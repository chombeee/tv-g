@echo off
setlocal
cd /d "%~dp0.."
where gh >nul 2>nul || (echo Pasang GitHub CLI dahulu. & exit /b 1)
gh auth status || exit /b 1

if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "TOOLS=%ANDROID_HOME%\build-tools\34.0.0"
if not exist "%TOOLS%\apksigner.bat" (echo Pasang Android SDK Build-Tools 34.0.0. & exit /b 1)

if "%~1"=="" (
    call gradlew.bat assembleRelease || exit /b 1
    set "APK=app\build\outputs\apk\release\app-release.apk"
) else (
    set "APK=%~f1"
)
if not exist "%APK%" (echo APK tidak ditemui. & exit /b 1)

call "%TOOLS%\apksigner.bat" verify --print-certs "%APK%" > "%TEMP%\GlassTV-v3.3.1-cert.txt" || exit /b 1
findstr /i /x /c:"Signer #1 certificate SHA-256 digest: 2813eb2587b840bf6567053780df5b696b7b87dd93ffdb469aad727c007d9fa2" "%TEMP%\GlassTV-v3.3.1-cert.txt" >nul
if errorlevel 1 (
    echo Sijil APK tidak sepadan dengan v3.3. Bina atau tandatangan dengan keystore asal.
    exit /b 1
)
"%TOOLS%\aapt.exe" dump badging "%APK%" > "%TEMP%\GlassTV-v3.3.1-version.txt" || exit /b 1
findstr /c:"package: name='com.faris.glasstv' versionCode='45' versionName='3.3'" "%TEMP%\GlassTV-v3.3.1-version.txt" >nul || (echo Versi APK mesti 3.3 / 45. & exit /b 1)

powershell -NoProfile -ExecutionPolicy Bypass -File "release\Publish-Version.ps1" -Apk "%APK%"
exit /b %errorlevel%
