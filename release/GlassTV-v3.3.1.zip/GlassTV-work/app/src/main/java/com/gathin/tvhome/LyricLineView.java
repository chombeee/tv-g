package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.text.Layout;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ReplacementSpan;
import android.widget.TextView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    static final String[] STYLES = {"Api", "Pop", "Neon"};
    private static final Pattern WORD = Pattern.compile("\\S+");
    private final Paint spark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private PlaybackState playback;
    private long start, end;
    private int style;
    private float progress = -1f;
    private String lyrics = "";
    private int wordCount;

    LyricLineView(Context context) { super(context); }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (!lyrics.equals(text) || this.style != style) {
            lyrics = text;
            this.style = style;
            setText(style == 1 ? popWords(text) : text);
        }
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    private CharSequence popWords(String text) {
        SpannableString result = new SpannableString(text);
        Matcher matcher = WORD.matcher(text);
        wordCount = 0;
        while (matcher.find()) {
            result.setSpan(new Word(wordCount++), matcher.start(), matcher.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return result;
    }

    private final class Word extends ReplacementSpan {
        private final int index;

        Word(int index) { this.index = index; }

        @Override public int getSize(Paint paint, CharSequence text, int start, int end, Paint.FontMetricsInt metrics) {
            if (metrics != null) paint.getFontMetricsInt(metrics);
            return (int) Math.ceil(paint.measureText(text, start, end));
        }

        @Override public void draw(Canvas canvas, CharSequence text, int start, int end, float x, int top,
                int baseline, int bottom, Paint paint) {
            float phase = progress * wordCount - index;
            int color = paint.getColor();
            int saved = canvas.save();
            if (phase >= 0f && phase < 1f) {
                float scale = 1f + 0.25f * (float) (Math.exp(-3.5f * phase) * Math.sin(8f * phase));
                canvas.scale(scale, scale, x + paint.measureText(text, start, end) / 2f, baseline);
                paint.setColor(phase < 0.35f ? 0xFFFF83D2 : 0xFFFFE2A0);
            }
            canvas.drawText(text, start, end, x, baseline, paint);
            paint.setColor(color);
            canvas.restoreToCount(saved);
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && hasWindowFocus() && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        progress = position >= start && position < end ? (position - start) / (float) (end - start) : -1f;
        Layout layout = getLayout();
        if (progress < 0f || style == 1 || layout == null) {
            super.onDraw(canvas);
        } else {
            drawSweep(canvas, layout);
        }
        // Refresh until the media update selects the next line. Inactive and paused lines draw normally.
        if (playing && progress >= 0f) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private void drawSweep(Canvas canvas, Layout layout) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        float pulse = (float) Math.sin(android.os.SystemClock.uptimeMillis() * 0.003);
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            float band = getTextSize() * (style == 0 ? 0.55f : 1.4f);
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            if (style == 0 && remaining > 0f) {
                paint.setShader(remaining >= width
                        ? new LinearGradient(x, 0, x + width, 0, 0xFFFF801A, 0xFFFFAA3B, Shader.TileMode.CLAMP)
                        : new LinearGradient(edge - band, 0, edge + band * 0.15f, 0,
                            new int[]{0xFFFF7818, 0xFFFFE39E, 0xFFFFFFFF, getCurrentTextColor()},
                            new float[]{0f, 0.68f, 0.86f, 1f}, Shader.TileMode.CLAMP));
            } else if (style == 2) {
                int neon = android.graphics.Color.rgb(112 + Math.round(25 * pulse),
                        222 + Math.round(16 * pulse), 255);
                paint.setShader(new LinearGradient(edge - band, 0, edge + band, 0,
                        new int[]{neon, 0xFFFFFFFF, neon}, null, Shader.TileMode.CLAMP));
                paint.setShadowLayer(getTextSize() * (0.12f + 0.035f * pulse), 0, 0, 0xB600C7FF);
            }
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if (style == 0 && remaining > 0f && remaining < width) {
                drawSparks(canvas, left + edge, top + layout.getLineBaseline(i));
            }
            remaining -= width;
        }
    }

    private void drawSparks(Canvas canvas, float x, float baseline) {
        float size = getTextSize();
        long now = android.os.SystemClock.uptimeMillis();
        for (int i = 0; i < 12; i++) {
            float age = ((now + 53L * i) % 480L) / 480f;
            spark.setColor(i % 3 == 0 ? 0xFFFFEDB8 : 0xFFFF9327);
            spark.setAlpha((int) (210f * (1f - age)));
            canvas.drawCircle(x - age * size * (0.55f + (i % 4) * 0.24f),
                    baseline - size * (0.25f + age * (0.45f + (i % 3) * 0.22f)),
                    size * (0.018f + (i % 3) * 0.009f), spark);
        }
    }
}
