package com.gathin.tvhome;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.util.TypedValue;
import android.widget.TextView;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hero-only app grid: exactly five columns by two rows of rounded icon tiles, centred under the clock.
 * More than ten apps continue on further pages of ten, reached by moving past the last column.
 *
 * Built to stay cheap on slow boxes: icons are drawn once on a background thread into small bitmaps
 * and cached, the D-pad is handled here instead of by a focus search, and nothing animates unless
 * focus moves.
 */
final class HeroAppGrid extends FrameLayout {

    interface Host {
        /** UP from the top row: hand focus to the controls above the grid. */
        void focusTop();
        /** OK held on an app: show the Move / App info menu next to {@code anchor}. */
        void onHold(int tilePosition, View anchor);
        /** RIGHT from the last column: move onto the home widgets; false when there are none. */
    }

    static final int COLS = 5, ROWS = 2, PAGE = COLS * ROWS;

    /** Corner radius of an icon tile, as a fraction of its size. */
    private static final float RADIUS = 0.225f;
    private static final float FOCUS_SCALE = 1.07f;
    private static final int TILE_BACKDROP = 0xFF1C1E24;

    private static final LruCache<String, Bitmap> ICONS = new LruCache<>(96);
    private static volatile int iconGeneration;
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "hero-icons");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });
    private static final Interpolator EASE = new DecelerateInterpolator();

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final RecyclerView list;
    private final GridLayoutManager lm;
    private final Tiles tiles = new Tiles();
    private final AppAdapter source;
    private final Host host;
    private final float scale;

    /** One grid cell, the icon inside it, the glass rim around a focused icon, and the room kept for shadows. */
    final int cell, iconSize, rimPad, padV;
    /** Row height: the cell plus room under the icon for the small name capsule. */
    final int rowH, labelRoom;
    private Typeface labelFace;
    /** Grid slot of the app being moved, or -1. */
    private int movingSlot = -1;
    private ObjectAnimator wiggle;

    /** Grid slot (column-major, as the layout manager fills it) to AppAdapter tile position; -1 is an empty slot. */
    private int[] slots = new int[0];
    private String signature = "";
    private int focusedSlot;
    private int pendingFocus = -1;
    /** Horizontal scroll offset in pixels, tracked exactly rather than estimated. */
    private int scrolled;
    /** Where a running page scroll is heading, so a second request for the same page does not restart it. */
    private int scrollTarget = -1;

    HeroAppGrid(Context c, AppAdapter adapter, Host h) {
        super(c);
        source = adapter;
        host = h;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        scale = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        cell = Math.max(48, Math.round(195 * scale));
        iconSize = Math.max(32, Math.round(140 * scale));
        rimPad = Math.max(2, Math.round(11 * scale));
        padV = Math.round(20 * scale);
        labelRoom = Math.round(18 * scale);
        rowH = cell + labelRoom;
        try { labelFace = c.getResources().getFont(R.font.outfit); } catch (Exception e) { labelFace = Typeface.DEFAULT; }

        // Paging is done here; the layout manager must not also scroll a focused tile into view.
        lm = new GridLayoutManager(c, ROWS, RecyclerView.HORIZONTAL, false) {
            @Override
            public boolean requestChildRectangleOnScreen(RecyclerView parent, View child, Rect rect, boolean immediate) {
                return false;
            }

            public boolean requestChildRectangleOnScreen(RecyclerView parent, View child, Rect rect,
                    boolean immediate, boolean focusedChildVisible) {
                return false;
            }
        };
        list = new RecyclerView(c);
        list.setLayoutManager(lm);
        list.setHasFixedSize(true);
        list.setItemAnimator(null);
        list.setItemViewCacheSize(PAGE);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // Vertical padding only: room for the focus scale and shadows. Sideways the list ends exactly
        // at five columns, so the next page never peeks in.
        list.setPadding(0, padV, 0, padV);
        list.setClipToPadding(false);
        list.setClipChildren(false);
        list.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        list.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView rv, int dx, int dy) {
                scrolled += dx;
            }
        });
        // Focus that lands on the list itself (after a rebind, say) belongs on a tile.
        list.setOnFocusChangeListener((v, focused) -> {
            if (focused && list.isFocused()) ui.post(this::focusCurrent);
        });
        list.setAdapter(tiles);
        addView(list, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        reload(false);
    }

    /** Width of exactly five columns. */
    int viewWidth() {
        return COLS * cell;
    }

    /** Height of two rows plus the shadow room above and below. */
    int viewHeight() {
        return ROWS * rowH + 2 * padV;
    }

    /**
     * Re-reads the apps from the adapter.
     *
     * @param iconsMayHaveChanged an app was installed, updated or removed, so cached icons are dropped
     */
    void reload(boolean iconsMayHaveChanged) {
        ArrayList<Integer> apps = new ArrayList<>();
        StringBuilder sig = new StringBuilder();
        for (int i = 0, n = source.tileCount(); i < n; i++) {
            AppAdapter.Entry e = source.tileAt(i);
            if (e.kind != AppAdapter.Entry.APP) continue;
            apps.add(i);
            sig.append(keyOf(e)).append('@').append(i).append(';');
        }
        if (iconsMayHaveChanged) {
            iconGeneration++;
            ICONS.evictAll();
        }
        String now = sig.toString();
        if (now.equals(signature)) {
            // Same apps in the same order: rebind in place, which keeps focus where it is.
            if (iconsMayHaveChanged && slots.length > 0) tiles.notifyItemRangeChanged(0, slots.length);
            return;
        }
        signature = now;

        // Pages of ten, each filled row by row, so the order reads left to right like the classic grid.
        int n = apps.size();
        int pages = (n + PAGE - 1) / PAGE;
        int[] fresh = new int[pages * PAGE];
        Arrays.fill(fresh, -1);
        for (int i = 0; i < n; i++) {
            int within = i % PAGE;
            int col = (i / PAGE) * COLS + within % COLS;
            int row = within / COLS;
            fresh[col * ROWS + row] = apps.get(i);
        }
        boolean hadFocus = hasFocus();
        slots = fresh;
        if (focusedSlot >= slots.length || focusedSlot < 0 || slots.length == 0 || slots[focusedSlot] < 0) focusedSlot = 0;
        pendingFocus = -1;
        tiles.notifyDataSetChanged();
        if (slots.length > 0) jumpToPage(focusedSlot / PAGE);
        if (hadFocus) ui.post(this::focusCurrent);
    }

    /** Focus the first app. */
    void focusFirst() {
        focusedSlot = 0;
        focusCurrent();
    }

    /** Focus the app that last had focus, or the first one. */
    void focusCurrent() {
        if (slots.length == 0) return;
        int t = focusedSlot;
        if (t < 0 || t >= slots.length || slots[t] < 0) t = 0;
        if (slots[t] < 0) return;
        focusedSlot = t;
        RecyclerView.ViewHolder vh = list.findViewHolderForAdapterPosition(t);
        if (vh != null) {
            pendingFocus = -1;
            vh.itemView.requestFocus();
            return;
        }
        // Not laid out yet: bring its page in, and take focus as soon as the tile is attached.
        pendingFocus = t;
        jumpToPage(t / PAGE);
    }

    private void jumpToPage(int page) {
        list.stopScroll();
        lm.scrollToPositionWithOffset(page * PAGE, 0);
        scrolled = page * COLS * cell;
        scrollTarget = scrolled;
    }

    private void showPageOf(int slot) {
        int target = (slot / PAGE) * COLS * cell;
        if (target == scrolled) return;
        if (target == scrollTarget && list.getScrollState() != RecyclerView.SCROLL_STATE_IDLE) return;
        if (!list.isLaidOut()) {
            jumpToPage(slot / PAGE);
            return;
        }
        scrollTarget = target;
        list.smoothScrollBy(target - scrolled, 0, EASE, 240);
    }

    private void moveTo(int slot) {
        if (slot < 0 || slot >= slots.length || slots[slot] < 0) return;
        SoundEffects.playNav();
        focusedSlot = slot;
        RecyclerView.ViewHolder vh = list.findViewHolderForAdapterPosition(slot);
        if (vh != null) {
            pendingFocus = -1;
            vh.itemView.requestFocus();
        } else {
            pendingFocus = slot;
            showPageOf(slot);
        }
    }

    private boolean onTileKey(Holder h, int code, KeyEvent event) {
        if (code != KeyEvent.KEYCODE_DPAD_LEFT && code != KeyEvent.KEYCODE_DPAD_RIGHT
                && code != KeyEvent.KEYCODE_DPAD_UP && code != KeyEvent.KEYCODE_DPAD_DOWN) return false;
        if (event.getAction() != KeyEvent.ACTION_DOWN) return true;
        int slot = h.slot;
        if (slot < 0 || slot >= slots.length) return true;
        int col = slot / ROWS, row = slot % ROWS, cols = slots.length / ROWS;
        if (movingSlot >= 0) {
            int to = -1;
            if (code == KeyEvent.KEYCODE_DPAD_UP && row > 0) to = slot - 1;
            else if (code == KeyEvent.KEYCODE_DPAD_DOWN && row < ROWS - 1) to = slot + 1;
            else if (code == KeyEvent.KEYCODE_DPAD_LEFT && col > 0) to = slot - ROWS;
            else if (code == KeyEvent.KEYCODE_DPAD_RIGHT && col < cols - 1) to = slot + ROWS;
            if (to >= 0 && to < slots.length && slots[to] >= 0) carry(slot, to);
            return true;
        }
        if (code == KeyEvent.KEYCODE_DPAD_UP) {
            if (row == 0) host.focusTop();
            else moveTo(slot - 1);
        } else if (code == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (row < ROWS - 1) moveTo(slot + 1);
        } else if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
            if (col > 0) {
                int t = slot - ROWS;
                if (slots[t] >= 0) moveTo(t);
            }
        } else if (col < cols - 1) {
            int t = slot + ROWS;
            if (slots[t] >= 0) moveTo(t);
        }
        return true;
    }

    /** Picks up the app at adapter position {@code tile}: it wiggles, the arrows carry it, OK or Back puts it down. */
    void startMove(int tile) {
        int slot = -1;
        for (int i = 0; i < slots.length; i++) if (slots[i] == tile) { slot = i; break; }
        if (slot < 0 || !source.canMove(tile)) return;
        movingSlot = slot;
        focusedSlot = slot;
        focusCurrent();
        RecyclerView.ViewHolder vh = list.findViewHolderForAdapterPosition(slot);
        if (vh instanceof Holder) startWiggle((Holder) vh);
    }

    boolean isMoving() { return movingSlot >= 0; }

    /** Puts the moving app down. Returns false when nothing was moving. */
    boolean endMove() {
        if (movingSlot < 0) return false;
        movingSlot = -1;
        stopWiggle();
        SoundEffects.playSelect();
        return true;
    }

    private void carry(int from, int to) {
        int fromTile = slots[from], toTile = slots[to];
        if (!source.move(fromTile, toTile)) return;
        SoundEffects.playNav();
        stopWiggle();
        movingSlot = to;
        focusedSlot = to;
        reload(false);   // the order changed, so the slots are rebuilt and focus follows the app
    }

    private void startWiggle(Holder h) {
        stopWiggle();
        wiggle = ObjectAnimator.ofFloat(h.body, View.ROTATION, -2.2f, 2.2f);
        wiggle.setDuration(130);
        wiggle.setRepeatMode(ValueAnimator.REVERSE);
        wiggle.setRepeatCount(ValueAnimator.INFINITE);
        wiggle.start();
    }

    private void stopWiggle() {
        if (wiggle == null) return;
        Object target = wiggle.getTarget();
        wiggle.cancel();
        wiggle = null;
        if (target instanceof View) ((View) target).setRotation(0f);
    }

    private void onTileFocus(Holder h, boolean focused) {
        if (focused && h.slot >= 0) {
            focusedSlot = h.slot;
            pendingFocus = -1;
            showPageOf(h.slot);
        }
        h.rim.animate().alpha(focused ? 1f : 0f).setDuration(140).start();
        ChombbWidgets.springScale(h.body, focused ? FOCUS_SCALE : 1f, 380f, 0.62f);
        h.icon.setElevation(focused ? 10 * scale : 0f);
        h.label.animate().alpha(focused ? 1f : 0f).translationY(focused ? 0f : -6 * scale).setDuration(160).start();
    }

    private void launch(Holder h) {
        if (endMove()) return;   // OK while moving puts the app down
        int tile = h.tile;
        if (tile < 0 || tile >= source.tileCount()) return;
        // The adapter moved under us: show the right apps first rather than start the wrong one.
        if (h.key == null || !h.key.equals(keyOf(source.tileAt(tile)))) {
            reload(false);
            return;
        }
        source.launchAt(tile);
    }

    private static String keyOf(AppAdapter.Entry e) {
        return e.component != null ? e.component.flattenToShortString() : String.valueOf(e.pkg);
    }

    private static final class Holder extends RecyclerView.ViewHolder {
        final FrameLayout body;
        final View rim;
        final ImageView icon;
        final Drawable placeholder;
        final TextView label;
        int slot = -1, tile = -1;
        String key;

        Holder(View item, FrameLayout body, View rim, ImageView icon, Drawable placeholder, TextView label) {
            super(item);
            this.label = label;
            this.body = body;
            this.rim = rim;
            this.icon = icon;
            this.placeholder = placeholder;
        }
    }

    private final class Tiles extends RecyclerView.Adapter<Holder> {
        @Override
        public Holder onCreateViewHolder(ViewGroup parent, int type) {
            Context c = parent.getContext();
            FrameLayout item = new FrameLayout(c);
            item.setLayoutParams(new RecyclerView.LayoutParams(cell, rowH));
            item.setFocusable(true);
            item.setClickable(true);
            item.setClipChildren(false);

            int rimSize = iconSize + 2 * rimPad;
            final float radius = iconSize * RADIUS;
            FrameLayout body = new FrameLayout(c);
            body.setClipChildren(false);

            // The frosted rim that shows around the focused icon.
            View rim = new View(c);
            GradientDrawable glass = new GradientDrawable();
            glass.setCornerRadius(radius + rimPad * 0.9f);
            glass.setColor(GlassStyle.tint(0x52FFFFFF));
            glass.setStroke(Math.max(1, Math.round(1.5f * scale)), 0x80FFFFFF);
            rim.setBackground(glass);
            rim.setAlpha(0f);
            body.addView(rim, new FrameLayout.LayoutParams(rimSize, rimSize, Gravity.CENTER));

            ImageView icon = new ImageView(c);
            icon.setScaleType(ImageView.ScaleType.FIT_XY);
            icon.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            GradientDrawable placeholder = new GradientDrawable();
            placeholder.setCornerRadius(radius);
            placeholder.setColor(0x33FFFFFF);
            body.addView(icon, new FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER));
            FrameLayout.LayoutParams bodyLp = new FrameLayout.LayoutParams(rimSize, rimSize, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            bodyLp.topMargin = (cell - rimSize) / 2;
            item.addView(body, bodyLp);

            // Small glass capsule with the app's name, shown only under the focused icon.
            TextView label = new TextView(c);
            label.setTextColor(0xF2FFFFFF);
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 19 * scale);
            label.setTypeface(labelFace);
            try { label.setFontVariationSettings("'wght' 550"); } catch (Exception ignored) { }
            label.setLetterSpacing(0.02f);
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            label.setIncludeFontPadding(false);
            label.setGravity(Gravity.CENTER);
            label.setMaxWidth(cell - Math.round(10 * scale));
            int lh = Math.round(14 * scale), lv = Math.round(6 * scale);
            label.setPadding(lh, lv, lh, lv);
            GradientDrawable capsule = new GradientDrawable();
            capsule.setColor(GlassStyle.tint(0x47000000));
            capsule.setCornerRadius(40 * scale);
            capsule.setStroke(Math.max(1, Math.round(scale)), 0x40FFFFFF);
            label.setBackground(capsule);
            label.setAlpha(0f);
            FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            labelLp.topMargin = (cell + iconSize) / 2 + Math.round(12 * scale);
            item.addView(label, labelLp);

            final Holder h = new Holder(item, body, rim, icon, placeholder, label);
            item.setOnFocusChangeListener((v, focused) -> onTileFocus(h, focused));
            item.setOnClickListener(v -> launch(h));
            item.setOnLongClickListener(v -> {
                if (h.tile < 0 || movingSlot >= 0) return true;
                host.onHold(h.tile, h.body);
                return true;
            });
            item.setOnKeyListener((v, code, event) -> onTileKey(h, code, event));
            return h;
        }

        @Override
        public void onBindViewHolder(Holder h, int position) {
            int tile = position < slots.length ? slots[position] : -1;
            if (tile >= source.tileCount()) tile = -1;
            h.slot = position;
            h.tile = tile;
            View item = h.itemView;
            boolean focused = tile >= 0 && item.isFocused();
            h.rim.animate().cancel();
            h.body.animate().cancel();
            h.rim.setAlpha(focused ? 1f : 0f);
            h.body.setScaleX(focused ? FOCUS_SCALE : 1f);
            h.body.setScaleY(focused ? FOCUS_SCALE : 1f);
            h.icon.setElevation(focused ? 10 * scale : 0f);
            h.label.animate().cancel();
            h.label.setAlpha(focused ? 1f : 0f);
            h.label.setTranslationY(0f);
            if (wiggle != null && wiggle.getTarget() == h.body) stopWiggle();
            h.body.setRotation(0f);
            if (tile < 0) {
                // Filler that completes the last page; it is never focusable or visible.
                h.key = null;
                h.icon.setImageDrawable(null);
                h.icon.setBackground(null);
                item.setFocusable(false);
                item.setVisibility(View.INVISIBLE);
                return;
            }
            item.setVisibility(View.VISIBLE);
            item.setFocusable(true);
            AppAdapter.Entry e = source.tileAt(tile);
            item.setContentDescription(e.label);
            h.label.setText(e.label);
            if (position == movingSlot) startWiggle(h);
            String key = keyOf(e);
            h.key = key;
            Bitmap cached = ICONS.get(key);
            if (cached != null) {
                h.icon.setBackground(null);
                h.icon.setImageBitmap(cached);
            } else {
                h.icon.setImageDrawable(null);
                h.icon.setBackground(h.placeholder);
                loadIcon(h, e, key);
            }
        }

        @Override
        public void onViewAttachedToWindow(Holder h) {
            if (pendingFocus >= 0 && h.slot == pendingFocus) {
                final int want = pendingFocus;
                ui.post(() -> {
                    if (pendingFocus == want && h.slot == want && h.itemView.isAttachedToWindow()) {
                        pendingFocus = -1;
                        h.itemView.requestFocus();
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return slots.length;
        }
    }

    private void loadIcon(final Holder h, AppAdapter.Entry e, final String key) {
        final ComponentName component = e.component;
        final String pkg = e.pkg;
        final Drawable ownIcon = e.icon, banner = e.banner;
        final int size = iconSize;
        final int generation = iconGeneration;
        final PackageManager pm = getContext().getApplicationContext().getPackageManager();
        LOADER.execute(() -> {
            Bitmap made = null;
            try {
                made = render(find(pm, component, pkg, ownIcon, banner), size);
            } catch (Throwable ignored) {
                // An icon that cannot be drawn leaves the placeholder; it must never take Home down.
            }
            final Bitmap out = made;
            ui.post(() -> {
                if (out == null || generation != iconGeneration) return;
                ICONS.put(key, out);
                if (key.equals(h.key)) {
                    h.icon.setBackground(null);
                    h.icon.setImageBitmap(out);
                }
            });
        });
    }

    /**
     * A private copy of the app's icon. The adapter's own drawables are shared with the classic grid,
     * so they are never given new bounds or drawn from this thread.
     */
    private static Drawable find(PackageManager pm, ComponentName component, String pkg, Drawable ownIcon, Drawable banner) {
        Drawable d = null;
        boolean hasIcon = true;
        if (component != null) {
            try {
                hasIcon = pm.getActivityInfo(component, 0).getIconResource() != 0;
            } catch (Exception ignored) {
            }
            // A TV app that ships only a banner: the middle of the banner beats the system's blank icon.
            if (!hasIcon && banner != null && banner.getConstantState() != null) {
                return banner.getConstantState().newDrawable().mutate();
            }
            try {
                d = pm.getActivityIcon(component);
            } catch (Exception ignored) {
            }
        }
        if (d == null && pkg != null) {
            try {
                d = pm.getApplicationIcon(pkg);
            } catch (Exception ignored) {
            }
        }
        if (d == null && ownIcon != null && ownIcon.getConstantState() != null) {
            d = ownIcon.getConstantState().newDrawable().mutate();
        }
        return d;
    }

    /** Draws an icon as a full-bleed rounded square, the way the reference design shows them. */
    private static Bitmap render(Drawable d, int s) {
        if (d == null || s <= 0) return null;
        Bitmap raw = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(raw);
        if (d instanceof AdaptiveIconDrawable) {
            // Adaptive layers are 108dp around a 72dp viewport: draw them 1.5x so the viewport fills the tile.
            AdaptiveIconDrawable a = (AdaptiveIconDrawable) d;
            int inset = Math.round(s * 0.25f);
            Drawable bg = a.getBackground(), fg = a.getForeground();
            if (bg != null) {
                bg.setBounds(-inset, -inset, s + inset, s + inset);
                bg.draw(c);
            }
            if (fg != null) {
                fg.setBounds(-inset, -inset, s + inset, s + inset);
                fg.draw(c);
            }
            c.drawColor(TILE_BACKDROP, PorterDuff.Mode.DST_OVER);
        } else {
            fit(d, s, 1f);
            d.draw(c);
            // A shaped icon (clear corners) sits smaller on a dark tile; a square one fills it.
            int m = Math.max(1, Math.round(s * 0.04f)), far = s - 1 - m;
            boolean shaped = Color.alpha(raw.getPixel(m, m)) < 40 && Color.alpha(raw.getPixel(far, m)) < 40
                    && Color.alpha(raw.getPixel(m, far)) < 40 && Color.alpha(raw.getPixel(far, far)) < 40;
            if (shaped) {
                raw.eraseColor(TILE_BACKDROP);
                fit(d, s, 0.78f);
                d.draw(c);
            } else {
                c.drawColor(TILE_BACKDROP, PorterDuff.Mode.DST_OVER);
            }
        }
        Bitmap out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        p.setShader(new BitmapShader(raw, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
        float r = s * RADIUS;
        new Canvas(out).drawRoundRect(new RectF(0, 0, s, s), r, r, p);
        raw.recycle();
        return out;
    }

    /** Centre-crops the drawable into a square of side {@code s}, scaled by {@code k}. */
    private static void fit(Drawable d, int s, float k) {
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        float side = s * k;
        if (w <= 0 || h <= 0) {
            int off = Math.round((s - side) / 2f);
            d.setBounds(off, off, s - off, s - off);
            return;
        }
        float z = Math.max(side / w, side / h);
        int dw = Math.round(w * z), dh = Math.round(h * z);
        int left = (s - dw) / 2, top = (s - dh) / 2;
        d.setBounds(left, top, left + dw, top + dh);
    }
}
