package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.TextView;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak", "Itik Ombak"};
    private static final int DUCK = 4;
    private static final int[] ACCENTS = {0xFFFF7622, 0xFFFFCA56, 0xFF56E4FF, 0xFF5AAEFF, 0xFF5AAEFF};
    private final Paint character = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint splash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path drop = new Path();
    private final Path wake = new Path();
    private PlaybackState playback;
    private long effectsAfter, start, end;
    private boolean playsInScreensaver;
    private boolean compact;
    private int style;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void setPlaysInScreensaver() { playsInScreensaver = true; }

    @Override public int getCompoundPaddingBottom() {
        return super.getCompoundPaddingBottom() + (style == DUCK ? Math.round(getTextSize() * .42f) : 0);
    }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (this.style != style) {
            this.style = style;
            requestLayout();
        }
        if (!TextUtils.equals(getText(), text)) setText(text);
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && (hasWindowFocus() || playsInScreensaver) && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        boolean active = playing && position >= start && position < end;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();
        if (active && now >= effectsAfter && layout != null) {
            float progress = (position - start) / (float) (end - start);
            drawSweep(canvas, layout, progress, now);
        } else {
            super.onDraw(canvas);
        }
        if (active) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private void drawSweep(Canvas canvas, Layout layout, float progress, long now) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            applySweep(paint, x, width, edge, remaining, now);
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if ((style == 0 || style == 3 || style == DUCK) && remaining >= 0f && remaining < width) {
                float baseline = top + layout.getLineBaseline(i);
                if (style == DUCK) drawDuck(canvas, left + edge, baseline, now);
                else drawSplash(canvas, left + edge, baseline,
                        (float) (totalWidth * 1000.0 / (end - start)), now, style == 3);
            }
            remaining -= width;
        }
    }

    private void applySweep(Paint paint, float x, float width, float edge, float remaining, long now) {
        float size = getTextSize();
        int accent = ACCENTS[style];
        if (style == 2) {
            float pulse = (float) Math.sin(now * 0.003);
            paint.setShader(new LinearGradient(edge - size * 1.4f, 0, edge + size * 1.4f, 0,
                    new int[]{accent, 0xFFFFFFFF, accent}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(size * ((compact ? 0.075f : 0.12f) + 0.025f * pulse), 0, 0, 0xB600C7FF);
        } else if (remaining >= width) {
            paint.setShader(new LinearGradient(x, 0, x + width, 0, accent,
                    style == 0 ? 0xFFFFA832 : accent, Shader.TileMode.CLAMP));
        } else if (remaining >= 0f) {
            if (style == 3 || style == DUCK) {
                float ripple = (float) Math.sin(now * .016) * size * .32f;
                paint.setShader(new LinearGradient(edge - size * 1.8f, -size, edge + size * .6f + ripple, 0,
                        new int[]{0xFF1E7BCB, 0xFF43C9F6, 0xFF217FCD, 0xFF79E5FF, 0xFFF0FCFF, getCurrentTextColor()},
                        new float[]{0f, .28f, .46f, .68f, .82f, 1f}, Shader.TileMode.CLAMP));
            } else if (style == 1) {
                float gleam = (float) Math.sin(now * .013) * size * .15f;
                paint.setShader(new LinearGradient(edge - size * 1.9f, 0, edge + size * .45f + gleam, size * .45f,
                        new int[]{0xFFF1A824, 0xFFFEDD7B, 0xFFBD7413, 0xFFFFD565, 0xFFFFFBCE, getCurrentTextColor()},
                        new float[]{0f, .30f, .48f, .63f, .80f, 1f}, Shader.TileMode.CLAMP));
            } else {
                float band = size * (compact ? 1.12f : 1.65f);
                paint.setShader(new LinearGradient(edge - band, 0, edge + band * .24f, 0,
                        new int[]{accent, 0xFFFFA832, 0xFFFFF1C4, getCurrentTextColor()},
                        new float[]{0f, .40f, .81f, 1f}, Shader.TileMode.CLAMP));
                paint.setShadowLayer(size * (compact ? .08f : .13f), 0, 0, 0x90FF6715);
            }
        }
    }

    private void drawDuck(Canvas canvas, float edge, float baseline, long now) {
        float unit = getTextSize() * (compact ? .65f : .76f);
        float x = Math.max(unit, Math.min(getWidth() - unit, edge));
        float sea = (now % 10000L) * .009f;
        float y = Math.max(unit, Math.min(getHeight() - unit * .65f, baseline + unit * .42f));
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.scale(unit, unit);

        drawWake(canvas, sea, -.13f, 0x8A16658C, 0x769DDFFF);
        drawDuckSpray(canvas, now, false);
        int bird = canvas.save();
        canvas.translate(0f, (float) Math.sin(sea) * .045f);
        canvas.rotate((float) Math.cos(sea) * 4f);
        character.setColor(0xFFFFB629);
        canvas.drawOval(-.76f, -.31f, .51f, .30f, character);
        character.setColor(0xFFFFD957);
        canvas.drawOval(-.49f, -.22f, .12f, .12f, character);
        character.setColor(0xFFFFE05C);
        canvas.drawCircle(.29f, -.40f, .35f, character);
        character.setColor(0xFFFF861D);
        canvas.drawOval(.48f, -.40f, .90f, -.21f, character);
        character.setColor(0xFF24202A);
        canvas.drawCircle(.39f, -.49f, .065f, character);
        canvas.restoreToCount(bird);
        drawWake(canvas, sea + 2.1f, .16f, 0xB325A8CE, 0xDEF0FDFF);
        drawDuckSpray(canvas, now, true);
        canvas.restoreToCount(saved);
    }

    private void drawWake(Canvas canvas, float phase, float height, int fill, int foam) {
        wake.rewind();
        wake.moveTo(-1.50f, height);
        float swell = (float) Math.sin(phase) * .16f;
        wake.cubicTo(-1.10f, height - .08f, -.69f, height + swell, -.26f, height);
        wake.cubicTo(.18f, height - swell, .48f, height + .16f, .83f, height - .08f);
        wake.quadTo(1.11f, height - .23f, 1.39f, height);
        character.setColor(foam);
        character.setStyle(Paint.Style.STROKE);
        character.setStrokeWidth(.045f);
        canvas.drawPath(wake, character);
        character.setStyle(Paint.Style.FILL);
        wake.quadTo(.75f, height + .30f, -.30f, height + .25f);
        wake.quadTo(-1.29f, height + .19f, -1.50f, height);
        wake.close();
        character.setColor(fill);
        canvas.drawPath(wake, character);
    }

    private void drawDuckSpray(Canvas canvas, long now, boolean foreground) {
        // Alternating directions launch off the bow and wake, then fall under gravity.
        for (int i = 0; i < 6; i++) {
            int index = foreground ? i + 6 : i;
            long cycle = 360L + index * 19L;
            float t = ((now + index * 53L) % cycle) / (float) cycle;
            float side = index % 2 == 0 ? 1f : -1f;
            float vx = side * (.68f + (index % 4) * .25f);
            float lift = .67f + (index % 5) * .25f;
            float x = side * (.48f + t * Math.abs(vx));
            float y = (foreground ? .16f : -.06f) - lift * t + lift * t * t;
            float size = (.044f + (index % 4) * .019f) * (1f - t * .42f);
            drawDroplet(canvas, x, y, size, vx, lift * (2f * t - 1f),
                    (1f - t) * (foreground ? 1f : .65f), index);
        }
    }

    /**
     * Like the Now Playing bar, the moving head emits particles forward through the fill,
     * above and below the row. Water adds gravity, stretched droplets and white reflections.
     */
    private void drawSplash(Canvas canvas, float head, float baseline, float sweepSpeed, long now, boolean water) {
        float size = getTextSize();
        float centerY = baseline - size * .44f;
        float pulse = .86f + .14f * (float) Math.sin((now % 10000L) * .018);
        float halo = size * (compact ? .62f : .81f) * pulse;
        splash.setShader(new RadialGradient(head, centerY, halo,
                water ? new int[]{0xB9ECFCFF, 0x6043C9FF, 0x00217FCD}
                        : new int[]{0xB9FFF2C8, 0x67FF9D3C, 0x00FF7622},
                new float[]{0f, .40f, 1f}, Shader.TileMode.CLAMP));
        splash.setAlpha(255);
        canvas.drawCircle(head, centerY, halo, splash);
        splash.setShader(null);

        int count = compact ? 10 : 12;
        for (int i = 0; i < count; i++) {
            long period = 410L + (i * 83L) % 215L;
            float elapsed = ((now + 83L * i) % period) / 1000f;
            float phase = elapsed * 1000f / period;
            float direction = (i % 4 == 0) ? 1f : -1f;
            float speedX = size * (1.70f + ((i * 7) % 11) * .31f);
            float speedY = size * (.48f + ((i * 11) % 7) * .22f) * direction;
            float gravity = size * (water ? 5.6f : -.9f);
            float x = head - size * (.08f + i % 4 * .21f) + (speedX - sweepSpeed * .25f) * elapsed;
            float y = centerY + speedY * elapsed + gravity * elapsed * elapsed * .5f;
            float radius = size * (.050f + ((i * 5) % 7) * .010f) * (1f - .5f * phase);
            if (x + radius < 0f || x - radius > getWidth()
                    || y + radius < 0f || y - radius > getHeight()) continue;
            float opacity = (1f - phase) * (1f - phase);
            if (water) {
                drawDroplet(canvas, x, y, radius, speedX, speedY + gravity * elapsed, opacity, i);
            } else {
                splash.setColor(i % 4 == 0 ? 0xFFFFF2BD : 0xFFFF8D35);
                splash.setAlpha(Math.round(105f * opacity));
                canvas.drawCircle(x, y, radius * 1.75f, splash);
                splash.setColor(i % 3 == 0 ? 0xFFFFF7DA : 0xFFFFBC64);
                splash.setAlpha(Math.round(255f * opacity));
                canvas.drawCircle(x, y, radius, splash);
            }
        }
    }

    private void drawDroplet(Canvas canvas, float x, float y, float radius, float vx, float vy, float opacity, int index) {
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.rotate((float) Math.toDegrees(Math.atan2(vy, vx)));
        drop.rewind();
        drop.moveTo(-radius * 2.5f, 0f);
        drop.cubicTo(-radius, -radius * .30f, -.3f * radius, -radius, radius * .5f, -radius);
        drop.cubicTo(radius * 2f, -radius, radius * 2f, radius, radius * .5f, radius);
        drop.cubicTo(-.3f * radius, radius, -radius, radius * .30f, -radius * 2.5f, 0f);
        drop.close();
        splash.setColor(index % 3 == 0 ? 0xFF8BEBFF : 0xFF35BBF4);
        splash.setAlpha(Math.round(235f * opacity));
        canvas.drawPath(drop, splash);
        splash.setColor(0xFFF5FFFF);
        splash.setAlpha(Math.round(245f * opacity));
        canvas.drawOval(0f, -radius * .67f, radius * 1.05f, -radius * .18f, splash);
        canvas.restoreToCount(saved);
    }
}
