param([Parameter(Mandatory=$true)][string]$Apk)
$ErrorActionPreference = 'Stop'
$repo = 'chombeee/tv-g'
$tag = 'v3.3.7'
$endpoint = "repos/$repo/contents/release/version.json"
$versionPath = Join-Path $PSScriptRoot 'version.json'

function Invoke-Gh {
    & gh @args
    if ($LASTEXITCODE -ne 0) { throw "GitHub CLI gagal (kod $LASTEXITCODE)." }
}

$current = Invoke-Gh api ("${endpoint}?ref=main") | ConvertFrom-Json
$remote = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($current.content)) | ConvertFrom-Json
$next = Get-Content -Raw $versionPath | ConvertFrom-Json
if ($next.versionCode -ne 51 -or $next.versionName -ne '3.3.7' -or
    $next.apkUrl -ne "https://github.com/$repo/releases/download/$tag/v3.3.7.apk") {
    throw 'Semak release/version.json sebelum publish.'
}
if ($remote.versionCode -gt 51) { throw 'OTA di GitHub sudah lebih baharu daripada kod 51.' }

$temp = Join-Path ([IO.Path]::GetTempPath()) ('GlassTV-' + [Guid]::NewGuid())
New-Item -ItemType Directory -Path $temp | Out-Null
try {
    $asset = Join-Path $temp 'v3.3.7.apk'
    Copy-Item -LiteralPath $Apk -Destination $asset
    $tags = Invoke-Gh api --paginate "repos/$repo/releases?per_page=100" --jq '.[].tag_name'
    if ($tags -contains $tag) {
        Invoke-Gh release upload $tag $asset --clobber -R $repo
        Invoke-Gh release edit $tag --draft=false --prerelease=false --title $tag --notes $next.changelog -R $repo
    } else {
        Invoke-Gh release create $tag $asset --target main --title $tag --notes $next.changelog -R $repo
    }
    $check = Join-Path $temp 'verified'
    New-Item -ItemType Directory -Path $check | Out-Null
    Invoke-Gh release download $tag -p 'v3.3.7.apk' -D $check -R $repo
    if ((Get-FileHash $asset).Hash -ne (Get-FileHash (Join-Path $check 'v3.3.7.apk')).Hash) {
        throw 'Semakan APK yang dimuat naik gagal.'
    }
    $payload = @{
        message = 'Update GlassTV OTA to v3.3.7 (51)'
        content = [Convert]::ToBase64String([IO.File]::ReadAllBytes($versionPath))
        sha = $current.sha
        branch = 'main'
    } | ConvertTo-Json -Compress
    $body = Join-Path $temp 'payload.json'
    [IO.File]::WriteAllText($body, $payload)
    Invoke-Gh api --method PUT $endpoint --input $body --jq '.commit.html_url'
} finally {
    Remove-Item -LiteralPath $temp -Recurse -Force
}
