# GlassTV CHOMBB — incremental source update

Screensaver change from prior WIP preserved.

Changes in this revision:
- Preferences > Wallpaper now exposes collection selection and video wallpaper settings, instead of showing an empty category.
- Classic-only Glass Transparency now recreates the activity after Apply to reload the home visuals.
- Glass Pills / Material dock: compact fixed six-app row plus All Apps arrow, smaller sizing and color-coded focus ring for known apps.
- Existing layout selection keys and Material/Hero layout infrastructure retained.

NOT YET COMPLETE: separate full designs for Glass Pills and Material Dynamic, adaptive Quick Settings skins, all functional Preferences fixes, new sound assets, device/emulator validation. This is a partial source update, not a completed Catatan #1-#11 release.

Build on Windows: .\\gradlew.bat clean assembleDebug
