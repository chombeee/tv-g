# Material TV A9 vs GlassTV UI #4 — source audit

Source compared: Material-TV-Launcher-A9-UPDATED MIBOX(2).zip, src/com/rampey/materialtv/HomeActivity.java and CookieDrawable.java.

1. A9 draws CookieDrawable inside an ImageView with hardware layer, root gradient backdrop, 560dp square at top-right, -150dp top and -120dp right. Its color comes from Palette.primaryContainer; focus morphs across nine MaterialShapes presets.
2. Prior GlassTV material blob was drawn in a HeroBlob subclass but could be visually obscured by wallpaper/legacy views. This patch explicitly elevates the dim layer (1dp), blob (2dp), and UI controls (5–6dp). The wallpaper remains selectable, with a dark overlay in Material mode only.
3. A9's preset shape families are now mirrored in MaterialBlob, with rotation and color interpolation preserved. This is an integration, NOT a direct port of A9's full Activity or palette extraction.
4. GlassTV PillDock is a separate implementation. Banner and row allocations are enlarged; focus remains stroke-only. Layout is not pixel-identical to A9.
5. UI #1–3 logic is unchanged. Material mode-specific layers are hidden outside Material mode.

Verification: ZIP source structure checked. Android compile/runtime not tested here; check build and screenshot on device before calling it finished.
