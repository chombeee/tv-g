package com.gathin.tvhome;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Provides the user-authorized MediaSession access; signals metadata changes to widgets. */
public final class ChombbMediaListener extends NotificationListenerService {
    @Override public void onListenerConnected() { super.onListenerConnected(); ChombbWidgets.invalidateMedia(); }
    @Override public void onListenerDisconnected() { ChombbWidgets.invalidateMedia(); super.onListenerDisconnected(); }
    @Override public void onNotificationPosted(StatusBarNotification sbn) { ChombbWidgets.invalidateMedia(); }
    @Override public void onNotificationRemoved(StatusBarNotification sbn) { ChombbWidgets.invalidateMedia(); }
}
