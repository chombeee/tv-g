package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * One search box for everything: installed apps (as you type), Google Play, YouTube, Google on the web,
 * opening a website directly, and searching inside any app that accepts a search (Netflix, SmartTube...).
 */
final class UniversalSearch {
    private UniversalSearch() { }

    private static final class App {
        final String label, pkg, activity;
        App(String label, String pkg, String activity) { this.label = label; this.pkg = pkg; this.activity = activity; }
    }

    static void show(Activity a) {
        if (a.isFinishing()) return;
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        final float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        Typeface face;
        try { face = a.getResources().getFont(R.font.outfit); } catch (Exception e) { face = Typeface.DEFAULT; }
        final Typeface font = face;
        final PackageManager pm = a.getPackageManager();

        // Apps and search-capable apps are listed once, not on every key press.
        final List<App> apps = installedApps(a, pm);
        final List<App> searchable = searchableApps(a, pm);

        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(28 * s);
        panel.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2161B23);
        bg.setCornerRadius(34 * s);
        bg.setStroke(Math.max(1, Math.round(1.5f * s)), 0x33FFFFFF);
        panel.setBackground(bg);

        final EditText input = new EditText(a);
        input.setSingleLine(true);
        input.setHint("Cari app, Play Store, YouTube, laman web…");
        input.setHintTextColor(0x80FFFFFF);
        input.setTextColor(Color.WHITE);
        input.setTextSize(TypedValue.COMPLEX_UNIT_PX, 32 * s);
        input.setTypeface(font);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        int ip = Math.round(22 * s);
        input.setPadding(ip, Math.round(16 * s), ip, Math.round(16 * s));
        GradientDrawable field = new GradientDrawable();
        field.setColor(0x1FFFFFFF);
        field.setCornerRadius(40 * s);
        field.setStroke(Math.max(1, Math.round(2 * s)), 0x40FFFFFF);
        input.setBackground(field);
        input.setOnFocusChangeListener((v, f) -> field.setStroke(Math.max(1, Math.round(2 * s)), f ? 0xFFFFFFFF : 0x40FFFFFF));
        panel.addView(input, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(a);
        final LinearLayout results = new LinearLayout(a);
        results.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(results);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, Math.round(560 * s));
        sp.topMargin = Math.round(18 * s);
        panel.addView(scroll, sp);

        final Runnable refresh = () -> {
            results.removeAllViews();
            String q = input.getText().toString().trim();
            String lq = q.toLowerCase(Locale.ROOT);
            int shown = 0;
            for (App app : apps) {
                if (!q.isEmpty() && !app.label.toLowerCase(Locale.ROOT).contains(lq)) continue;
                results.addView(row(a, d, s, font, app.label, q.isEmpty() ? "App" : "Buka app", app.pkg, 0, () -> launch(a, pm, app)));
                if (++shown >= (q.isEmpty() ? 6 : 8)) break;
            }
            if (q.isEmpty()) {
                if (shown == 0) results.addView(note(a, s, font, "Taip untuk mencari"));
                return;
            }
            if (looksLikeUrl(q)) {
                String url = q.startsWith("http") ? q : "https://" + q;
                results.addView(row(a, d, s, font, "Buka laman: " + q, "Pelayar web", null, R.drawable.ic_search,
                        () -> view(a, Uri.parse(url), null, "Tiada pelayar web dipasang")));
            }
            results.addView(row(a, d, s, font, "Cari \"" + q + "\" di Google Play", "Play Store", "com.android.vending", R.drawable.ic_search,
                    () -> playStore(a, q)));
            results.addView(row(a, d, s, font, "Cari \"" + q + "\" di YouTube", "YouTube", null, R.drawable.ic_search,
                    () -> youtube(a, pm, q, searchable)));
            results.addView(row(a, d, s, font, "Cari \"" + q + "\" di Google", "Web", null, R.drawable.ic_search,
                    () -> view(a, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)), null, "Tiada pelayar web dipasang")));
            for (App app : searchable) {
                if (app.pkg.contains("youtube")) continue;   // has its own row above
                results.addView(row(a, d, s, font, "Cari \"" + q + "\" dalam " + app.label, "Carian dalam app", app.pkg, 0,
                        () -> searchIn(a, app, q)));
            }
        };
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int st, int co, int af) { }
            @Override public void onTextChanged(CharSequence c, int st, int b, int co) { refresh.run(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        // Search/Enter on the keyboard: hand focus to the first result.
        input.setOnEditorActionListener((v, actionId, ev) -> {
            if (results.getChildCount() > 0 && results.getChildAt(0).isFocusable()) results.getChildAt(0).requestFocus();
            return true;
        });
        input.setOnKeyListener((v, code, ev) -> {
            if (ev.getAction() == KeyEvent.ACTION_DOWN && code == KeyEvent.KEYCODE_DPAD_DOWN && results.getChildCount() > 0) {
                results.getChildAt(0).requestFocus();
                return true;
            }
            return false;
        });

        d.setContentView(panel);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = Math.round(1000 * s);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = Math.round(90 * s);
            lp.dimAmount = 0.6f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        refresh.run();
        d.show();
        input.requestFocus();
    }

    private static List<App> installedApps(Activity a, PackageManager pm) {
        List<ResolveInfo> found = new ArrayList<>();
        found.addAll(pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0));
        found.addAll(pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0));
        Set<String> seen = new HashSet<>();
        Set<String> hidden = AppAdapter.userHidden(a);
        List<App> out = new ArrayList<>();
        for (ResolveInfo r : found) {
            if (r.activityInfo == null) continue;
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(a.getPackageName()) || hidden.contains(pkg) || !seen.add(pkg)) continue;
            out.add(new App(String.valueOf(r.loadLabel(pm)), pkg, r.activityInfo.name));
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private static List<App> searchableApps(Activity a, PackageManager pm) {
        Set<String> seen = new HashSet<>();
        List<App> out = new ArrayList<>();
        for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_SEARCH), 0)) {
            if (r.activityInfo == null) continue;
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(a.getPackageName()) || !seen.add(pkg)) continue;
            out.add(new App(String.valueOf(r.loadLabel(pm)), pkg, r.activityInfo.name));
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private static boolean looksLikeUrl(String q) {
        return !q.contains(" ") && (q.startsWith("http://") || q.startsWith("https://") || q.matches("(?i)[a-z0-9-]+(\\.[a-z0-9-]+)+(/.*)?"));
    }

    private static void launch(Activity a, PackageManager pm, App app) {
        Intent i = pm.getLeanbackLaunchIntentForPackage(app.pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(app.pkg);
        if (i == null) i = new Intent(Intent.ACTION_MAIN).setClassName(app.pkg, app.activity);
        start(a, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), "Tidak dapat buka " + app.label);
    }

    private static void playStore(Activity a, String q) {
        Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q) + "&c=apps"));
        if (market.resolveActivity(a.getPackageManager()) != null) { start(a, market, null); return; }
        view(a, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(q) + "&c=apps"), null, "Google Play tiada pada TV ini");
    }

    private static void youtube(Activity a, PackageManager pm, String q, List<App> searchable) {
        String[] tubes = {"com.google.android.youtube.tv", "com.google.android.youtube", "com.liskovsoft.smarttubetv.beta",
                "com.liskovsoft.smarttubetv", "com.teamsmart.videomanager.tv"};
        for (String pkg : tubes) {
            Intent search = new Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra("query", q);
            if (search.resolveActivity(pm) != null) { start(a, search, null); return; }
        }
        Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)));
        for (String pkg : tubes) {
            web.setPackage(pkg);
            if (web.resolveActivity(pm) != null) { start(a, web, null); return; }
        }
        web.setPackage(null);
        view(a, web.getData(), null, "YouTube tiada pada TV ini");
    }

    private static void searchIn(Activity a, App app, String q) {
        Intent i = new Intent(Intent.ACTION_SEARCH).setClassName(app.pkg, app.activity).putExtra("query", q);
        start(a, i, app.label + " tidak menerima carian");
    }

    private static void view(Activity a, Uri uri, String pkg, String fail) {
        Intent i = new Intent(Intent.ACTION_VIEW, uri);
        if (pkg != null) i.setPackage(pkg);
        start(a, i, fail);
    }

    private static void start(Activity a, Intent i, String fail) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(a, fail != null ? fail : "Tidak dapat dibuka", Toast.LENGTH_SHORT).show();
        }
    }

    private static TextView note(Activity a, float s, Typeface font, String text) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextColor(0x99FFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24 * s);
        t.setTypeface(font);
        t.setPadding(Math.round(20 * s), Math.round(16 * s), 0, 0);
        return t;
    }

    /** One result: icon (app icon or a glyph), title and a small kind label. Focused: white pill. */
    private static View row(Activity a, Dialog d, float s, Typeface font, String title, String kind, String iconPkg, int glyph, Runnable action) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true);
        row.setClickable(true);
        int ph = Math.round(18 * s), pv = Math.round(12 * s);
        row.setPadding(ph, pv, ph, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(26 * s);
        bg.setColor(0x00FFFFFF);
        row.setBackground(bg);
        ImageView icon = new ImageView(a);
        int is = Math.round(48 * s);
        if (glyph != 0 && iconPkg == null) {
            icon.setImageResource(glyph);
            icon.setColorFilter(Color.WHITE);
            int gp = Math.round(8 * s);
            icon.setPadding(gp, gp, gp, gp);
        } else if (iconPkg != null) {
            IconLoader.into(icon, iconPkg, null, is);
        }
        row.addView(icon, new LinearLayout.LayoutParams(is, is));
        TextView name = new TextView(a);
        name.setText(title);
        name.setTextColor(Color.WHITE);
        name.setTextSize(TypedValue.COMPLEX_UNIT_PX, 27 * s);
        name.setTypeface(font);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(0, -2, 1);
        np.leftMargin = Math.round(18 * s);
        row.addView(name, np);
        TextView tag = new TextView(a);
        tag.setText(kind);
        tag.setTextColor(0x99FFFFFF);
        tag.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20 * s);
        tag.setTypeface(font);
        row.addView(tag);
        row.setOnFocusChangeListener((v, f) -> {
            bg.setColor(f ? 0xFFFFFFFF : 0x00FFFFFF);
            name.setTextColor(f ? 0xFF14181F : Color.WHITE);
            tag.setTextColor(f ? 0x9914181F : 0x99FFFFFF);
            if (glyph != 0 && iconPkg == null) icon.setColorFilter(f ? 0xFF14181F : Color.WHITE);
        });
        row.setOnClickListener(v -> {
            SoundEffects.playSelect();
            d.dismiss();
            action.run();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Math.round(4 * s);
        row.setLayoutParams(lp);
        return row;
    }
}
