package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The small glass menu shown when OK is held on an app in the Hero, Pill or Material layouts:
 * Move (when the app can move) and App info. A plain Dialog, so focus and Back stay inside it on
 * every box without depending on the Classic grid's highlight.
 */
final class TileActionMenu {
    private TileActionMenu() { }

    static void show(Activity a, View anchor, String title, Runnable move, Runnable info) {
        show(a, anchor, title, null, move, info, null);
    }

    /** As above, with the Move row's text replaced (for example "Move to dock" from All Apps). */
    static void show(Activity a, View anchor, String title, String moveLabel, Runnable move, Runnable info, Runnable hide) {
        if (a.isFinishing()) return;
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        Typeface face;
        try { face = a.getResources().getFont(R.font.outfit); } catch (Exception e) { face = Typeface.DEFAULT; }

        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(14 * s);
        box.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF01B2028);
        bg.setCornerRadius(30 * s);
        bg.setStroke(Math.max(1, Math.round(1.5f * s)), 0x38FFFFFF);
        box.setBackground(bg);

        TextView head = new TextView(a);
        head.setText(title);
        head.setTextColor(0x99FFFFFF);
        head.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20 * s);
        head.setTypeface(face);
        head.setSingleLine(true);
        head.setEllipsize(android.text.TextUtils.TruncateAt.END);
        head.setPadding(Math.round(14 * s), Math.round(4 * s), Math.round(14 * s), Math.round(10 * s));
        box.addView(head);

        if (move != null) box.addView(row(a, d, s, face, R.drawable.ic_move,
                moveLabel != null ? moveLabel : a.getString(R.string.tile_move), move));
        box.addView(row(a, d, s, face, R.drawable.ic_info, a.getString(R.string.tile_app_info), info));
        if (hide != null) box.addView(row(a, d, s, face, R.drawable.ic_lock, "Sorok app", hide));

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            int width = Math.round(320 * s), edge = Math.round(24 * s), gap = Math.round(14 * s);
            box.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED);
            int height = box.getMeasuredHeight();
            int[] at = new int[2];
            anchor.getLocationOnScreen(at);
            int aw = Math.round(anchor.getWidth() * anchor.getScaleX());
            int ah = Math.round(anchor.getHeight() * anchor.getScaleY());
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.width = width;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.x = Math.max(edge, Math.min(at[0] + aw / 2 - width / 2, dm.widthPixels - width - edge));
            int below = at[1] + ah + gap;
            lp.y = below + height < dm.heightPixels - edge ? below : Math.max(edge, at[1] - gap - height);
            w.setAttributes(lp);
        }
        d.show();
        PanelMotion.openDialog(d, box, 0.90f);
    }

    private static View row(Activity a, Dialog d, float s, Typeface face, int icon, String text, Runnable action) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true);
        row.setClickable(true);
        int ph = Math.round(16 * s), pv = Math.round(12 * s);
        row.setPadding(ph, pv, ph, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(20 * s);
        bg.setColor(0x00FFFFFF);
        row.setBackground(bg);

        ImageView glyph = new ImageView(a);
        glyph.setImageResource(icon);
        glyph.setColorFilter(Color.WHITE);
        int g = Math.round(28 * s);
        row.addView(glyph, new LinearLayout.LayoutParams(g, g));

        TextView label = new TextView(a);
        label.setText(text);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 25 * s);
        label.setTypeface(face);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = Math.round(14 * s);
        row.addView(label, tp);

        row.setOnFocusChangeListener((v, f) -> {
            ChombbWidgets.springScale(v, f ? 1.035f : 1f, 320f, 0.79f);
            bg.setColor(f ? 0xFFFFFFFF : 0x00FFFFFF);
            glyph.setColorFilter(f ? 0xFF15191F : Color.WHITE);
            label.setTextColor(f ? 0xFF15191F : Color.WHITE);
        });
        row.setOnClickListener(v -> {
            SoundEffects.playSelect();
            d.dismiss();
            action.run();
        });
        row.setOnKeyListener((v, code, e) -> code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT);
        return row;
    }
}
