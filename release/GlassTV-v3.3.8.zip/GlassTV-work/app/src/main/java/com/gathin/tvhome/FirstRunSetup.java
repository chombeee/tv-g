package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Shown once, on a fresh install: a short tutorial in Malay, then the three permissions the launcher needs
 * (location, installing updates, notification access), each with its status. Can be reopened from
 * Preferences > About > Tutorial & Kebenaran.
 */
final class FirstRunSetup {
    private FirstRunSetup() { }

    interface Host {
        void requestLocation();
        void requestNotificationAccess();
        void onSetupFinished();
    }

    private static final String PREFS = "first_run", KEY_DONE = "done_v1";
    private static Runnable refreshShown;

    /** True on a fresh install that has not finished setup; an app updated over an older one is not asked. */
    static boolean shouldShow(Context c) {
        if (c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DONE, false)) return false;
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            if (pi.firstInstallTime != pi.lastUpdateTime) {
                markDone(c);
                return false;
            }
        } catch (Exception ignored) { }
        return true;
    }

    static void markDone(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DONE, true).apply();
    }

    /** Re-reads the permission ticks of an open setup screen (after a permission screen returns). */
    static void refresh() {
        if (refreshShown != null) refreshShown.run();
    }

    static boolean hasLocation(Context c) {
        return c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean canInstall(Context c) {
        return c.getPackageManager().canRequestPackageInstalls();
    }

    static void openInstallSettings(Activity a) {
        Intent[] tries = {
                new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())),
                new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES),
                new Intent(Settings.ACTION_SECURITY_SETTINGS),
        };
        for (Intent i : tries) {
            try {
                if (i.resolveActivity(a.getPackageManager()) == null) continue;
                a.startActivity(i);
                return;
            } catch (Exception ignored) { }
        }
        android.widget.Toast.makeText(a, "Buka Settings > Apps > Special app access > Install unknown apps, pilih GlassTV",
                android.widget.Toast.LENGTH_LONG).show();
    }

    static void show(Activity a, Host host) {
        if (a.isFinishing()) return;
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        final float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        Typeface face;
        try { face = a.getResources().getFont(R.font.outfit); } catch (Exception e) { face = Typeface.DEFAULT; }
        final Typeface font = face;

        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        final LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(48 * s);
        panel.setPadding(pad, Math.round(40 * s), pad, Math.round(36 * s));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF5151A22);
        bg.setCornerRadius(40 * s);
        bg.setStroke(Math.max(1, Math.round(1.5f * s)), 0x33FFFFFF);
        panel.setBackground(bg);
        d.setContentView(panel);

        final int[] page = {0};
        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            panel.removeAllViews();
            if (page[0] == 0) {
                panel.addView(text(a, font, s, "Selamat datang ke GlassTV", 52, Color.WHITE, 500));
                panel.addView(gap(a, s, 6));
                panel.addView(text(a, font, s, "Panduan ringkas sebelum mula", 24, 0x99FFFFFF, 400));
                panel.addView(gap(a, s, 24));
                String[][] tips = {
                        {"Gerak & buka", "Anak panah remote untuk bergerak, tekan OK untuk buka app."},
                        {"Tekan lama OK pada app", "Pindah susunan, Info App, atau Sorok app."},
                        {"Tukar rupa Home", "Preferences > Appearance > Home Layout: Classic, Hero, Pill atau Material."},
                        {"Widget", "Preferences > Widgets: Waktu Solat, Now Playing, Lirik, Kalendar, Baru Dibuka."},
                        {"Carian", "Butang carian: cari app, Google Play, YouTube dan laman web sekali gus."},
                        {"Butang Home", "Tekan sekali: screensaver. Tekan dua kali: app terbaru."},
                        {"Telefon", "Preferences > About > Backup & Restore: muat naik wallpaper, simpan dan pulihkan setting."},
                };
                for (String[] t : tips) panel.addView(tip(a, font, s, t[0], t[1]));
                panel.addView(gap(a, s, 26));
                LinearLayout bar = buttons(a);
                bar.addView(button(a, font, s, "Seterusnya  ›", true, () -> { page[0] = 1; render[0].run(); }));
                panel.addView(bar);
                bar.getChildAt(0).requestFocus();
            } else {
                panel.addView(text(a, font, s, "Benarkan akses", 52, Color.WHITE, 500));
                panel.addView(gap(a, s, 6));
                panel.addView(text(a, font, s, "Supaya semua fungsi berjalan. Boleh ubah kemudian di Preferences.", 24, 0x99FFFFFF, 400));
                panel.addView(gap(a, s, 24));
                View first = permission(a, font, s, "Lokasi", "Cuaca dan waktu solat ikut tempat anda secara automatik.",
                        hasLocation(a), host::requestLocation);
                panel.addView(first);
                panel.addView(permission(a, font, s, "Pasang kemas kini", "Benarkan GlassTV memasang versi baru (OTA).",
                        canInstall(a), () -> openInstallSettings(a)));
                panel.addView(permission(a, font, s, "Akses notifikasi", "Untuk Now Playing dan Lirik (Spotify, YouTube…).",
                        NowPlaying.hasAccess(a), host::requestNotificationAccess));
                panel.addView(gap(a, s, 26));
                LinearLayout bar = buttons(a);
                bar.addView(button(a, font, s, "‹  Kembali", false, () -> { page[0] = 0; render[0].run(); }));
                bar.addView(button(a, font, s, "Selesai", true, () -> {
                    markDone(a);
                    refreshShown = null;
                    d.dismiss();
                    host.onSetupFinished();
                }));
                panel.addView(bar);
                first.requestFocus();
            }
        };
        // Coming back from a permission screen: show the new ticks.
        refreshShown = () -> { if (d.isShowing() && page[0] == 1) render[0].run(); };
        panel.getViewTreeObserver().addOnWindowFocusChangeListener(has -> { if (has && page[0] == 1) render[0].run(); });

        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.width = Math.round(1180 * s);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            lp.dimAmount = 0.7f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        render[0].run();
        d.show();
    }

    // ---- small builders --------------------------------------------------------------------------------

    private static TextView text(Context c, Typeface font, float s, String value, float px, int color, int weight) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px * s);
        t.setTypeface(font);
        try { t.setFontVariationSettings("'wght' " + weight); } catch (Exception ignored) { }
        return t;
    }

    private static View gap(Context c, float s, int h) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, Math.round(h * s)));
        return v;
    }

    private static View tip(Context c, Typeface font, float s, String title, String body) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, Math.round(8 * s), 0, Math.round(8 * s));
        TextView dot = text(c, font, s, "•", 26, 0xFF9ECBFF, 700);
        row.addView(dot, new LinearLayout.LayoutParams(Math.round(30 * s), -2));
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c, font, s, title, 26, Color.WHITE, 600));
        col.addView(text(c, font, s, body, 22, 0xB3FFFFFF, 400));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        return row;
    }

    private static View permission(Context c, Typeface font, float s, String title, String body, boolean granted, Runnable ask) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setFocusable(true);
        row.setClickable(true);
        int ph = Math.round(22 * s), pv = Math.round(16 * s);
        row.setPadding(ph, pv, ph, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(28 * s);
        bg.setColor(0x14FFFFFF);
        row.setBackground(bg);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = text(c, font, s, title, 28, Color.WHITE, 600);
        TextView t2 = text(c, font, s, body, 21, 0xB3FFFFFF, 400);
        col.addView(t1);
        col.addView(t2);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        TextView state = text(c, font, s, granted ? "✓ Dibenarkan" : "Benarkan  ›", 23, granted ? 0xFF7EE2A8 : Color.WHITE, 600);
        row.addView(state);
        row.setOnFocusChangeListener((v, f) -> {
            bg.setColor(f ? 0xFFFFFFFF : 0x14FFFFFF);
            t1.setTextColor(f ? 0xFF14181F : Color.WHITE);
            t2.setTextColor(f ? 0x9914181F : 0xB3FFFFFF);
            state.setTextColor(f ? (granted ? 0xFF1F8A4C : 0xFF14181F) : (granted ? 0xFF7EE2A8 : Color.WHITE));
        });
        row.setOnClickListener(v -> { SoundEffects.playSelect(); ask.run(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Math.round(12 * s);
        row.setLayoutParams(lp);
        return row;
    }

    private static LinearLayout buttons(Context c) {
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.END);
        return bar;
    }

    private static View button(Context c, Typeface font, float s, String label, boolean primary, Runnable action) {
        TextView b = text(c, font, s, label, 26, primary ? 0xFF14181F : Color.WHITE, 600);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(Math.round(34 * s), Math.round(14 * s), Math.round(34 * s), Math.round(14 * s));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(40 * s);
        bg.setColor(primary ? 0xE6FFFFFF : 0x1FFFFFFF);
        bg.setStroke(Math.max(1, Math.round(3 * s)), 0x00FFFFFF);
        b.setBackground(bg);
        b.setOnFocusChangeListener((v, f) -> {
            bg.setStroke(Math.max(1, Math.round(3 * s)), f ? 0xFF9ECBFF : 0x00FFFFFF);
            v.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(140).start();
        });
        b.setOnClickListener(v -> { SoundEffects.playSelect(); action.run(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = Math.round(16 * s);
        b.setLayoutParams(lp);
        return b;
    }
}
