package com.gathin.tvhome;

import android.graphics.drawable.Drawable;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.PathInterpolator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Material-only dynamic palette cache. Artwork sampling never runs on the UI thread. */
final class MaterialStyle {
    static final PathInterpolator FAST_SPATIAL = new PathInterpolator(.42f,1.67f,.21f,.90f);
    static final PathInterpolator DEFAULT_SPATIAL = new PathInterpolator(.38f,1.21f,.22f,1f);
    static final PathInterpolator FAST_EFFECTS = new PathInterpolator(.31f,.94f,.34f,1f);
    static final PathInterpolator DEFAULT_EFFECTS = new PathInterpolator(.34f,.80f,.34f,1f);
    static final int FOCUS_MS=350, EFFECT_MS=150, RETINT_MS=200, SETTLE_MS=120;
    interface Listener { void onMaterialPalette(MaterialPalette palette); }
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String,Integer> seeds = new ConcurrentHashMap<>();
    private final Map<Integer,MaterialPalette> palettes = new ConcurrentHashMap<>();
    private final java.util.List<Listener> listeners = new java.util.ArrayList<>();
    private MaterialPalette current = MaterialPalette.of(MaterialPalette.DEFAULT_SEED);
    private String pendingPackage;
    private ValueAnimator transition;
    MaterialPalette current() { return current; }
    void addListener(Listener listener) { if(!listeners.contains(listener)) listeners.add(listener); listener.onMaterialPalette(current); }
    void removeListener(Listener listener) { listeners.remove(listener); }
    void focus(String pkg, Drawable art) {
        if(pkg==null) return;
        pendingPackage=pkg;
        Integer seed=seeds.get(pkg);
        if(seed!=null) { schedule(pkg, seed); return; }
        // Clone drawables on the main thread before processing them off-thread.
        Drawable.ConstantState cs=art==null?null:art.getConstantState();
        worker.execute(() -> {
            Drawable snapshot=cs==null?null:cs.newDrawable().mutate();
            int result=MaterialPalette.seedFrom(snapshot);
            seeds.put(pkg,result);
            ui.post(() -> schedule(pkg,result));
        });
    }
    private void schedule(String pkg,int seed) {
        if(!pkg.equals(pendingPackage)) return;
        ui.removeCallbacksAndMessages(null);
        ui.postDelayed(() -> {
            if(!pkg.equals(pendingPackage) || current.seed==seed) return;
            MaterialPalette next=palettes.get(seed);
            if(next==null) {next=MaterialPalette.of(seed);palettes.put(seed,next);}
            if (transition != null) transition.cancel();
            final MaterialPalette start=current;
            final MaterialPalette target=next;
            transition=ValueAnimator.ofFloat(0f,1f);
            transition.setDuration(RETINT_MS);
            transition.setInterpolator(DEFAULT_EFFECTS);
            transition.addUpdateListener(a -> {
                current=MaterialPalette.blend(start,target,(float)a.getAnimatedValue());
                for(Listener l:new java.util.ArrayList<>(listeners)) l.onMaterialPalette(current);
            });
            transition.start();
        }, SETTLE_MS);
    }
}
