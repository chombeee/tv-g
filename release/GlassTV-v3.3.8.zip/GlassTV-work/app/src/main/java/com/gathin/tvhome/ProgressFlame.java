package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/**
 * Now Playing progress bar with a living head: the bar fills with a light-to-amber gradient, a soft trail
 * follows the head, a glow breathes on it, and sparks are pushed out from behind the head, through it and
 * on ahead of it (past the end of the bar itself, into the padding above and below). It animates only while
 * a song is playing and sleeps when it is not.
 */
final class ProgressFlame extends View {
    private static final int MAX = 36;
    /** Bar styles: the flame (sparks rise above and below the bar) or a plain glowing head. */
    static final int STYLE_FLAME = 0, STYLE_GLOW = 1;
    private final int style;

    private final float s;
    private final float barH, pad;
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trail = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    // Particle state (struct of arrays; no per-particle objects).
    private final float[] px = new float[MAX], py = new float[MAX], vx = new float[MAX], vy = new float[MAX];
    private final float[] life = new float[MAX], maxLife = new float[MAX], size = new float[MAX];
    private final int[] tone = new int[MAX];
    private int alive = 0;

    private float shown, base;
    private long t0, last;
    private float rate;
    private boolean playing, running;
    private float spawnDebt;
    private final java.util.Random rnd = new java.util.Random();

    ProgressFlame(Context c, float scale) { this(c, scale, STYLE_FLAME); }

    ProgressFlame(Context c, float scale, int style) {
        super(c);
        s = scale;
        this.style = style == STYLE_GLOW ? STYLE_GLOW : STYLE_FLAME;
        barH = Math.max(3f, 4f * s);
        // The glow style never draws outside a small halo, so it needs far less room than the flame.
        pad = (this.style == STYLE_GLOW ? 22f : 24f) * s;
        track.setColor(0x33FFFFFF);
        glow.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        trail.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        spark.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
    }

    /** Extra height above and below the bar that the flame may use. */
    float padding() { return pad; }

    float barHeight() { return barH; }

    /** Sets where the song is. {@code durationMs} lets the head keep moving between updates. */
    void setProgress(float fraction, long durationMs, boolean isPlaying, boolean snap) {
        base = Math.max(0f, Math.min(1f, fraction));
        t0 = SystemClock.uptimeMillis();
        rate = isPlaying && durationMs > 0 ? 1f / durationMs : 0f;
        playing = isPlaying;
        if (snap || Math.abs(shown - base) > 0.06f) shown = base;
        wake();
    }

    private void wake() {
        if (!running && isAttachedToWindow()) {
            running = true;
            last = SystemClock.uptimeMillis();
            postOnAnimation(frame);
        }
        invalidate();
    }

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!isAttachedToWindow()) { running = false; return; }
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.05f, (now - last) / 1000f);
            last = now;
            float want = Math.min(1f, base + rate * (now - t0));
            shown += (want - shown) * Math.min(1f, dt * 8f);
            step(dt);
            invalidate();
            if (playing || alive > 0) postOnAnimation(this); else running = false;
        }
    };

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); wake(); }

    @Override protected void onDetachedFromWindow() { running = false; super.onDetachedFromWindow(); }

    private void step(float dt) {
        float w = getWidth();
        float headX = w * shown;
        float cy = getHeight() / 2f;
        // Spawn: sparks start behind the head and are shoved forward through it, fanning up and down.
        if (style == STYLE_FLAME && playing && shown > 0.002f) {
            spawnDebt += dt * 46f;
            while (spawnDebt >= 1f && alive < MAX) {
                spawnDebt -= 1f;
                int i = alive++;
                px[i] = headX - rnd.nextFloat() * 46f * s;
                py[i] = cy + (rnd.nextFloat() - 0.5f) * barH * 1.6f;
                vx[i] = (70f + rnd.nextFloat() * 150f) * s;
                vy[i] = (rnd.nextFloat() - 0.5f) * 120f * s - 18f * s;
                maxLife[i] = life[i] = 0.55f + rnd.nextFloat() * 0.7f;
                size[i] = (1.1f + rnd.nextFloat() * 2.4f) * s;
                float k = rnd.nextFloat();
                tone[i] = k < 0.25f ? 0xFFFFFFFF : k < 0.65f ? 0xFFFFD27A : 0xFFFF9A4D;
            }
            spawnDebt = Math.min(spawnDebt, 2f);
        }
        for (int i = 0; i < alive; ) {
            life[i] -= dt;
            if (life[i] <= 0f || px[i] > w + pad) {
                int l = --alive;
                px[i] = px[l]; py[i] = py[l]; vx[i] = vx[l]; vy[i] = vy[l];
                life[i] = life[l]; maxLife[i] = maxLife[l]; size[i] = size[l]; tone[i] = tone[l];
                continue;
            }
            vy[i] *= 1f - dt * 1.4f;
            vy[i] -= 22f * s * dt;           // sparks drift upward a little, like embers
            px[i] += vx[i] * dt;
            py[i] += vy[i] * dt;
            i++;
        }
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), cy = getHeight() / 2f;
        float top = cy - barH / 2f, bottom = cy + barH / 2f, rad = barH / 2f;
        r.set(0, top, w, bottom);
        c.drawRoundRect(r, rad, rad, track);
        float headX = Math.max(0f, Math.min(w, w * shown));
        if (headX <= 0.5f) return;

        fill.setShader(new LinearGradient(0, 0, Math.max(1f, headX), 0,
                new int[]{0x99FFFFFF, 0xFFFFFFFF, 0xFFFFE2A8}, new float[]{0f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        r.set(0, top, headX, bottom);
        c.drawRoundRect(r, rad, rad, fill);

        if (style == STYLE_GLOW) { drawGlowHead(c, headX, cy); return; }
        if (!playing && alive == 0) return;
        float tm = (SystemClock.uptimeMillis() % 100000) / 1000f;
        float flick = 0.88f + 0.12f * (float) Math.sin(tm * 11f) + 0.05f * (float) Math.sin(tm * 23f);

        // Trail: a soft amber wake behind the head, taller than the bar.
        float tl = Math.min(headX, 110f * s);
        trail.setShader(new LinearGradient(headX - tl, 0, headX, 0, 0x00FFB45A, 0x88FFB45A, Shader.TileMode.CLAMP));
        r.set(headX - tl, cy - barH * 1.3f, headX, cy + barH * 1.3f);
        c.drawRoundRect(r, barH, barH, trail);

        // Head glow, breathing.
        float gr = 26f * s * flick;
        glow.setShader(new RadialGradient(headX, cy, gr, new int[]{0xDDFFE7B0, 0x55FFA24A, 0x00FF9A4D},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(headX, cy, gr, glow);

        // Flame tongue: a short teardrop flickering forward of the head.
        float fl = (10f + 8f * (float) Math.sin(tm * 17f)) * s;
        glow.setShader(new RadialGradient(headX + fl * 0.4f, cy, Math.max(2f, fl + 6f * s),
                new int[]{0xCCFFFFFF, 0x66FFC070, 0x00FF9A4D}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(headX + fl * 0.4f, cy, Math.max(2f, fl + 6f * s), glow);

        for (int i = 0; i < alive; i++) {
            float k = life[i] / maxLife[i];
            int a = Math.max(0, Math.min(255, Math.round(255 * k * k + 30 * k)));
            spark.setColor((tone[i] & 0x00FFFFFF) | (a << 24));
            c.drawCircle(px[i], py[i], Math.max(0.6f, size[i] * (0.4f + 0.6f * k)), spark);
        }
    }

    /** Bar end for the glow style: a soft halo that breathes while playing, and a bright dot on the end. */
    private void drawGlowHead(Canvas c, float headX, float cy) {
        float breathe = 1f;
        if (playing) {
            float tm = (SystemClock.uptimeMillis() % 100000) / 1000f;
            breathe = 0.5f + 0.5f * (float) Math.sin(tm * 3.2f);   // slow, ~2 s per breath
        }
        float gr = (15f + 6f * breathe) * s;
        int a = Math.round(0x66 + 0x44 * breathe);
        glow.setShader(new RadialGradient(headX, cy, gr,
                new int[]{(a << 24) | 0xFFFFFF, ((a / 3) << 24) | 0xFFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(headX, cy, gr, glow);
        spark.setColor(0xFFFFFFFF);
        c.drawCircle(headX, cy, barH * 0.9f, spark);
    }
}
