package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Backup and restore of the launcher's settings: layout, widgets, app order, hidden apps, wallpaper and
 * screensaver choices. Every SharedPreferences file is written out with each value's type, except caches
 * that the launcher rebuilds by itself (weather, prayer times, timestamps).
 */
final class SettingsBackup {
    private SettingsBackup() { }

    static final int VERSION = 1;

    private static boolean skipped(String name) {
        String n = name.toLowerCase(java.util.Locale.ROOT);
        return n.contains("cache") || n.equals("launch") || n.startsWith("com.google") || n.startsWith("webview");
    }

    static String export(Context c) throws Exception {
        JSONObject root = new JSONObject();
        root.put("app", "GlassTV");
        root.put("version", VERSION);
        root.put("created", System.currentTimeMillis());
        JSONObject files = new JSONObject();
        File dir = new File(c.getApplicationInfo().dataDir, "shared_prefs");
        File[] list = dir.listFiles();
        if (list != null) {
            for (File f : list) {
                String file = f.getName();
                if (!file.endsWith(".xml")) continue;
                String name = file.substring(0, file.length() - 4);
                if (skipped(name)) continue;
                JSONObject values = new JSONObject();
                for (Map.Entry<String, ?> e : c.getSharedPreferences(name, Context.MODE_PRIVATE).getAll().entrySet()) {
                    Object v = e.getValue();
                    JSONObject item = new JSONObject();
                    if (v instanceof Boolean) item.put("t", "b");
                    else if (v instanceof Integer) item.put("t", "i");
                    else if (v instanceof Long) item.put("t", "l");
                    else if (v instanceof Float) { item.put("t", "f"); v = ((Float) v).doubleValue(); }
                    else if (v instanceof String) item.put("t", "s");
                    else if (v instanceof Set) {
                        item.put("t", "set");
                        JSONArray arr = new JSONArray();
                        for (Object o : (Set<?>) v) arr.put(String.valueOf(o));
                        v = arr;
                    } else continue;
                    item.put("v", v);
                    values.put(e.getKey(), item);
                }
                files.put(name, values);
            }
        }
        root.put("prefs", files);
        return root.toString(2);
    }

    /** Applies a backup. Returns how many settings were restored; throws when the file is not a backup. */
    static int restore(Context c, String json) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!"GlassTV".equals(root.optString("app"))) throw new IllegalArgumentException("Bukan fail backup GlassTV");
        JSONObject files = root.getJSONObject("prefs");
        int count = 0;
        Iterator<String> names = files.keys();
        while (names.hasNext()) {
            String name = names.next();
            if (skipped(name)) continue;
            JSONObject values = files.getJSONObject(name);
            SharedPreferences.Editor ed = c.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear();
            Iterator<String> keys = values.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                JSONObject item = values.getJSONObject(key);
                switch (item.optString("t")) {
                    case "b": ed.putBoolean(key, item.getBoolean("v")); break;
                    case "i": ed.putInt(key, item.getInt("v")); break;
                    case "l": ed.putLong(key, item.getLong("v")); break;
                    case "f": ed.putFloat(key, (float) item.getDouble("v")); break;
                    case "s": ed.putString(key, item.getString("v")); break;
                    case "set": {
                        JSONArray arr = item.getJSONArray("v");
                        Set<String> set = new HashSet<>();
                        for (int i = 0; i < arr.length(); i++) set.add(arr.getString(i));
                        ed.putStringSet(key, set);
                        break;
                    }
                    default: continue;
                }
                count++;
            }
            ed.commit();
        }
        return count;
    }
}
