package com.gathin.tvhome;

import android.content.Context;

/**
 * Preferences > Appearance > Glass Transparency, applied to the glass of every layout: Classic's blurred
 * pills and panels, Hero's capsules, the Pill dock, widgets and menus. 70% is the original look; lower is
 * more solid, higher is clearer (100% leaves only the edges).
 */
final class GlassStyle {
    private GlassStyle() { }

    static final int DEFAULT = 70, MIN = 25, MAX = 100;
    /** Multiplier for glass alpha; 1 at the default. Read while drawing, so kept in a field. */
    static volatile float factor = 1f;

    static int level(Context c) {
        int v = c.getSharedPreferences("chombb_appearance", Context.MODE_PRIVATE).getInt("glass_transparency", DEFAULT);
        return Math.max(MIN, Math.min(MAX, v));
    }

    /** Reloads the level; call at startup and after the setting changes. */
    static void load(Context c) {
        factor = (100 - level(c)) / (float) (100 - DEFAULT);
    }

    /** {@code argb} with its alpha scaled to the user's glass level. */
    static int tint(int argb) {
        int a = Math.round((argb >>> 24) * factor);
        a = Math.max(0, Math.min(255, a));
        return (argb & 0x00FFFFFF) | (a << 24);
    }
}
