package com.gathin.tvhome;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;

import java.util.List;

/**
 * Finds the media session worth showing (Spotify, YouTube...): one that is playing, else the first.
 * Android only shares media sessions with an app that has Notification Access.
 */
final class NowPlaying {
    private NowPlaying() { }

    static ComponentName listener(Context c) { return new ComponentName(c, ChombbMediaListener.class); }

    /** The adb command that grants access on TVs whose Settings have no Notification Access screen. */
    static String adbGrant(Context c) {
        return "adb shell cmd notification allow_listener " + listener(c).flattenToString();
    }

    static boolean hasAccess(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && android.os.Build.VERSION.SDK_INT >= 27) return nm.isNotificationListenerAccessGranted(listener(c));
        } catch (Exception ignored) { }
        String listeners = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return listeners != null && listeners.contains(listener(c).flattenToString());
    }

    /**
     * Grants Notification Access to ourselves when the launcher holds WRITE_SECURE_SETTINGS (given once over
     * adb: pm grant com.faris.glasstv android.permission.WRITE_SECURE_SETTINGS). Returns whether access is on.
     */
    static boolean ensureAccess(Context c) {
        if (hasAccess(c)) return true;
        if (c.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) != PackageManager.PERMISSION_GRANTED) return false;
        try {
            String me = listener(c).flattenToString();
            String now = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
            String next = now == null || now.isEmpty() ? me : now + ":" + me;
            Settings.Secure.putString(c.getContentResolver(), "enabled_notification_listeners", next);
            NotificationListenerService.requestRebind(listener(c));
        } catch (Exception ignored) { }
        return hasAccess(c);
    }

    /** Opens the system screen for Notification Access; false when this TV has no such screen. */
    static boolean openSettings(Context c) {
        android.content.Intent[] tries = {
                new android.content.Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
                new android.content.Intent("android.settings.NOTIFICATION_LISTENER_SETTINGS"),
                new android.content.Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + c.getPackageName())),
        };
        for (android.content.Intent i : tries) {
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                if (i.resolveActivity(c.getPackageManager()) == null) continue;
                c.startActivity(i);
                return i.getAction() != null && !i.getAction().equals(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            } catch (Exception ignored) { }
        }
        return false;
    }

    static MediaController active(Context c) {
        try {
            MediaSessionManager mgr = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (mgr == null) return null;
            List<MediaController> sessions = mgr.getActiveSessions(listener(c));
            if (sessions == null || sessions.isEmpty()) return null;
            MediaController withTrack = null;
            for (MediaController m : sessions) {
                PlaybackState s = m.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) return m;
                if (withTrack == null && m.getMetadata() != null) withTrack = m;
            }
            // Paused: prefer a session that still holds a song over an empty one.
            return withTrack != null ? withTrack : sessions.get(0);
        } catch (Exception e) {      // SecurityException when Notification Access is not granted
            return null;
        }
    }

    /** Current position in ms, moved on from the last report while playing. */
    static long position(MediaController m) {
        return positionOf(m.getPlaybackState());
    }

    static long positionOf(PlaybackState s) {
        if (s == null) return 0;
        long p = s.getPosition();
        if (s.getState() == PlaybackState.STATE_PLAYING) {
            p += Math.round((android.os.SystemClock.elapsedRealtime() - s.getLastPositionUpdateTime()) * s.getPlaybackSpeed());
        }
        return Math.max(0, p);
    }
}
