package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.TextView;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak"};
    private static final int[] ACCENTS = {0xFFFF7622, 0xFFFFCA56, 0xFF56E4FF, 0xFF5AAEFF};
    private final Paint splash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path drop = new Path();
    private PlaybackState playback;
    private long effectsAfter, start, end;
    private boolean compact;
    private int style;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (!TextUtils.equals(getText(), text)) setText(text);
        this.style = style;
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && hasWindowFocus() && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        boolean active = playing && position >= start && position < end;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();
        if (active && now >= effectsAfter && layout != null) {
            float progress = (position - start) / (float) (end - start);
            drawSweep(canvas, layout, progress, now);
        } else {
            super.onDraw(canvas);
        }
        if (active) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private void drawSweep(Canvas canvas, Layout layout, float progress, long now) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            applySweep(paint, x, width, edge, remaining, now);
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if ((style == 0 || style == 3) && remaining >= 0f && remaining < width) {
                drawSplash(canvas, left + edge, top + layout.getLineBaseline(i),
                        (float) (totalWidth * 1000.0 / (end - start)), now, style == 3);
            }
            remaining -= width;
        }
    }

    private void applySweep(Paint paint, float x, float width, float edge, float remaining, long now) {
        float size = getTextSize();
        int accent = ACCENTS[style];
        if (style == 2) {
            float pulse = (float) Math.sin(now * 0.003);
            paint.setShader(new LinearGradient(edge - size * 1.4f, 0, edge + size * 1.4f, 0,
                    new int[]{accent, 0xFFFFFFFF, accent}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(size * ((compact ? 0.075f : 0.12f) + 0.025f * pulse), 0, 0, 0xB600C7FF);
        } else if (remaining >= width) {
            paint.setShader(new LinearGradient(x, 0, x + width, 0, accent,
                    style == 0 ? 0xFFFFA832 : accent, Shader.TileMode.CLAMP));
        } else if (remaining >= 0f) {
            if (style == 3) {
                float ripple = (float) Math.sin(now * .016) * size * .32f;
                paint.setShader(new LinearGradient(edge - size * 1.8f, -size, edge + size * .6f + ripple, 0,
                        new int[]{0xFF1E7BCB, 0xFF43C9F6, 0xFF217FCD, 0xFF79E5FF, 0xFFF0FCFF, getCurrentTextColor()},
                        new float[]{0f, .28f, .46f, .68f, .82f, 1f}, Shader.TileMode.CLAMP));
            } else if (style == 1) {
                float gleam = (float) Math.sin(now * .013) * size * .15f;
                paint.setShader(new LinearGradient(edge - size * 1.9f, 0, edge + size * .45f + gleam, size * .45f,
                        new int[]{0xFFF1A824, 0xFFFEDD7B, 0xFFBD7413, 0xFFFFD565, 0xFFFFFBCE, getCurrentTextColor()},
                        new float[]{0f, .30f, .48f, .63f, .80f, 1f}, Shader.TileMode.CLAMP));
            } else {
                float band = size * (compact ? 1.12f : 1.65f);
                paint.setShader(new LinearGradient(edge - band, 0, edge + band * .24f, 0,
                        new int[]{accent, 0xFFFFA832, 0xFFFFF1C4, getCurrentTextColor()},
                        new float[]{0f, .40f, .81f, 1f}, Shader.TileMode.CLAMP));
                paint.setShadowLayer(size * (compact ? .08f : .13f), 0, 0, 0x90FF6715);
            }
        }
    }

    /**
     * Like the Now Playing bar, the moving head emits particles forward through the fill,
     * above and below the row. Water adds gravity, stretched droplets and white reflections.
     */
    private void drawSplash(Canvas canvas, float head, float baseline, float sweepSpeed, long now, boolean water) {
        float size = getTextSize();
        float centerY = baseline - size * .44f;
        float pulse = .86f + .14f * (float) Math.sin((now % 10000L) * .018);
        float halo = size * (compact ? .62f : .81f) * pulse;
        splash.setShader(new RadialGradient(head, centerY, halo,
                water ? new int[]{0xB9ECFCFF, 0x6043C9FF, 0x00217FCD}
                        : new int[]{0xB9FFF2C8, 0x67FF9D3C, 0x00FF7622},
                new float[]{0f, .40f, 1f}, Shader.TileMode.CLAMP));
        splash.setAlpha(255);
        canvas.drawCircle(head, centerY, halo, splash);
        splash.setShader(null);

        int count = compact ? 10 : 12;
        for (int i = 0; i < count; i++) {
            long period = 410L + (i * 83L) % 215L;
            float elapsed = ((now + 83L * i) % period) / 1000f;
            float phase = elapsed * 1000f / period;
            float direction = (i % 4 == 0) ? 1f : -1f;
            float speedX = size * (1.70f + ((i * 7) % 11) * .31f);
            float speedY = size * (.48f + ((i * 11) % 7) * .22f) * direction;
            float gravity = size * (water ? 5.6f : -.9f);
            float x = head - size * (.08f + i % 4 * .21f) + (speedX - sweepSpeed * .25f) * elapsed;
            float y = centerY + speedY * elapsed + gravity * elapsed * elapsed * .5f;
            float radius = size * (.050f + ((i * 5) % 7) * .010f) * (1f - .5f * phase);
            if (x + radius < 0f || x - radius > getWidth()
                    || y + radius < 0f || y - radius > getHeight()) continue;
            float opacity = (1f - phase) * (1f - phase);
            if (water) {
                drawDroplet(canvas, x, y, radius, speedX, speedY + gravity * elapsed, opacity, i);
            } else {
                splash.setColor(i % 4 == 0 ? 0xFFFFF2BD : 0xFFFF8D35);
                splash.setAlpha(Math.round(105f * opacity));
                canvas.drawCircle(x, y, radius * 1.75f, splash);
                splash.setColor(i % 3 == 0 ? 0xFFFFF7DA : 0xFFFFBC64);
                splash.setAlpha(Math.round(255f * opacity));
                canvas.drawCircle(x, y, radius, splash);
            }
        }
    }

    private void drawDroplet(Canvas canvas, float x, float y, float radius, float vx, float vy, float opacity, int index) {
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.rotate((float) Math.toDegrees(Math.atan2(vy, vx)));
        drop.rewind();
        drop.moveTo(-radius * 2.5f, 0f);
        drop.cubicTo(-radius, -radius * .30f, -.3f * radius, -radius, radius * .5f, -radius);
        drop.cubicTo(radius * 2f, -radius, radius * 2f, radius, radius * .5f, radius);
        drop.cubicTo(-.3f * radius, radius, -radius, radius * .30f, -radius * 2.5f, 0f);
        drop.close();
        splash.setColor(index % 3 == 0 ? 0xFF8BEBFF : 0xFF35BBF4);
        splash.setAlpha(Math.round(235f * opacity));
        canvas.drawPath(drop, splash);
        splash.setColor(0xFFF5FFFF);
        splash.setAlpha(Math.round(245f * opacity));
        canvas.drawOval(0f, -radius * .67f, radius * 1.05f, -radius * .18f, splash);
        canvas.restoreToCount(saved);
    }
}
