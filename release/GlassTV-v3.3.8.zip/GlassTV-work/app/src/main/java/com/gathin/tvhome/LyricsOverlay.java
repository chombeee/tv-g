package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.drawable.ColorDrawable;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Expanded lyrics card with a spring transition from its home widget. */
final class LyricsOverlay {
    private LyricsOverlay() { }

    private static final long GAP_FOR_DOTS_MS = 9000, DOTS_AFTER_MS = 5500;

    /** One entry of the column: a lyric line or an instrumental gap. */
    private static final class Line {
        final long start;
        final String text;
        final boolean dots;
        TextView view;
        Line(long start, String text, boolean dots) { this.start = start; this.text = text; this.dots = dots; }
    }

    /** Set while the lyrics card is open: folds it back into its widget. */
    private static Runnable current;

    /** Closes the lyrics card if it is open (Home pressed). Returns true when there was one. */
    static boolean closeIfShowing() {
        Runnable c = current;
        if (c == null) return false;
        c.run();
        return true;
    }

    static void show(Activity a) { show(a, null); }

    /** Opens the lyrics by growing out of {@code source} (the widget card) to full screen; Back folds it back. */
    static void show(Activity a, View source) {
        if (a.isFinishing() || current != null) return;
        final int[] srcLoc = new int[2];
        final int[] srcSize = {0, 0};
        float srcRadius = 0f;
        if (source != null && source.getWidth() > 0) {
            source.getLocationOnScreen(srcLoc);
            srcSize[0] = source.getWidth();
            srcSize[1] = source.getHeight();
            srcRadius = 28f * a.getResources().getDisplayMetrics().density;
        }
        final float cardRadius = srcRadius;
        DisplayMetrics dm = a.getResources().getDisplayMetrics();
        final float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f) * 0.78f;
        final int screenW = dm.widthPixels, screenH = dm.heightPixels;
        final int cardW = Math.round(screenW * 0.78f), cardH = Math.round(screenH * 0.80f);
        Typeface face;
        try { face = a.getResources().getFont(R.font.outfit); } catch (Exception e) { face = Typeface.DEFAULT; }
        final Typeface font = face;

        final Dialog d = new Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        final FrameLayout stage = new FrameLayout(a);
        final FrameLayout root = new FrameLayout(a);
        // Behind the card: the real launcher, only darkened a little. No blur.
        final View veil0 = new View(a);
        veil0.setBackgroundColor(0x3B000000);
        final FrameLayout scrimBox = new FrameLayout(a);
        scrimBox.addView(veil0, new FrameLayout.LayoutParams(-1, -1));
        scrimBox.setAlpha(0f);
        stage.addView(scrimBox, new FrameLayout.LayoutParams(-1, -1));
        root.setBackgroundColor(0xFF0B0E13);
        final float[] radius = {0f};
        root.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Math.max(0f, radius[0])); }
        });
        root.setClipToOutline(true);
        root.setPivotX(0f);
        root.setPivotY(0f);

        final int neutral = 0xFF0B0E13;
        final GradientDrawable background = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{neutral, neutral});
        root.setBackground(background);

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int side = Math.round(100 * s);
        row.setPadding(side, 0, Math.round(70 * s), 0);
        root.addView(row, new FrameLayout.LayoutParams(-1, -1));

        // Left: art, song, progress, hint
        LinearLayout left = new LinearLayout(a);
        left.setOrientation(LinearLayout.VERTICAL);
        final ImageView art = new ImageView(a);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        final float r = 26 * s;
        art.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r); }
        });
        art.setClipToOutline(true);
        GradientDrawable artBg = new GradientDrawable();
        artBg.setColor(0x26FFFFFF);
        artBg.setCornerRadius(r);
        art.setBackground(artBg);
        art.setElevation(24 * s);
        int as = Math.round(400 * s);
        left.addView(art, new LinearLayout.LayoutParams(as, as));
        final TextView title = text(a, font, s, 40, Color.WHITE, 700);
        final TextView artist = text(a, font, s, 28, 0xB3FFFFFF, 450);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(as, -2);
        tl.topMargin = Math.round(28 * s);
        left.addView(title, tl);
        left.addView(artist, new LinearLayout.LayoutParams(as, -2));
        FrameLayout track = new FrameLayout(a);
        GradientDrawable tb = new GradientDrawable();
        tb.setColor(0x33FFFFFF);
        tb.setCornerRadius(4 * s);
        track.setBackground(tb);
        final View progress = new View(a);
        GradientDrawable pb = new GradientDrawable();
        pb.setColor(Color.WHITE);
        pb.setCornerRadius(4 * s);
        progress.setBackground(pb);
        progress.setPivotX(0f);
        progress.setScaleX(0f);
        track.addView(progress, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams trl = new LinearLayout.LayoutParams(as, Math.max(3, Math.round(6 * s)));
        trl.topMargin = Math.round(22 * s);
        left.addView(track, trl);
        TextView hint = text(a, font, s, 19, 0x80FFFFFF, 400);
        hint.setSingleLine(false);
        hint.setText("OK  main / jeda     ◀ ▶  lagu     Back  tutup");
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(as, -2);
        hl.topMargin = Math.round(26 * s);
        left.addView(hint, hl);
        row.addView(left, new LinearLayout.LayoutParams(as, -2));

        // Right: the column of lines, clipped to its window and moved by translation only.
        final FrameLayout viewport = new FrameLayout(a);
        viewport.setClipChildren(true);
        // Measured at its full height (a whole song), not cut to the window; the window clips and it slides.
        final LinearLayout column = new LinearLayout(a) {
            @Override protected void onMeasure(int widthSpec, int heightSpec) {
                super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            }
        };
        column.setOrientation(LinearLayout.VERTICAL);
        viewport.addView(column, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        final TextView message = text(a, font, s, 44, 0xCCFFFFFF, 650);
        message.setSingleLine(false);
        message.setMaxLines(16);
        viewport.addView(message, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL));
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(0, -1, 1);
        vl.leftMargin = Math.round(110 * s);
        row.addView(viewport, vl);

        stage.addView(root, new FrameLayout.LayoutParams(cardW, cardH, Gravity.CENTER));
        d.setContentView(stage);
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setDimAmount(0f);
        }

        final Handler ui = new Handler(Looper.getMainLooper());
        final List<Line> lines = new ArrayList<>();
        final String[] shownSong = {null};
        final String[] builtFor = {null};
        final int[] active = {-2};
        final SpringAnimation scroll = new SpringAnimation(column, DynamicAnimation.TRANSLATION_Y);
        final int dimPast = 0xB3FFFFFF;

        final Runnable[] buildColumn = new Runnable[1];
        buildColumn[0] = () -> {
            scroll.cancel();
            column.removeAllViews();
            lines.clear();
            String[] texts = ChombbWidgets.syncedLines();
            long[] times = ChombbWidgets.syncedTimes();
            if (texts == null || times == null || times.length != texts.length) return;
            if (times.length > 0 && times[0] > 3000) lines.add(new Line(0, "• • •", true));
            for (int i = 0; i < texts.length; i++) {
                lines.add(new Line(times[i], texts[i], false));
                if (i + 1 < texts.length && times[i + 1] - times[i] > GAP_FOR_DOTS_MS)
                    lines.add(new Line(times[i] + DOTS_AFTER_MS, "• • •", true));
            }
            for (Line ln : lines) {
                TextView t = formatText(new LyricLineView(a), font, s, ln.dots ? 46 : 58, Color.WHITE, 750);
                t.setSingleLine(false);
                t.setMaxLines(3);
                ((LyricLineView) t).show(ln.text, ChombbWidgets.lyricStyle(a), null, 0L, 0L);
                t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
                t.setPivotX(0f);
                t.setPadding(Math.round(12 * s), Math.round(27 * s), Math.round(12 * s), Math.round(16 * s));
                column.addView(t, new LinearLayout.LayoutParams(-1, -2));
                ln.view = t;
            }
            column.setTranslationY(viewport.getHeight() * 0.33f);
        };

        scroll.setSpring(new androidx.dynamicanimation.animation.SpringForce()
                .setStiffness(175f).setDampingRatio(0.95f));

        final Runnable tick = new Runnable() {
            @Override public void run() {
                if (!d.isShowing()) return;
                MediaController m = NowPlaying.active(a);
                MediaMetadata md = m == null ? null : m.getMetadata();
                if (md == null) {
                    if (active[0] != -3) {
                        active[0] = -3;
                        shownSong[0] = null;
                        title.setText(NowPlaying.hasAccess(a) ? "Tiada lagu dimainkan" : "Perlu Notification Access");
                        artist.setText("");
                        art.setImageDrawable(null);
                        background.setColors(new int[]{neutral, neutral});
                        scroll.cancel();
                        column.removeAllViews();
                        lines.clear();
                        message.setVisibility(View.VISIBLE);
                        message.setText("Mainkan lagu di Spotify atau YouTube Music");
                    }
                    ui.postDelayed(this, 800);
                    return;
                }
                String t = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                String ar = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                String key = t + "|" + ar;
                if (!key.equals(shownSong[0])) {
                    shownSong[0] = key;
                    builtFor[0] = null;
                    active[0] = -2;
                    title.setText(t == null ? "" : t);
                    artist.setText(ar == null ? "" : ar);
                    Bitmap b = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (b == null) b = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                    art.setImageBitmap(b);
                    int tint = b == null ? 0 : ChombbWidgets.artTint(b);
                    background.setColors(new int[]{tint == 0 ? neutral : tint | 0xFF000000, neutral});
                    scroll.cancel();
                    column.removeAllViews();
                    lines.clear();
                    ChombbWidgets.requestFor(m);
                }
                long dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
                PlaybackState playback = m.getPlaybackState();
                long pos = NowPlaying.positionOf(playback);
                progress.setScaleX(dur > 0 ? Math.min(1f, pos / (float) dur) : 0f);

                String[] synced = ChombbWidgets.syncedLines();
                if (ChombbWidgets.lyricsLoading()) {
                    message.setVisibility(View.VISIBLE);
                    message.setText("Mencari lirik…");
                } else if (synced == null) {
                    String plain = ChombbWidgets.plainLyrics();
                    message.setVisibility(View.VISIBLE);
                    message.setTextSize(TypedValue.COMPLEX_UNIT_PX, (plain.isEmpty() ? 44 : 32) * s);
                    message.setText(plain.isEmpty() ? "Lirik tiada untuk lagu ini" : plain);
                } else {
                    message.setVisibility(View.GONE);
                    String sig = shownSong[0] + "#" + synced.length;
                    if (!sig.equals(builtFor[0]) && viewport.getHeight() > 0) {
                        builtFor[0] = sig;
                        buildColumn[0].run();
                        active[0] = -2;
                    }
                    int now = -1;
                    for (int i = 0; i < lines.size(); i++) {
                        if (lines.get(i).start > pos) break;
                        now = i;
                    }
                    if (now != active[0] && column.getChildCount() > 0 && column.getChildAt(0).getHeight() > 0) {
                        int previous = active[0];
                        if (previous >= 0 && previous < lines.size()) {
                            Line old = lines.get(active[0]);
                            ((LyricLineView) old.view).show(old.text, ChombbWidgets.lyricStyle(a), null, 0L, 0L);
                            old.view.setTextColor(Color.WHITE);
                            old.view.animate().alpha(0.72f).scaleX(0.96f).scaleY(0.96f).setDuration(340).start();
                        }
                        active[0] = now;
                        for (int i = 0; i < lines.size(); i++) {
                            View lyric = lines.get(i).view;
                            if (i != now - 1 || lyric.getAlpha() != 1f) {
                                lyric.animate().cancel();
                                lyric.setAlpha(i < now ? 0.72f : 1f);
                                lyric.setScaleX(i < now ? 0.96f : 1f);
                                lyric.setScaleY(i < now ? 0.96f : 1f);
                            }
                        }
                        if (now >= 0) {
                            LyricLineView line = (LyricLineView) lines.get(now).view;
                            if (previous >= 0 && now == previous + 1 && !lines.get(previous).dots && !lines.get(now).dots
                                    && playback != null && playback.getState() == PlaybackState.STATE_PLAYING) {
                                line.waitForSlide(200L);
                            }
                            scroll.animateToFinalPosition(viewport.getHeight() * 0.33f
                                    - (line.getTop() + line.getHeight() / 2f));
                        }
                    }
                    if (active[0] >= 0 && active[0] < lines.size()) {
                        Line line = lines.get(active[0]);
                        long next = active[0] + 1 < lines.size() ? lines.get(active[0] + 1).start : dur;
                        long end = ChombbWidgets.lineEnd(line.start, next);
                        line.view.setTextColor(!line.dots && pos >= end ? dimPast : Color.WHITE);
                        ((LyricLineView) line.view).show(line.text, ChombbWidgets.lyricStyle(a),
                                line.dots ? null : playback, line.start, end);
                    }
                }
                ui.postDelayed(this, 90);
            }
        };

        final boolean[] closing = {false};
        final SpringAnimation[] morphSpring = {null};
        final float[] morphP = {0f};
        final Runnable[] closeMorph = new Runnable[1];
        final FloatPropertyCompat<View> progressProp = new FloatPropertyCompat<View>("morph") {
            @Override public float getValue(View v) { return morphP[0]; }
            @Override public void setValue(View v, float p) {
                morphP[0] = p;
                float W = Math.max(1, root.getWidth()), H = Math.max(1, root.getHeight());
                boolean fromCard = srcSize[0] > 0;
                float fx = fromCard ? srcSize[0] / W : 0.86f, fy = fromCard ? srcSize[1] / H : 0.86f;
                float sx = fx + (1f - fx) * p, sy = fy + (1f - fy) * p;
                float x0 = fromCard ? srcLoc[0] - root.getLeft() : W * 0.07f, y0 = fromCard ? srcLoc[1] - root.getTop() : H * 0.07f;
                root.setScaleX(sx);
                root.setScaleY(sy);
                root.setTranslationX(x0 * (1f - p));
                root.setTranslationY(y0 * (1f - p));
                scrimBox.setAlpha(Math.max(0f, Math.min(1f, p)));
                float rr = (fromCard ? cardRadius : 40f * s) + (44f * s - (fromCard ? cardRadius : 40f * s)) * Math.min(1f, p);
                radius[0] = rr / Math.max(0.2f, Math.min(sx, sy));
                root.invalidateOutline();
                float ca = Math.max(0f, Math.min(1f, (p - 0.3f) / 0.6f));
                row.setAlpha(ca);
                root.setAlpha(Math.max(0f, Math.min(1f, p * 6f)));
            }
        };
        closeMorph[0] = () -> {
            if (closing[0]) return;
            closing[0] = true;
            if (morphSpring[0] != null) morphSpring[0].cancel();
            SpringAnimation sp = new SpringAnimation(root, progressProp, 0f);
            sp.getSpring().setStiffness(260f);
            sp.getSpring().setDampingRatio(1f);
            sp.setStartValue(morphP[0]);
            sp.setMinimumVisibleChange(0.002f);
            sp.addEndListener((an, canceled, val, vel) -> { if (d.isShowing()) d.dismiss(); });
            sp.start();
        };
        stage.setOnClickListener(v -> closeMorph[0].run());
        current = () -> closeMorph[0].run();
        d.setOnKeyListener((dialog, code, ev) -> {
            if (code == KeyEvent.KEYCODE_HOME || code == KeyEvent.KEYCODE_ALL_APPS) {
                if (ev.getAction() == KeyEvent.ACTION_UP) closeMorph[0].run();
                return true;
            }
            if (code == KeyEvent.KEYCODE_BACK) {
                if (ev.getAction() == KeyEvent.ACTION_UP) closeMorph[0].run();
                return true;
            }
            if (ev.getAction() != KeyEvent.ACTION_UP) {
                return code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                        || code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT;
            }
            MediaController m = NowPlaying.active(a);
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) {
                if (m != null) {
                    PlaybackState st = m.getPlaybackState();
                    if (st != null && st.getState() == PlaybackState.STATE_PLAYING) m.getTransportControls().pause();
                    else m.getTransportControls().play();
                }
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) { if (m != null) m.getTransportControls().skipToPrevious(); return true; }
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) { if (m != null) m.getTransportControls().skipToNext(); return true; }
            return false;
        });
        d.setOnDismissListener(x -> {
            current = null;
            ui.removeCallbacks(tick);
            scroll.cancel();
            if (morphSpring[0] != null) morphSpring[0].cancel();
        });
        d.show();
        root.post(() -> {
            progressProp.setValue(root, 0f);
            SpringAnimation sp = new SpringAnimation(root, progressProp, 1f);
            sp.getSpring().setStiffness(150f);
            sp.getSpring().setDampingRatio(0.78f);
            sp.setStartValue(0f);
            sp.setMinimumVisibleChange(0.002f);
            morphSpring[0] = sp;
            sp.start();
        });
        ui.post(tick);
    }

    private static TextView text(Activity a, Typeface font, float s, float px, int color, int weight) {
        return formatText(new TextView(a), font, s, px, color, weight);
    }

    private static TextView formatText(TextView t, Typeface font, float s, float px, int color, int weight) {
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px * s);
        t.setTypeface(font);
        try { t.setFontVariationSettings("'wght' " + weight); } catch (Exception ignored) { }
        t.setIncludeFontPadding(false);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }
}
