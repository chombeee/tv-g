package com.gathin.tvhome;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * App icons for the Pill dock, the Material dock and both All Apps drawers, loaded off the UI thread.
 * Most TV apps ship a banner, so the adapter keeps no icon for them and asking PackageManager for one
 * (a disk read and a decode) on the UI thread stalled every rebuild. Icons are drawn once into small
 * bitmaps and cached by package and size.
 */
final class IconLoader {
    private IconLoader() { }

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "icon-loader");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });
    private static final Handler UI = new Handler(Looper.getMainLooper());

    /**
     * Shows the icon of {@code pkg} in {@code view}. {@code known} (the adapter's own icon, when it has one)
     * is used straight away as a private copy; otherwise the icon is loaded in the background.
     */
    static void into(ImageView view, String pkg, Drawable known, int sizePx) {
        if (known != null) {
            Drawable.ConstantState cs = known.getConstantState();
            view.setTag(R.id.card, null);
            view.setImageDrawable(cs != null ? cs.newDrawable(view.getResources()).mutate() : known);
            return;
        }
        final String key = pkg + "@" + sizePx;
        Bitmap hit = CACHE.get(key);
        view.setTag(R.id.card, key);
        if (hit != null) { view.setImageBitmap(hit); return; }
        view.setImageDrawable(null);
        final Context app = view.getContext().getApplicationContext();
        WORKER.execute(() -> {
            Bitmap made = null;
            try {
                PackageManager pm = app.getPackageManager();
                Drawable d = pm.getApplicationIcon(pkg);
                int s = Math.max(1, sizePx);
                made = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
                d.setBounds(0, 0, s, s);
                d.draw(new Canvas(made));
            } catch (Throwable ignored) {
                // an app removed meanwhile, or an icon that cannot be drawn: leave the space empty
            }
            final Bitmap out = made;
            if (out == null) return;
            CACHE.put(key, out);
            UI.post(() -> { if (key.equals(view.getTag(R.id.card))) view.setImageBitmap(out); });
        });
    }

    /** Drops cached icons (apps installed, updated or removed). */
    static void clear() { CACHE.evictAll(); }
}
