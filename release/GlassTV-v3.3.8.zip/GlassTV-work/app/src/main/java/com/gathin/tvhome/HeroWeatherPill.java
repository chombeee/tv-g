package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Hero-only glass capsule in the top-left corner: sky icon and temperature, then a drop and the humidity.
 * It only reads the weather the launcher has already cached; it never makes a network request.
 */
final class HeroWeatherPill extends LinearLayout {
    private final ImageView sky;
    private final TextView temperature;
    private final TextView humidity;
    private int shownSky;

    HeroWeatherPill(Context context) { this(context, false); }

    /** {@code plain}: no glass capsule and no humidity, just the sky icon and the temperature (Pill layout, under the clock). */
    HeroWeatherPill(Context context, boolean plain) {
        super(context);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        // Sized against a 1920x1080 design so it matches on any density a box reports.
        float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        int side = Math.round(26 * s);
        setPadding(side, 0, side, 0);
        GradientDrawable glass = new GradientDrawable();
        glass.setColor(GlassStyle.tint(0x40FFFFFF));
        glass.setCornerRadius(40 * s);
        glass.setStroke(Math.max(1, Math.round(1.5f * s)), 0x73FFFFFF);
        if (!plain) setBackground(glass);
        else setPadding(0, 0, 0, 0);
        setFocusable(false);

        int icon = Math.round(30 * s);
        sky = glyph(context, R.drawable.ic_hero_w_cloud);
        shownSky = R.drawable.ic_hero_w_cloud;
        addView(sky, new LayoutParams(icon, icon));
        temperature = label(context, s);
        LayoutParams tp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        tp.leftMargin = Math.round(9 * s);
        addView(temperature, tp);
        LayoutParams dp = new LayoutParams(icon, icon);
        dp.leftMargin = Math.round(30 * s);
        View drop = glyph(context, R.drawable.ic_hero_drop);
        addView(drop, dp);
        humidity = label(context, s);
        LayoutParams hp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        hp.leftMargin = Math.round(7 * s);
        addView(humidity, hp);
        if (plain) {
            // Mono and simple: white icon and degrees only, a little smaller than the capsule's.
            drop.setVisibility(GONE);
            humidity.setVisibility(GONE);
            temperature.setTextSize(TypedValue.COMPLEX_UNIT_PX, 30 * s);
        }
        update(null);
    }

    private static ImageView glyph(Context context, int drawable) {
        ImageView v = new ImageView(context);
        v.setImageResource(drawable);
        v.setColorFilter(Color.WHITE);
        return v;
    }

    private TextView label(Context context, float s) {
        TextView t = new TextView(context);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 33 * s);
        t.setSingleLine(true);
        t.setIncludeFontPadding(false);
        t.setShadowLayer(3f * s, 0f, 1f * s, 0x55000000);
        try {
            t.setTypeface(getResources().getFont(R.font.outfit));
            t.setFontVariationSettings("'wght' 500");
        } catch (Exception ignored) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    void update(WeatherAirQuality.FullWeather w) {
        boolean cached = getContext().getSharedPreferences("weather_aqi_cache", Context.MODE_PRIVATE)
                .contains("weather_json");
        if (w == null || !cached) {
            temperature.setText("--°C");
            humidity.setText("--%");
            show(R.drawable.ic_hero_w_cloud);
            return;
        }
        temperature.setText(w.temp + "°C");
        humidity.setText(w.humidity + "%");
        // The same Open-Meteo condition strings WeatherCompactView matches, in Malay or English.
        String c = w.condition == null ? "" : w.condition.toLowerCase(java.util.Locale.ROOT);
        if (c.contains("ribut") || c.contains("thunder")) show(R.drawable.ic_hero_w_storm);
        else if (c.contains("hujan") || c.contains("rain") || c.contains("drizzle") || c.contains("shower")) show(R.drawable.ic_hero_w_rain);
        else if (c.contains("separa") || c.contains("partly")) show(R.drawable.ic_hero_w_partly);
        else if (c.contains("mendung") || c.contains("cloud") || c.contains("overcast") || c.contains("jerebu")
                || c.contains("kabus") || c.contains("fog") || c.contains("haze")) show(R.drawable.ic_hero_w_cloud);
        else show(R.drawable.ic_hero_w_clear);
    }

    private void show(int drawable) {
        if (drawable == shownSky) return;
        shownSky = drawable;
        sky.setImageResource(drawable);
    }
}
