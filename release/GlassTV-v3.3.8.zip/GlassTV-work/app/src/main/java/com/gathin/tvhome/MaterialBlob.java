package com.gathin.tvhome;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Path;
import android.view.animation.DecelerateInterpolator;

/** Material A9 cookie geometry, integrated only into GlassTV layout #4. */
public final class MaterialBlob extends HeroBlob {
    private final CookieDrawable shape = new CookieDrawable(0xFFB21C21, 9, .08f);
    private int current = 0xFFB21C21;
    private ValueAnimator morph;
    private ValueAnimator rotationAnimator;
    private int variation;
    private float shapeRotation = 0f;
    private Bitmap wallpaper;
    private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    public void setWallpaper(Bitmap bitmap) { wallpaper = bitmap; invalidate(); }

    public MaterialBlob(Context context) {
        super(context);
        setVisibility(VISIBLE);
        setAlpha(.94f);
        setWillNotDraw(false);
        setPivotX(0f);
        setPivotY(0f);
    }

    @Override protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w,h,oldW,oldH);
        shape.setBounds(new Rect(0, 0, w, h));
        invalidate();
    }

    @Override public void setAccent(int color, boolean show) {
        if (!show) { animate().alpha(0f).setDuration(250).start(); return; }
        setVisibility(VISIBLE);
        animate().alpha(.94f).setDuration(300).start();
        if (morph != null) morph.cancel();
        final int from = current;
        final int to = color;
        variation++;
        // Same MaterialShapes preset family used by the working A9 HomeActivity.
        final int[] lobes = {9, 12, 4, 8, 14, 10, 6, 7, 4};
        final float[] depths = {.08f, .06f, .26f, .16f, .05f, .11f, .12f, .10f, .16f};
        final float[] sharp = {1f, 1f, .55f, .65f, 1f, 2.4f, 1f, 1f, 1f};
        int k = variation % lobes.length;
        shape.morphTo(lobes[k], depths[k], sharp[k]);
        morph = ValueAnimator.ofFloat(0f,1f);
        morph.setDuration(650);
        morph.setInterpolator(new DecelerateInterpolator());
        final float turnFrom = shapeRotation;
        morph.addUpdateListener(a -> {
            float t=(Float)a.getAnimatedValue();
            shapeRotation = (turnFrom + 36f * t) % 360f;   // turns a little with each focus change, then rests
            shape.setProgress(t);
            shape.setColor((Integer)new ArgbEvaluator().evaluate(t,from,to));
            invalidate();
        });
        morph.start();
        current=to;
    }

    @Override protected void onDraw(Canvas canvas) {
        int save = canvas.save();
        canvas.rotate(shapeRotation, getWidth() * .5f, getHeight() * .5f);
        if (wallpaper != null && !wallpaper.isRecycled()) {
            Path mask = shape.getShapePath();
            canvas.clipPath(mask);
            // Undo the shape rotation before painting: wallpaper stays upright.
            canvas.rotate(-shapeRotation, getWidth() * .5f, getHeight() * .5f);
            float vw = getWidth(), vh = getHeight();
            float scale = Math.max(vw / wallpaper.getWidth(), vh / wallpaper.getHeight());
            float bw = wallpaper.getWidth() * scale, bh = wallpaper.getHeight() * scale;
            canvas.drawBitmap(wallpaper, null, new RectF((vw-bw)/2f,(vh-bh)/2f,(vw+bw)/2f,(vh+bh)/2f), imagePaint);
        } else { shape.draw(canvas); }
        canvas.restoreToCount(save);
    }
    @Override protected void onDetachedFromWindow() {
        if(morph!=null) morph.cancel();
        if(rotationAnimator!=null) { rotationAnimator.cancel(); rotationAnimator=null; }
        super.onDetachedFromWindow();
    }
}
