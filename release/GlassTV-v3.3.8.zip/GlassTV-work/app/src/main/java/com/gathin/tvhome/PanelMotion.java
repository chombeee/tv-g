package com.gathin.tvhome;

import android.app.Dialog;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;

/** Shared spring for launcher panels. Progress drives scale and opacity in a single animation. */
final class PanelMotion {
    private final View panel;
    private final SpringAnimation spring;
    private float progress = 1f;
    private Runnable afterClose;
    private boolean closing;

    PanelMotion(View panel, float collapsedScale) {
        this.panel = panel;
        spring = new SpringAnimation(panel, new FloatPropertyCompat<View>("panelProgress") {
            @Override public float getValue(View view) { return progress; }

            @Override public void setValue(View view, float value) {
                progress = value;
                float scale = Math.min(1.022f, collapsedScale + (1f - collapsedScale) * Math.max(0f, value));
                view.setScaleX(scale);
                view.setScaleY(scale);
                view.setAlpha(Math.max(0f, Math.min(1f, value)));
            }
        }, 1f);
        spring.setMinimumVisibleChange(0.003f);
        spring.getSpring().setStiffness(305f).setDampingRatio(0.69f);
        spring.addEndListener((animation, canceled, value, velocity) -> {
            if (!canceled && closing && afterClose != null) afterClose.run();
        });
    }

    void open() {
        panel.setAlpha(0f);
        progress = 0f;
        spring.setStartValue(0f);
        spring.start();
    }

    void close(Runnable done) {
        if (closing) return;
        closing = true;
        afterClose = done;
        spring.getSpring().setStiffness(310f).setDampingRatio(0.95f);
        spring.animateToFinalPosition(0f);
    }

    static void openDialog(Dialog dialog, View panel, float collapsedScale) {
        Window window = dialog.getWindow();
        if (window != null) window.setWindowAnimations(0);
        PanelMotion motion = new PanelMotion(panel, collapsedScale);
        dialog.setOnKeyListener((d, code, event) -> {
            if (code != KeyEvent.KEYCODE_BACK && code != KeyEvent.KEYCODE_ESCAPE) return false;
            if (event.getAction() == KeyEvent.ACTION_UP) motion.close(dialog::dismiss);
            return true;
        });
        motion.open();
    }
}
