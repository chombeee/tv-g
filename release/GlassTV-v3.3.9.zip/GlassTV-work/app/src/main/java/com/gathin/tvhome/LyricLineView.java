package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.TextView;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak", "Itik Ombak", "Penyanyi Tersasul"};
    static final int SINGER = 5;
    private static final int DUCK = 4;
    private static final int[] ACCENTS = {0xFFFF7622, 0xFFFFCA56, 0xFF56E4FF, 0xFF5AAEFF, 0xFF5AAEFF, 0xFFFF9DD0};
    private final Paint character = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint splash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path drop = new Path();
    private PlaybackState playback;
    private long effectsAfter, start, end, restUntil;
    private boolean playsInScreensaver;
    private boolean compact;
    private int style;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void setPlaysInScreensaver() { playsInScreensaver = true; }

    @Override public int getCompoundPaddingRight() {
        return super.getCompoundPaddingRight() + (style == SINGER ? Math.round(getTextSize() * 1.05f) : 0);
    }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        show(text, style, playback, start, end, end);
    }

    void show(String text, int style, PlaybackState playback, long start, long end, long restUntil) {
        if (this.style != style) {
            this.style = style;
            requestLayout();
        }
        if (!TextUtils.equals(getText(), text)) setText(text);
        this.playback = playback;
        this.start = start;
        this.end = end;
        this.restUntil = restUntil;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && (hasWindowFocus() || playsInScreensaver) && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        boolean active = playing && position >= start && position < end;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();
        boolean breathing = playing && style == SINGER && position >= end
                && restUntil - end >= 2400L && position < Math.min(restUntil, end + 1700L);
        if (active && now >= effectsAfter && layout != null) {
            float progress = (position - start) / (float) (end - start);
            drawSweep(canvas, layout, progress, now);
        } else {
            super.onDraw(canvas);
        }
        if ((active || breathing) && now >= effectsAfter && style == SINGER && layout != null) {
            drawSinger(canvas, layout, position, breathing);
        }
        if (active || breathing) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private void drawSweep(Canvas canvas, Layout layout, float progress, long now) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            applySweep(paint, x, width, edge, remaining, now);
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if ((style == 0 || style == 3 || style == DUCK) && remaining >= 0f && remaining < width) {
                float baseline = top + layout.getLineBaseline(i);
                if (style == DUCK) drawDuck(canvas, left + edge, baseline, progress, now);
                else drawSplash(canvas, left + edge, baseline,
                        (float) (totalWidth * 1000.0 / (end - start)), now, style == 3);
            }
            remaining -= width;
        }
    }

    private void applySweep(Paint paint, float x, float width, float edge, float remaining, long now) {
        float size = getTextSize();
        int accent = ACCENTS[style];
        if (style == 2 || style == SINGER) {
            float pulse = (float) Math.sin(now * 0.003);
            paint.setShader(new LinearGradient(edge - size * 1.4f, 0, edge + size * 1.4f, 0,
                    new int[]{accent, 0xFFFFFFFF, accent}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(size * ((compact ? 0.075f : 0.12f) + 0.025f * pulse), 0, 0, 0xB600C7FF);
        } else if (remaining >= width) {
            paint.setShader(new LinearGradient(x, 0, x + width, 0, accent,
                    style == 0 ? 0xFFFFA832 : accent, Shader.TileMode.CLAMP));
        } else if (remaining >= 0f) {
            if (style == 3 || style == DUCK) {
                float ripple = (float) Math.sin(now * .016) * size * .32f;
                paint.setShader(new LinearGradient(edge - size * 1.8f, -size, edge + size * .6f + ripple, 0,
                        new int[]{0xFF1E7BCB, 0xFF43C9F6, 0xFF217FCD, 0xFF79E5FF, 0xFFF0FCFF, getCurrentTextColor()},
                        new float[]{0f, .28f, .46f, .68f, .82f, 1f}, Shader.TileMode.CLAMP));
            } else if (style == 1) {
                float gleam = (float) Math.sin(now * .013) * size * .15f;
                paint.setShader(new LinearGradient(edge - size * 1.9f, 0, edge + size * .45f + gleam, size * .45f,
                        new int[]{0xFFF1A824, 0xFFFEDD7B, 0xFFBD7413, 0xFFFFD565, 0xFFFFFBCE, getCurrentTextColor()},
                        new float[]{0f, .30f, .48f, .63f, .80f, 1f}, Shader.TileMode.CLAMP));
            } else {
                float band = size * (compact ? 1.12f : 1.65f);
                paint.setShader(new LinearGradient(edge - band, 0, edge + band * .24f, 0,
                        new int[]{accent, 0xFFFFA832, 0xFFFFF1C4, getCurrentTextColor()},
                        new float[]{0f, .40f, .81f, 1f}, Shader.TileMode.CLAMP));
                paint.setShadowLayer(size * (compact ? .08f : .13f), 0, 0, 0x90FF6715);
            }
        }
    }

    private void drawDuck(Canvas canvas, float edge, float baseline, float progress, long now) {
        float unit = getTextSize() * (compact ? .63f : .72f);
        float x = Math.max(unit, Math.min(getWidth() - unit, edge));
        float bob = (float) Math.sin((now % 10000L) * .012) * unit * .12f;
        float y = Math.max(unit, Math.min(getHeight() - unit * .42f, baseline + unit * .25f + bob));
        boolean flips = (start / 1000L) % 3L == 0L;
        float flip = flips ? Math.max(0f, Math.min(1f, (progress - .83f) / .14f)) : 0f;

        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.scale(unit, unit);
        character.setColor(0xA8A9EDFF);
        character.setStyle(Paint.Style.STROKE);
        character.setStrokeWidth(.08f);
        canvas.drawOval(-.89f, .23f, .87f, .46f, character);
        character.setStyle(Paint.Style.FILL);
        canvas.rotate(360f * flip);
        character.setColor(0xFFFFBE29);
        canvas.drawOval(-.76f, -.31f, .51f, .30f, character);
        character.setColor(0xFFFFE05C);
        canvas.drawCircle(.29f, -.40f, .35f, character);
        character.setColor(0xFFFF861D);
        canvas.drawOval(.48f, -.40f, .90f, -.21f, character);
        character.setColor(0xFF24202A);
        if (flip >= 1f) {
            canvas.drawOval(.29f, -.56f, .45f, -.52f, character);
        } else {
            canvas.drawCircle(.39f, -.49f, .065f, character);
        }
        canvas.restoreToCount(saved);
    }

    private void drawSinger(Canvas canvas, Layout layout, long position, boolean breath) {
        if (layout.getLineCount() == 0) return;
        float unit = getTextSize() * (compact ? .82f : 1f);
        float x = getWidth() - super.getCompoundPaddingRight() - unit * .52f;
        float y = getTotalPaddingTop() + layout.getLineBaseline(0) - getTextSize() * .31f;
        float phase = breath ? Math.max(0f, (position - end) / 1700f)
                : (Math.max(0L, position - start) % 400L) / 400f;
        float opening = breath ? .15f + .48f * (float) Math.sin(phase * Math.PI)
                : .14f + .24f * Math.abs((float) Math.sin(phase * Math.PI * 2));
        character.setColor(0xFFFF83B0);
        canvas.drawOval(x - unit * .48f, y - unit * opening, x + unit * .48f, y + unit * opening, character);
        character.setColor(0xFF501C3C);
        canvas.drawOval(x - unit * .36f, y - unit * opening * .72f, x + unit * .36f, y + unit * opening * .72f, character);
        character.setColor(breath ? 0xDFD3F9FF : 0xFFFFF4F8);
        if (breath) {
            float bubble = unit * .10f * (1f - phase);
            canvas.drawCircle(x + unit * (.18f + phase * .56f), y - unit * (.45f + phase * .26f), bubble, character);
        } else {
            canvas.drawRoundRect(x - unit * .22f, y - unit * opening * .66f,
                    x + unit * .22f, y - unit * opening * .15f, unit * .09f, unit * .09f, character);
        }
    }

    /**
     * Like the Now Playing bar, the moving head emits particles forward through the fill,
     * above and below the row. Water adds gravity, stretched droplets and white reflections.
     */
    private void drawSplash(Canvas canvas, float head, float baseline, float sweepSpeed, long now, boolean water) {
        float size = getTextSize();
        float centerY = baseline - size * .44f;
        float pulse = .86f + .14f * (float) Math.sin((now % 10000L) * .018);
        float halo = size * (compact ? .62f : .81f) * pulse;
        splash.setShader(new RadialGradient(head, centerY, halo,
                water ? new int[]{0xB9ECFCFF, 0x6043C9FF, 0x00217FCD}
                        : new int[]{0xB9FFF2C8, 0x67FF9D3C, 0x00FF7622},
                new float[]{0f, .40f, 1f}, Shader.TileMode.CLAMP));
        splash.setAlpha(255);
        canvas.drawCircle(head, centerY, halo, splash);
        splash.setShader(null);

        int count = compact ? 10 : 12;
        for (int i = 0; i < count; i++) {
            long period = 410L + (i * 83L) % 215L;
            float elapsed = ((now + 83L * i) % period) / 1000f;
            float phase = elapsed * 1000f / period;
            float direction = (i % 4 == 0) ? 1f : -1f;
            float speedX = size * (1.70f + ((i * 7) % 11) * .31f);
            float speedY = size * (.48f + ((i * 11) % 7) * .22f) * direction;
            float gravity = size * (water ? 5.6f : -.9f);
            float x = head - size * (.08f + i % 4 * .21f) + (speedX - sweepSpeed * .25f) * elapsed;
            float y = centerY + speedY * elapsed + gravity * elapsed * elapsed * .5f;
            float radius = size * (.050f + ((i * 5) % 7) * .010f) * (1f - .5f * phase);
            if (x + radius < 0f || x - radius > getWidth()
                    || y + radius < 0f || y - radius > getHeight()) continue;
            float opacity = (1f - phase) * (1f - phase);
            if (water) {
                drawDroplet(canvas, x, y, radius, speedX, speedY + gravity * elapsed, opacity, i);
            } else {
                splash.setColor(i % 4 == 0 ? 0xFFFFF2BD : 0xFFFF8D35);
                splash.setAlpha(Math.round(105f * opacity));
                canvas.drawCircle(x, y, radius * 1.75f, splash);
                splash.setColor(i % 3 == 0 ? 0xFFFFF7DA : 0xFFFFBC64);
                splash.setAlpha(Math.round(255f * opacity));
                canvas.drawCircle(x, y, radius, splash);
            }
        }
    }

    private void drawDroplet(Canvas canvas, float x, float y, float radius, float vx, float vy, float opacity, int index) {
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.rotate((float) Math.toDegrees(Math.atan2(vy, vx)));
        drop.rewind();
        drop.moveTo(-radius * 2.5f, 0f);
        drop.cubicTo(-radius, -radius * .30f, -.3f * radius, -radius, radius * .5f, -radius);
        drop.cubicTo(radius * 2f, -radius, radius * 2f, radius, radius * .5f, radius);
        drop.cubicTo(-.3f * radius, radius, -radius, radius * .30f, -radius * 2.5f, 0f);
        drop.close();
        splash.setColor(index % 3 == 0 ? 0xFF8BEBFF : 0xFF35BBF4);
        splash.setAlpha(Math.round(235f * opacity));
        canvas.drawPath(drop, splash);
        splash.setColor(0xFFF5FFFF);
        splash.setAlpha(Math.round(245f * opacity));
        canvas.drawOval(0f, -radius * .67f, radius * 1.05f, -radius * .18f, splash);
        canvas.restoreToCount(saved);
    }
}
