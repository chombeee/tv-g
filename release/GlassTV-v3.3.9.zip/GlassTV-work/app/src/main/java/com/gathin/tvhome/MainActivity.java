package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.widget.RelativeLayout;
import android.widget.TextClock;
import android.util.DisplayMetrics;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import android.util.TypedValue;

import androidx.annotation.NonNull;
import androidx.dynamicanimation.animation.DynamicAnimation;
import androidx.dynamicanimation.animation.FloatPropertyCompat;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.dynamicanimation.animation.SpringForce;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gathin.tvhome.qrcode.QrBitmapUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * tvOS style home: black, a pinned dock row, an app grid, and one glass highlight that springs between tiles.
 */
public class MainActivity extends Activity implements AppAdapter.TileListener {

    private static java.lang.ref.WeakReference<MainActivity> sInstance;

    public static MainActivity getInstance() {
        return sInstance != null ? sInstance.get() : null;
    }

    /** Tiles per row and dock slots (res/values/config.xml, columns). Set in onCreate. */
    static int COLUMNS = 4;
    private static final long MINUTE_MS = 60_000L;
    private String liveTvPkg;
    private String liveTvAction;
    private String inputAction;
    private String sourcePanelService;
    private String sourcePanelAction;

    private AppAdapter adapter;
    private RecyclerView grid;
    private FrameLayout root;
    private GlassView glass;
    private View ambient;
    /** The focus: one dark shape gliding between tiles and pills (see Glider). */
    private Glider glider;
    /** Whether the glider is on the top menu, so a move down travels dark. */
    private boolean gliderOnPill;
    private final int[] pillAt = new int[2], rootAt = new int[2];
    /** The top-right buttons and the two rectangles used to line them up with the dock. */
    private View topRow, topSettings;
    private final Rect alignCard = new Rect(), alignButton = new Rect();
    /** How much of the space between the side paddings the top shelf may use. */
    private static final float HERO_WIDTH_SHARE = 0.40f;
    /** The name is one line, and may run wider than the description, up to this share. */
    private static final float HERO_NAME_WIDTH_SHARE = 0.60f;
    private static final float HERO_TITLE_MAX_SP = 40f;
    /** The breathing room between the shelf's last line and the top of the app container. */
    private static final float HERO_GAP_DP = 36f;
    private static final float HERO_TITLE_MIN_SP = 26f;
    /** The shelf's width in pixels, worked out once from the screen. */
    private int heroMaxWidth, heroNameMaxWidth;
    private View heroShelf;
    private TextView heroName;
    private TextView heroDesc;
    private TextView heroWhere;
    /** The place on screen and a few lines about it; null for the user's own wallpapers. */
    private String placeName;
    private String placeText = "", placeCountry = "";
    private int ambientColor = -1;
    private boolean heroShown;
    /** The glow behind the tiles. It follows every app, while the shelf only names dock apps. */
    private boolean ambientShown;

    /** The colour the glass is blending from, how far along it is, and the blend itself. */
    private int glowFrom;
    private float glowMix = 1f;
    private android.animation.ValueAnimator glowBlend;
    private Bitmap ambientShape;
    /** Where the shelf's bottom edge belongs; its top follows once the lines have been measured. */
    private float heroBottom;
    private View btnInputs;
    private TextView btnWifi;
    private TextView ampmView, dateView;
    private TextView shamsiDate;
    private TextView prayerTimesView;
    private TextView weatherAirQualityView;
    private View islamicShelf;
    private TextView ayatRef, ayatArabic, ayatTranslation, prayerHeader;
    private TextView lblSubuh, lblSyuruk, lblZohor, lblAsar, lblMaghrib, lblIsyak;
    private TextView timeSubuh, timeSyuruk, timeZohor, timeAsar, timeMaghrib, timeIsyak;
    private boolean shamsi;
    private String vpnApp;
    private SpringAnimation springX, springY;
    private float glassTargetX, glassTargetY;
    // How far the grid has scrolled the glass. springY works without it, in grid content space, so a
    // scroll moves the glass in lockstep with its tile instead of becoming a moving spring target.
    private float glassScrollShift;
    private boolean glassShown;
    // Static so they survive the activity being destroyed while another app is open (low-memory TVs,
    // or Developer options → "Don't keep activities"); they only reset when the process dies.
    private static int lastFocused = 0;
    /** App of the last focused tile, so focus follows it when the app list changes. */
    private static String lastFocusedKey;
    private float density;
    /** Module cards (res/values/config.xml, module_cards): discovered on resume, shown only after the owner's Show. */
    private boolean moduleCards;
    /** Calmer motion for weak GPUs (config.xml, reduced_motion): stiff spring, short fades, no replay. */
    private boolean reducedMotion;
    /** hidden_apps as the adapter sees them (config.xml or a theme's config.json): a hidden app gets no card either. */
    private Set<String> hiddenApps = Collections.emptySet();
    private List<Cards.Card> cards = Collections.emptyList();
    /** The grid has been laid out and focused since the last resume; the card prompt waits for this. */
    private boolean tilesReady;
    private boolean tilesAnimatedOnce;
    /** Grid rows left showing under the dock (config rows_below_dock). */
    private int rowsBelowDockSetting;
    /** The longest Home holds its first frame while it puts itself together (see holdFirstFrame). */
    private static final long FIRST_FRAME_WAIT_MS = 1200;
    private static final long RETURN_SETTLE_MS = 6000;
    /** True while Home rebuilds on return; focus passes through the pills then and must not light them. */
    private boolean resuming;
    /** True while Home's first frame is held back (see holdFirstFrame). */
    private boolean firstFrameHeld;
    private Dialog cardPrompt;
    /** Set when a decision could not be saved: no more prompts until the next resume, instead of asking in a loop. */
    private boolean promptsPaused;
    /** The Inputs or Module cards dropdown while one is open, so onPause can close it. */
    private PopupWindow openPopup;

    private final Handler handler = new Handler(Looper.getMainLooper());
    /** Rotating wallpaper (Config.wallpapers), the view that shows it and the bitmap on screen. */
    private List<File> wallpapers = Collections.emptyList();
    private long wallpaperIntervalMs;
    /** Decodes the next picture off the main thread, so a switch never stutters the D-pad animations. */
    private final java.util.concurrent.ExecutorService wallDecoder = java.util.concurrent.Executors.newSingleThreadExecutor();
    private long wallShownAt;
    private android.widget.ImageView wallView;
    private VideoView videoWallpaperView;
    private android.graphics.Bitmap wallBitmap;
    private static final int REQUEST_PICK_VIDEO_WALLPAPER = 4801;
    /** Settings kept for the places refresh, which runs after onCreate. */
    private Config config;
    /** Pictures of places are on (see PlaceWallpapers); they are dimmed behind the tiles. */
    private boolean placesMode;
    private volatile boolean placesRefreshRunning;
    private static final long SCREENSAVER_TIMEOUT_MS = 10L * 60 * 1000L; // 10 minutes idle -> screensaver
    private static final long TV_SLEEP_TIMEOUT_MS = SCREENSAVER_TIMEOUT_MS + (2L * 60 * 60 * 1000L); // 2 hours later -> TV off
    private long lastUserInteraction = android.os.SystemClock.elapsedRealtime();
    private boolean screensaverActive = false;
    private View screensaverView;
    private View mainContent;
    private static final long DOUBLE_BACK_DELAY_MS = 350L;
    private long lastHomeBackAt = -1L;
    private View focusBeforeScreensaver;
    private int widgetBeforeScreensaver = -1;
    private static final long DOUBLE_HOME_INTERVAL_MS = 400L;
    private long lastHomePressTime = 0;
    private Runnable singleHomeRunnable = null;
    /** Refreshes the network pill when the connection changes: at boot Wi-Fi often connects after Home is shown. */
    private final ConnectivityManager.NetworkCallback networkCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        @Override
        public void onLost(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }
    };
    /** Shows the Inputs pill once the TV registers an input: at boot HDMI inputs can appear after Home is shown. */
    private final TvInputManager.TvInputCallback inputCallback = new TvInputManager.TvInputCallback() {
        @Override
        public void onInputAdded(String inputId) {
            updateInputsButton();
        }

        @Override
        public void onInputRemoved(String inputId) {
            updateInputsButton();
        }
    };
    /** Listens for any VPN coming up or going down, even one this app's traffic is excluded from. */
    private final ConnectivityManager.NetworkCallback vpnCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onAvailable(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }

        @Override
        public void onLost(@NonNull Network network) {
            handler.post(MainActivity.this::updateWifiLabel);
        }
    };
    private final IntentFilter packageFilter = new IntentFilter();
    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            IconLoader.clear();   // an install or update may change an icon
            // Updates send REMOVED followed by ADDED; keep the tile until the new APK is ready.
            if (Intent.ACTION_PACKAGE_REMOVED.equals(intent.getAction())
                    && intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return;
            reloadApps(false);
        }
    };
    private final Runnable minuteTick = new Runnable() {
        @Override
        public void run() {
            updateShamsiDate();
            updatePrayerTimes();
            updateDateAndPeriod();
            updateWifiLabel();
            updateWeatherAqi();
            WeatherAirQuality.syncIfDue(MainActivity.this, MainActivity.this::updateWeatherAqi);
            updateIslamicShelf();
            refreshPlacesIfDue();
            refreshOnlineWallpapersIfDue();
            checkInactivity();
            handler.postDelayed(this, MINUTE_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLog.install(this);
        GlassStyle.load(this);
        sInstance = new java.lang.ref.WeakReference<>(this);
        SoundEffects.init(this);
        setContentView(R.layout.activity_main);
        density = getResources().getDisplayMetrics().density;
        // config.xml, overlaid by config.json from a pushed theme (see Config and tools/theme.sh).
        Config cfg = Config.load(this);
        COLUMNS = Math.max(4, Math.min(6,
                getSharedPreferences("chombb_appearance", MODE_PRIVATE).getInt("grid_columns", cfg.columns)));
        reducedMotion = cfg.reducedMotion;
        liveTvPkg = cfg.liveTvPackage;
        liveTvAction = cfg.liveTvAction;
        inputAction = cfg.inputAction;
        sourcePanelService = cfg.sourcePanelService;
        sourcePanelAction = cfg.sourcePanelAction;

        root = findViewById(R.id.root);
        root.setClipChildren(false);
        root.setClipToPadding(false);
        // The tiles' entrance plays once per TV boot. Android reclaims the launcher during long stays
        // in big apps; starting again then is a return to Home, not a first launch.
        long bootAt = System.currentTimeMillis() - android.os.SystemClock.elapsedRealtime();
        android.content.SharedPreferences launch = getSharedPreferences("launch", MODE_PRIVATE);
        if (Math.abs(launch.getLong("boot_at", 0) - bootAt) < 60_000) tilesAnimatedOnce = true;
        else launch.edit().putLong("boot_at", bootAt).apply();
        ensureSystemScreensaverAndSleepSettings();
        root.setBackgroundColor(cfg.backgroundColor);
        config = cfg;
        wallpapers = cfg.wallpapers;
        wallpaperIntervalMs = cfg.wallpaperIntervalMs;
        long savedInterval = getSharedPreferences("wallpaper_ui", MODE_PRIVATE).getLong("interval_ms", -1L);
        if (savedInterval >= 0) wallpaperIntervalMs = savedInterval;
        placesMode = cfg.places;
        mainContent = findViewById(R.id.mainContent);
        glass = findViewById(R.id.glass);
        ambient = findViewById(R.id.ambient);
        Backdrop.setWorker(wallDecoder, handler);
        Backdrop.setBlurStrength(getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                .getInt("glass_blur_strength", 70));
        heroShelf = findViewById(R.id.heroShelf);
        heroName = findViewById(R.id.heroName);
        heroDesc = findViewById(R.id.heroDesc);
        heroWhere = findViewById(R.id.heroWhere);
        int usable = getResources().getDisplayMetrics().widthPixels - (int) ((55 + 56) * density);
        heroMaxWidth = Math.round(usable * HERO_WIDTH_SHARE);
        heroNameMaxWidth = Math.round(usable * HERO_NAME_WIDTH_SHARE);
        if (heroName != null) heroName.setMaxWidth(heroNameMaxWidth);
        if (heroDesc != null) heroDesc.setMaxWidth(heroMaxWidth);

        String activeCat = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");
        if ("Custom".equalsIgnoreCase(activeCat)) {
            placesMode = false;
            File customDir = new File(getFilesDir(), "custom_wallpapers");
            File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
            boolean singleMode = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getBoolean("custom_single_mode", false);
            String singleFile = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("custom_single_file", null);
            if (singleMode && singleFile != null) {
                File sf = new File(customDir, singleFile);
                if (sf.exists() && sf.length() > 0) {
                    wallpapers = Collections.singletonList(sf);
                } else if (files != null && files.length > 0) {
                    Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    wallpapers = new ArrayList<>(Arrays.asList(files));
                }
            } else if (files != null && files.length > 0) {
                Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                wallpapers = new ArrayList<>(Arrays.asList(files));
            } else if (cfg.wallpaperOnline && wallpapers.isEmpty()) {
                wallpapers = OnlineWallpapers.list(this);
            }
        } else if (!"Natural".equalsIgnoreCase(activeCat)) {
            placesMode = false;
            List<File> catFiles = OnlineWallpapers.listByCategory(this, activeCat);
            if (!catFiles.isEmpty()) wallpapers = catFiles;
            else if (cfg.wallpaperOnline && wallpapers.isEmpty()) wallpapers = OnlineWallpapers.list(this);
        } else if (placesMode) {
            wallpapers = PlaceWallpapers.list(this);
        } else if (cfg.wallpaperOnline && wallpapers.isEmpty()) {
            wallpapers = OnlineWallpapers.list(this);
        }
        if (!wallpapers.isEmpty()) showNextWallpaper(false);
        else if (cfg.wallpaper != null && !placesMode) setWallpaper(decodeWallpaper(cfg.wallpaper), false);
        // The shelf grows and shrinks with the name and the description, so it hangs from its
        // bottom edge: every time it is measured, its top is worked out again. Positioning it by
        // the height it happened to have beforehand is what let a tall block run into the dock.
        heroShelf.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
            if (heroBottom > 0) v.setY(heroBottom - v.getHeight());
        });
        // The time bubble is an alternate shortcut to the same 3-3-2 quick panel.
        View clockShortcut = findViewById(R.id.clock);
        if (clockShortcut != null) {
            clockShortcut.setFocusable(true);
            clockShortcut.setClickable(true);
            clockShortcut.setOnClickListener(v -> showGlassSettingsPanel());
            clockShortcut.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    if (!focusWidgets(false)) focusHomeApps();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && heroTopIcons != null
                        && heroTopIcons.getVisibility() == View.VISIBLE) {
                    heroTopIcons.getChildAt(0).requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && heroCarousel != null
                        && heroCarousel.getVisibility() == View.VISIBLE) {
                    heroCarousel.requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && "classic".equals(getHomeLayout())) {
                    View search = findViewById(R.id.classicSearch);
                    if (search != null) search.requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP ||
                        keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
                        keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) return true;
                return false;
            });
        }
        View classicSearch = findViewById(R.id.classicSearch);
        if (classicSearch != null) {
            classicSearch.setVisibility(isHeroLayout() ? View.GONE : View.VISIBLE);
            classicSearch.setOnClickListener(v -> openLauncherSearch());
            classicSearch.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && clockShortcut != null) {
                    clockShortcut.requestFocus(); return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    focusTile(lastFocused >= 0 ? lastFocused % COLUMNS : 0); return true;
                }
                return false;
            });
            if (clockShortcut != null) clockShortcut.setNextFocusLeftId(R.id.classicSearch);
        }
        ampmView = findViewById(R.id.ampm);
        dateView = findViewById(R.id.date);
        updateDateAndPeriod();
        // Small non-focusable weather indicator alongside the existing clock.
        WeatherCompactView compactWeather = findViewById(R.id.weatherCompact);
        if (compactWeather != null) {
            compactWeather.update(WeatherAirQuality.getFullWeather(this));
            compactWeather.setFocusable(true);
            compactWeather.setClickable(true);
            compactWeather.setOnClickListener(v -> showCompactWeatherDetails());
            compactWeather.setOnKeyListener((v, key, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                    v.performClick();
                    return true;
                }
                return false;
            });
        }
        weatherAirQualityView = findViewById(R.id.weatherAirQuality);
        if (weatherAirQualityView != null) {
            weatherAirQualityView.setOnClickListener(v -> {
                startActivity(new Intent(this, WeatherActivity.class));
            });
            weatherAirQualityView.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    focusTile(0);
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    View target = (btnInputs != null && btnInputs.getVisibility() == View.VISIBLE) ? btnInputs
                            : (btnWifi != null && btnWifi.getVisibility() == View.VISIBLE) ? btnWifi
                            : findViewById(R.id.btnSettings);
                    if (target != null) {
                        target.requestFocus();
                        return true;
                    }
                }
                return false;
            });
            weatherAirQualityView.setOnFocusChangeListener((v, hasFocus) -> {
                float scale = hasFocus ? 1.05f : 1.0f;
                ChombbWidgets.springScale(v, scale, 420f, 0.66f);
            });
        }
        updateWeatherAqi();
        WeatherAirQuality.syncIfDue(this, this::updateWeatherAqi);

        islamicShelf = findViewById(R.id.islamicShelf);
        if (islamicShelf != null) {
            ayatRef = findViewById(R.id.ayatRef);
            ayatArabic = findViewById(R.id.ayatArabic);
            ayatTranslation = findViewById(R.id.ayatTranslation);
            prayerHeader = findViewById(R.id.prayerHeader);

            lblSubuh = findViewById(R.id.lblSubuh);
            lblSyuruk = findViewById(R.id.lblSyuruk);
            lblZohor = findViewById(R.id.lblZohor);
            lblAsar = findViewById(R.id.lblAsar);
            lblMaghrib = findViewById(R.id.lblMaghrib);
            lblIsyak = findViewById(R.id.lblIsyak);

            timeSubuh = findViewById(R.id.timeSubuh);
            timeSyuruk = findViewById(R.id.timeSyuruk);
            timeZohor = findViewById(R.id.timeZohor);
            timeAsar = findViewById(R.id.timeAsar);
            timeMaghrib = findViewById(R.id.timeMaghrib);
            timeIsyak = findViewById(R.id.timeIsyak);

            islamicShelf.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
                if (heroBottom > 0) v.setY(heroBottom - v.getHeight());
            });
            updateIslamicShelf();
        }

        applyPrayerVisibility();
        applyAyatVisibility();
        setupChombbWidgetShelf();
        applyHomeLayout();
        btnWifi = findViewById(R.id.btnWifi);
        btnWifi.setVisibility(View.GONE); // Wi-Fi controls live in the unified Settings menu.
        shamsiDate = findViewById(R.id.shamsiDate);
        shamsi = cfg.shamsiDate;
        if (shamsi) {
            shamsiDate.setVisibility(View.VISIBLE);
            TextView date = findViewById(R.id.date);
            date.setTextSize(11f);
            date.setPadding(0, (int) (4 * density), 0, 0);
        }
        prayerTimesView = findViewById(R.id.prayerTimes);
        if (prayerTimesView != null) {
            prayerTimesView.setOnClickListener(v -> showPrayerPopup());
            prayerTimesView.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    View inputs = findViewById(R.id.btnInputs);
                    View wifi = findViewById(R.id.btnWifi);
                    View settings = findViewById(R.id.btnSettings);
                    if (inputs != null && inputs.getVisibility() == View.VISIBLE) inputs.requestFocus();
                    else if (wifi != null && wifi.getVisibility() == View.VISIBLE) wifi.requestFocus();
                    else if (settings != null) settings.requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    if (!focusWidgets(false)) focusTile(Math.max(0, lastFocused) % COLUMNS);
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return true;
                if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                    showPrayerPopup();
                    return true;
                }
                return false;
            });
        }
        updatePrayerTimes();
        PrayerTimes.syncIfDue(this, this::updatePrayerTimes);
        vpnApp = cfg.vpnApp;
        moduleCards = cfg.moduleCards;
        hiddenApps = new HashSet<>(cfg.hiddenApps);

        grid = findViewById(R.id.grid);
        grid.setLayoutManager(new GridLayoutManager(this, COLUMNS) {
            @Override
            public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
                // The dock's line is set before any row is placed. Set afterwards, the grid kept its
                // rows where the first layout had put them, and Home came back with the dock and its
                // tray hundreds of pixels up the screen until focus slid them down.
                parkDock();
                super.onLayoutChildren(recycler, state);
            }
        });
        grid.setHasFixedSize(true);
        grid.setItemAnimator(null);
        DockDecoration tray = new DockDecoration(COLUMNS, density);
        grid.addItemDecoration(tray);
        // The top-right buttons line up with the dock, which is only known once the tiles are laid out.
        grid.getViewTreeObserver().addOnGlobalLayoutListener(this::alignTopButtons);
        // Glass shows the blurred wallpaper behind it: the dock tray (drawn by the grid) and the
        // top-bar pills redraw when a new blurred copy is ready.
        Backdrop.watch(grid);
        setUpGlider();
        holdFirstFrame();
        for (int i = 0; i < grid.getItemDecorationCount(); i++) {
            if (grid.getItemDecorationAt(i) instanceof DockDecoration) {
                ((DockDecoration) grid.getItemDecorationAt(i)).setGlider(glider);
            }
        }
        // The grid only shows the shape on the tray.
        glider.addCompanion(grid, tray.area);
        for (int id : new int[]{R.id.btnInputs, R.id.btnWifi, R.id.btnSettings}) {
            View pill = findViewById(id);
            if (pill == null) continue;
            float radius = 21f * density;
            pill.setBackground(new GlassDrawable(pill, radius, density, glider));
            glider.addCompanion(pill);
            Backdrop.watch(pill);
            pill.setOnFocusChangeListener((v, has) -> {
                if (has) moveTopHighlight(v);
            });
        }
        if (prayerTimesView != null) {
            prayerTimesView.setOnFocusChangeListener((v, has) -> {
                if (has) {
                    SoundEffects.playNav();
                    glider.hide();
                }
            });
        }
        // The apps rise into place on the first launch after the TV starts, and only then. Setting
        // the animation arms it for the grid's first draw, so on any later fresh start (Android
        // closing Home while an app was open) it is not set at all: armed, it drew the dock's tray
        // empty while the apps faded in.
        if (!tilesAnimatedOnce) {
            int enterAnim = reducedMotion ? R.anim.tile_enter_reduced : R.anim.tile_enter;
            float enterDelay = reducedMotion ? 0f : 0.06f;
            grid.setLayoutAnimation(new LayoutAnimationController(
                    AnimationUtils.loadAnimation(this, enterAnim), enterDelay));
        }
        adapter = new AppAdapter(this, this, COLUMNS, cfg);
        grid.setAdapter(adapter);
        applyHomeLayout();
        // Fresh install: a short tutorial, then location, update install and notification access.
        if (FirstRunSetup.shouldShow(this)) handler.postDelayed(this::showFirstRunSetup, 1500);

        // tvOS layout: push the dock row towards the bottom of the screen, leaving room for
        // rows_below_dock grid rows under it; the rest of the grid stays below until you press Down.
        rowsBelowDockSetting = cfg.rowsBelowDock;
        grid.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            parkDock();
            updateTopFade();
        });

        // Rows feather out under the top bar instead of being cut off. The fade needs an offscreen
        // layer and draws the grid twice, on every frame of every animation, so it is on only while a
        // row is actually in the band: it switches on in the same frame a row scrolls into it.
        gridWrap = findViewById(R.id.gridWrap);

        // Keep the glass glued to its tile while the grid scrolls.
        grid.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                updateTopFade();
                if (dy != 0 && "classic".equals(getHomeLayout())) placeWidgetShelf();
                if (!glassShown) return;
                glassTargetY -= dy;
                glassScrollShift -= dy;
                glider.scrolled(dy);
            }
        });

        // Classic widgets rest on the dock row: place them again whenever the grid lays out.
        grid.addOnLayoutChangeListener((v, l, tp, r, b, ol, ot, or, ob) -> {
            if ("classic".equals(getHomeLayout())) placeWidgetShelf();
        });

        // Liquid feel: soft springs on the highlight's position.
        springX = new SpringAnimation(glass, DynamicAnimation.TRANSLATION_X);
        springY = new SpringAnimation(glass, new FloatPropertyCompat<View>("glassContentY") {
            @Override
            public float getValue(View v) {
                return v.getTranslationY() - glassScrollShift;
            }

            @Override
            public void setValue(View v, float value) {
                v.setTranslationY(value + glassScrollShift);
            }
        });
        for (SpringAnimation s : new SpringAnimation[]{springX, springY}) {
            if (reducedMotion) {
                // Stiff and almost critically damped: settles in a few frames instead of oscillating,
                // and stops once the highlight is within 1.5 px of its tile.
                s.setSpring(new SpringForce().setStiffness(1400f).setDampingRatio(0.95f));
                s.setMinimumVisibleChange(1.5f);
            } else {
                // Critically damped: glides onto the tile and stops there, with no bounce back.
                s.setSpring(new SpringForce().setStiffness(900f).setDampingRatio(1.0f));
            }
        }

        btnInputs = findViewById(R.id.btnInputs);
        View btnSettings = findViewById(R.id.btnSettings);
        btnInputs.setOnClickListener(v -> showInputs());
        btnWifi.setOnClickListener(v -> showWifiPopup());
        btnWifi.setOnLongClickListener(v -> {
            open(systemIntent(Settings.ACTION_WIFI_SETTINGS));
            return true;
        });
        btnSettings.setOnClickListener(v -> showGlassSettingsPanel());
        btnSettings.setOnLongClickListener(v -> {
            if (moduleCards) {
                showModuleCards();
                return true;
            }
            open(systemIntent(Settings.ACTION_SETTINGS));
            return true;
        });

        // Keep focus on the top bar at its ends and at the top: Android's focus finder would otherwise
        // jump to a tile far below when there is nothing in that direction.
        View.OnKeyListener pillKeys = (v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return true;
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                // Back to the dock tile Up came from, not wherever the focus finder lands.
                focusTile(Math.max(0, lastFocused) % COLUMNS);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                if (v.getId() == R.id.btnInputs && prayerTimesView != null && prayerTimesView.getVisibility() == View.VISIBLE) {
                    prayerTimesView.requestFocus();
                    return true;
                }
                // The left end is Inputs, or Wi-Fi on a box without inputs, or Settings when both are gone.
                return v.getId() == R.id.btnInputs
                        || (v.getId() == R.id.btnWifi && btnInputs.getVisibility() != View.VISIBLE)
                        || (v.getId() == R.id.btnSettings && btnInputs.getVisibility() != View.VISIBLE
                            && btnWifi.getVisibility() != View.VISIBLE);
            }
            return keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && v.getId() == R.id.btnSettings;
        };
        btnInputs.setOnKeyListener(pillKeys);
        btnWifi.setOnKeyListener(pillKeys);
        btnSettings.setOnKeyListener(pillKeys);

        // Hide the glass when focus leaves the tiles.
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalFocusChangeListener((oldF, newF) -> {
            boolean onTile = newF != null && newF.getId() == R.id.card;
            if (!onTile) hideGlass();
            if (!onTile && (newF == null || !(isTopPill(newF) || inMenu(newF)))) glider.hide();
        });

        packageFilter.addAction(Intent.ACTION_PACKAGE_ADDED);
        packageFilter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        packageFilter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        packageFilter.addDataScheme("package");

        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (tim != null) tim.registerCallback(inputCallback, handler);
        if (cm != null) {
            cm.registerDefaultNetworkCallback(networkCallback);
            cm.registerNetworkCallback(new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(), vpnCallback);
        }

        // Silent background update check after 5 seconds on launch
        handler.postDelayed(() -> AppUpdateManager.checkForUpdates(this, false), 5000);
    }

    /**
     * A theme's full-screen picture behind everything. Decoded once, downsampled to the screen so a 4K
     * JPEG costs a 1080p bitmap at most (about 8 MB), which is the price of a wallpaper on a 1 GB TV.
     */
    private android.graphics.Bitmap decodeWallpaper(File file) {
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(file.getPath(), opts);
            int sample = 1;
            while (opts.outWidth / (sample * 2) >= dm.widthPixels && opts.outHeight / (sample * 2) >= dm.heightPixels) sample *= 2;
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            opts.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
            android.graphics.Bitmap raw = android.graphics.BitmapFactory.decodeFile(file.getPath(), opts);
            return coverScreen(raw, dm.widthPixels, dm.heightPixels);
        } catch (Exception | OutOfMemoryError e) {
            // A bad or huge picture must never take the home screen down; the plain colour stays.
            return null;
        }
    }

    /**
     * Fit to screen: scales the picture to fill exactly screenW x screenH and crops the overflow from
     * the centre. Every wallpaper then has the same size, so the cross-fade never stretches one layer and
     * the picture never jumps when the fade ends.
     */
    private static android.graphics.Bitmap coverScreen(android.graphics.Bitmap raw, int screenW, int screenH) {
        if (raw == null || screenW <= 0 || screenH <= 0) return raw;
        if (raw.getWidth() == screenW && raw.getHeight() == screenH) return raw;
        float scale = Math.max(screenW / (float) raw.getWidth(), screenH / (float) raw.getHeight());
        float dx = (screenW - raw.getWidth() * scale) / 2f;
        float dy = (screenH - raw.getHeight() * scale) / 2f;
        android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(screenW, screenH, android.graphics.Bitmap.Config.RGB_565);
        android.graphics.Canvas c = new android.graphics.Canvas(out);
        android.graphics.Matrix m = new android.graphics.Matrix();
        m.setScale(scale, scale);
        m.postTranslate(dx, dy);
        c.drawBitmap(raw, m, new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG));
        if (out != raw) raw.recycle();
        return out;
    }

    /** Puts a picture behind everything, cross-fading from the previous one when asked. */
    private void setWallpaper(android.graphics.Bitmap bmp, boolean fade) {
        setWallpaper(bmp, fade, null);
    }

    /** With {@code blur} made in advance, the glass changes in step with the picture. */
    private void setWallpaper(android.graphics.Bitmap bmp, boolean fade, android.graphics.Bitmap blur) {
        if (bmp == null) return;
        if (wallView == null) {
            wallView = new android.widget.ImageView(this);
            wallView.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            // Photos are bright: dim them so the clock, names and tiles stay readable.
            if (placesMode && !"classic".equals(getHomeLayout())) wallView.setColorFilter(0xFF7A7A7A, android.graphics.PorterDuff.Mode.MULTIPLY);
            Backdrop.setWallpaperAnchor(wallView);
            root.addView(wallView, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        android.graphics.Bitmap old = wallBitmap;
        wallBitmap = bmp;
        if (heroBlob instanceof MaterialBlob) ((MaterialBlob)heroBlob).setWallpaper(bmp);
        if (fade && old != null && !reducedMotion) {
            android.graphics.drawable.TransitionDrawable t = new android.graphics.drawable.TransitionDrawable(new android.graphics.drawable.Drawable[]{
                    new android.graphics.drawable.BitmapDrawable(getResources(), old),
                    new android.graphics.drawable.BitmapDrawable(getResources(), bmp)});
            t.setCrossFadeEnabled(false);
            wallView.setImageDrawable(t);
            t.startTransition(800);
            // The glass fades to the new picture over the same 800 ms as the wallpaper itself.
            if (blur != null) Backdrop.present(blur, 800);
            else blurBackdrop(bmp);
            // Drop the old picture once the fade is done, so only one 1080p bitmap stays in memory.
            handler.postDelayed(() -> {
                if (wallBitmap == bmp) wallView.setImageBitmap(bmp);
            }, 900);
        } else {
            wallView.setImageBitmap(bmp);
            if (blur != null) Backdrop.present(blur, 0);
            else blurBackdrop(bmp);
        }
        // An opaque picture covers the whole screen, so the black window and the plain background
        // under it are never seen. Painting them anyway cost two full-screen passes on every frame,
        // and this TV's graphics chip, not the app, is what holds each frame back.
        boolean videoEnabled = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("video_wallpaper_enabled", false);
        wallView.setVisibility(videoEnabled ? View.GONE : View.VISIBLE);
        if (!bmp.hasAlpha()) {
            root.setBackground(null);
            getWindow().setBackgroundDrawable(null);
        }
    }

    /** Hands the picture now on screen to the glass, which blurs it once, off the main thread. */
    private void blurBackdrop(android.graphics.Bitmap bmp) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        Backdrop.update(bmp, dm.widthPixels, dm.heightPixels, placesMode && !"classic".equals(getHomeLayout()) ? 0xFF7A7A7A : 0, wallDecoder, handler);
    }

    /** Shows the next picture from the wallpapers folder; the position survives restarts. */
    private void showNextWallpaper(boolean fade) {
        if (isVideoWallpaperEnabled()) return;
        android.content.SharedPreferences prefs = getSharedPreferences("wallpaper", MODE_PRIVATE);
        int next = (prefs.getInt("index", -1) + 1) % wallpapers.size();
        prefs.edit().putInt("index", next).apply();
        wallShownAt = android.os.SystemClock.elapsedRealtime();
        final File file = wallpapers.get(next);
        prefs.edit().putString("current_path", file.getPath()).apply();   // the screensaver can follow Home
        // On a cold start, name the place straight away: waiting for the decode showed the app's name
        // at full size and shrank it a moment later. After that the name changes with the picture,
        // or it would name the next place over the last one's picture while that one decodes.
        if (placeName == null) setPlace(file);
        final boolean firstPicture = wallBitmap == null;
        wallDecoder.execute(() -> {
            android.graphics.Bitmap bmp = decodeWallpaper(file);
            // After the first picture, the blur is made here, before the picture is shown, so the glass
            // changes with the wallpaper rather than after it. The first picture of a fresh start does
            // not wait for its blur: Home is held for it, and the glass catches up a moment later.
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            android.graphics.Bitmap blur = firstPicture ? null
                    : Backdrop.blur(bmp, dm.widthPixels, dm.heightPixels, placesMode && !"classic".equals(getHomeLayout()) ? 0xFF7A7A7A : 0);
            handler.post(() -> {
                if (isDestroyed()) return;
                setWallpaper(bmp, fade, blur);
                setPlace(file);
            });
        });
    }

    /** Switches to the next picture every wallpaper interval while Home is in front. */
    private final Runnable wallTick = new Runnable() {
        @Override
        public void run() {
            if (isVideoWallpaperEnabled()) return;
            if (wallpapers.size() >= 2) showNextWallpaper(true);
            handler.postDelayed(this, wallpaperIntervalMs);
        }
    };

    /** Fetches the week's places in the background, then switches the rotation to them. */
    private void refreshPlacesIfDue() {
        if (!placesMode || placesRefreshRunning || !PlaceWallpapers.due(this)) return;
        placesRefreshRunning = true;
        new Thread(() -> {
            boolean changed = PlaceWallpapers.refresh(getApplicationContext());
            handler.post(() -> {
                placesRefreshRunning = false;
                if (!changed || isDestroyed()) return;
                List<File> places = PlaceWallpapers.list(this);
                if (places.isEmpty()) return;
                // Last week's pictures are gone: show one of this week's straight away, so the
                // name on the shelf and the picture behind it always match.
                wallpapers = places;
                showNextWallpaper(wallBitmap != null);
                if (!isFinishing() && hasWindowFocus()) startWallpaperRotation();
            });
        }, "place-wallpapers").start();
    }

    private boolean onlineRefreshRunning;

    /** Fetches fresh 4K online wallpapers in the background when due. */
    private void refreshOnlineWallpapersIfDue() {
        if (config == null || !config.wallpaperOnline || onlineRefreshRunning || !OnlineWallpapers.due(this)) return;
        onlineRefreshRunning = true;
        new Thread(() -> {
            boolean changed = OnlineWallpapers.sync(getApplicationContext(), config.wallpaperFeed);
            handler.post(() -> {
                onlineRefreshRunning = false;
                if (!changed || isDestroyed()) return;
                List<File> fresh = OnlineWallpapers.list(this);
                if (fresh.isEmpty()) return;
                List<File> combined = new ArrayList<>(config.wallpapers);
                for (File f : fresh) {
                    if (!combined.contains(f)) combined.add(f);
                }
                wallpapers = combined;
                if (wallBitmap == null) showNextWallpaper(false);
                if (!isFinishing() && hasWindowFocus()) startWallpaperRotation();
            });
        }, "online-wallpapers").start();
    }

    /** Clears the TV's app caches when due, once Home has sat idle on screen for a while. */
    private final Runnable cacheClean = () -> {
        if (hasWindowFocus() && config != null) CacheCleaner.maybeRun(this, config.cacheCleanDays);
    };

    /** Whenever Home comes back: picks the rotation up where the interval left it. */
    private void startWallpaperRotation() {
        if (isVideoWallpaperEnabled()) {
            handler.removeCallbacks(wallTick);
            return;
        }
        refreshPlacesIfDue();
        refreshOnlineWallpapersIfDue();
        handler.removeCallbacks(wallTick);
        if (wallpapers.size() < 2 || wallpaperIntervalMs <= 0) return;
        long waited = android.os.SystemClock.elapsedRealtime() - wallShownAt;
        // A picture that fell due while you were in an app waits a few seconds: decoding, blurring
        // and fading it the moment you come back competed with Home for the TV's slow CPU.
        handler.postDelayed(wallTick, Math.max(RETURN_SETTLE_MS, wallpaperIntervalMs - waited));
    }

    /**
     * Home pressed while Home is already in front: singleTask delivers it here, then onResume runs.
     * Back to the top with the first dock tile focused, like the stock launcher. Back from an app
     * never comes this way, so returning to the app you left from is unchanged (#118).
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getBooleanExtra("screensaver", false)) {
            showNightstandScreensaver();
            return;
        }
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME) && LyricsOverlay.closeIfShowing()) return;   // Home folds the lyrics card back
        if (intent == null || !intent.hasCategory(Intent.CATEGORY_HOME)) return;
        // Home pressed on Home goes to screensaver sleep mode. Home pressed in another app comes back to
        // the launcher without launching screensaver.
        if (hiddenSinceResume) return;
        if (screensaverActive) {
            dismissScreensaver();
            return;
        }
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastHomePressTime < DOUBLE_HOME_INTERVAL_MS) {
            lastHomePressTime = 0;
            if (singleHomeRunnable != null) {
                handler.removeCallbacks(singleHomeRunnable);
                singleHomeRunnable = null;
            }
            startActivity(new Intent(this, RecentAppsActivity.class));
            return;
        } else {
            lastHomePressTime = now;
            singleHomeRunnable = () -> {
                singleHomeRunnable = null;
                if (screensaverActive) {
                    dismissScreensaver();
                } else {
                    if (cardPrompt != null) cardPrompt.dismiss();
                    if (openPopup != null) openPopup.dismiss();
                    closeMenu(false);
                    if (movingPos >= 0) finishMove();
                    showNightstandScreensaver();
                }
            };
            handler.postDelayed(singleHomeRunnable, DOUBLE_HOME_INTERVAL_MS);
        }
    }

    /**
     * Home went behind another app since it was last resumed. A Home press that brings it back
     * arrives before onResume, so this tells it apart from a Home press on Home itself.
     */
    private boolean hiddenSinceResume;

    @Override
    protected void onStop() {
        hiddenSinceResume = true;
        handler.removeCallbacks(cacheClean);
        super.onStop();
    }

    /** True when D-pad focus sits on a widget card (or nowhere): not where Home should start. */
    private boolean focusIsOnWidgetOrNone() {
        View f = getCurrentFocus();
        if (f == null || !f.isShown()) return true;
        return widgetCards != null && widgetCards.contains(f);
    }

    /** Starts every layout on the first app of the dock (Hero grid, Pill, Material, Classic row), never on a widget. */
    private void focusFirstDockApp() {
        String layout = getHomeLayout();
        if (heroAppGrid != null && "hero".equals(layout)) { heroAppGrid.focusFirst(); return; }
        if (pillDock != null && ("pills".equals(layout) || "material".equals(layout) || isHeroLayout())) {
            pillDock.focusFirstTile();
            return;
        }
        focusTile(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshChombbWidgetShelf();
        applyHomeLayout();
        FirstRunSetup.refresh();
        if (heroAppGrid != null) handler.postDelayed(() -> {
            View f = getCurrentFocus();
            if (heroAppGrid != null && (f == null || !f.isShown())) heroAppGrid.focusCurrent();
        }, 250);
        handler.postDelayed(() -> { if (!isFinishing() && focusIsOnWidgetOrNone() && openPopup == null) focusFirstDockApp(); }, 450);
        if (heroCarousel != null) heroCarousel.setActive(true);
        if (isHeroLayout() && pillDock != null) handler.postDelayed(() -> {
            if (pillDock != null && getCurrentFocus() == null) pillDock.focusCurrent();
        }, 400);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(packageReceiver, packageFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(packageReceiver, packageFilter);
        }
        tilesReady = false;
        promptsPaused = false;
        resuming = true;
        reloadApps(true);
        updateShamsiDate();
        updatePrayerTimes();
        updateDateAndPeriod();
        updateWifiLabel();
        updateWeatherAqi();
        WeatherAirQuality.syncIfDue(this, this::updateWeatherAqi);
        autoLocate();
        updateIslamicShelf();
        updateInputsButton();
        startWallpaperRotation();
        startVideoWallpaperFromPrefs();
        applyPrayerVisibility();
        handler.postDelayed(minuteTick, MINUTE_MS);
        handler.removeCallbacks(cacheClean);
        handler.postDelayed(cacheClean, CacheCleaner.IDLE_MS);
        hiddenSinceResume = false;
        // Check again after returning to Home, but never on every brief app switch.
        long lastUpdateCheck = getSharedPreferences("update_prefs", MODE_PRIVATE)
                .getLong("last_check_timestamp", 0L);
        if (System.currentTimeMillis() - lastUpdateCheck > 6L * 60L * 60L * 1000L) {
            handler.postDelayed(() -> AppUpdateManager.checkForUpdates(this, false), 5000);
        }
    }

    /** Rebuilds the tiles (and the module cards), then puts focus back where it was. */
    private void reloadApps(boolean animate) {
        // Capture the app before rebinding can move focus and overwrite its key.
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        final boolean restoreFocus = animate || grid.hasFocus();
        long started = android.os.SystemClock.uptimeMillis();
        boolean rebuilt = reloadTiles();
        // Nothing installed or removed: Home comes back exactly as it was left, with no rebuild and
        // no shelf, glow or selection fading back in.
        if (restoreFocus && rebuilt) {
            glassShown = false;
            glider.hideNow();
            heroShown = false;
            heroShelf.setAlpha(0f);
            ambientShown = false;
            ambient.setAlpha(0f);
            syncGlassGlow();
        }
        android.util.Log.i("TvHome.Perf", "tiles " + (rebuilt ? "rebuilt" : "unchanged") + " in "
                + (android.os.SystemClock.uptimeMillis() - started) + " ms");
        // The tiles rise into place on the first launch only. Replayed on every return from an app,
        // it showed the glass tray empty for a moment and held Home back while the tiles arrived.
        if (animate && !reducedMotion && !tilesAnimatedOnce) grid.scheduleLayoutAnimation();
        if (animate) tilesAnimatedOnce = true;

        if (restoreFocus) {
            // Follow the same app, or the nearest remaining slot when it was removed.
            restoreFocus();
        } else {
            // A package change must not steal focus from a top button or the Inputs popup.
            int pos = adapter.positionOf(returnKey);
            lastFocused = Math.max(0, Math.min(pos >= 0 ? pos : returnSlot, adapter.getItemCount() - 1));
            lastFocusedKey = adapter.keyAt(lastFocused);
            if (pos < 0) hideHero();
            // A newly installed app may have brought a card with it.
            tilesReady = true;
            showCardPrompt();
        }
    }

    /**
     * Rebuilds the tiles; the module cards the owner chose to show stand in for their app's tile.
     * Every step into the card code runs under CardFeature: if it fails, the tiles are the ordinary
     * ones and cards stay off for this process.
     */
    private boolean reloadTiles() {
        // Read these before reload(): rebinding can move focus to the first tile and overwrite them.
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        final List<Cards.Card> none = Collections.emptyList();
        cards = moduleCards ? CardFeature.run(() -> Cards.discover(this, hiddenApps, Cards.load(Cards.storeFile(this))), none) : none;
        boolean rebuilt = adapter.reload(cards.isEmpty() ? none : CardFeature.run(() -> Cards.shown(cards), none));
        lastFocusedKey = returnKey;
        lastFocused = returnSlot;
        return rebuilt;
    }

    /**
     * Return to the app we left from, or the same slot if that app is gone. Always refocus: after
     * reload() the view that holds focus may no longer show the app it had.
     */
    private void restoreFocus() {
        final String returnKey = lastFocusedKey;
        final int returnSlot = lastFocused;
        grid.post(() -> {
            int pos = adapter.positionOf(returnKey);
            focusTile(pos >= 0 ? pos : returnSlot);
            tilesReady = true;
            resuming = false;
            View now = getCurrentFocus();
            if (now != null && isTopPill(now)) moveTopHighlight(now);
            showCardPrompt();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (heroCarousel != null) heroCarousel.setActive(false);
        unregisterReceiver(packageReceiver);
        handler.removeCallbacks(minuteTick);
        handler.removeCallbacks(wallTick);
        handler.removeCallbacks(chombbWidgetRefresh);
        handler.removeCallbacks(lyricWidgetRefresh);
        if (heroAppGrid != null) heroAppGrid.endMove();
        if (pillDock != null) pillDock.endMove();
        // Nothing of ours stays on screen over another app; an undecided prompt simply returns next time.
        if (cardPrompt != null) cardPrompt.dismiss();
        if (openPopup != null) openPopup.dismiss();
        closeMenu(false);
        if (videoWallpaperView != null && videoWallpaperView.isPlaying()) videoWallpaperView.pause();
        finishMove();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) lastHomeBackAt = -1L;
        if (hasFocus) showCardPrompt();
    }

    /**
     * Android is short of memory while Home sits behind another app: give back what can be remade,
     * so the launcher is less likely to be reclaimed and Home comes back without starting over.
     */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_BACKGROUND) Backdrop.trim();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sInstance != null && sInstance.get() == this) {
            sInstance = null;
        }
        if (uploadServer != null) {
            uploadServer.stop();
            uploadServer = null;
        }
        SoundEffects.release();
        if (videoWallpaperView != null) {
            videoWallpaperView.stopPlayback();
            videoWallpaperView = null;
        }
        wallDecoder.shutdownNow();
        ConnectivityManager cm = getSystemService(ConnectivityManager.class);
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (tim != null) tim.unregisterCallback(inputCallback);
        if (cm != null) {
            cm.unregisterNetworkCallback(networkCallback);
            cm.unregisterNetworkCallback(vpnCallback);
        }
    }

    private void autoLocate() {
        AutoLocation.refreshIfDue(this, this::refreshLocationDependentData);
    }

    public void refreshLocationDependentData() {
        updateWeatherAqi();
        updatePrayerTimes();
        WeatherAirQuality.sync(this, this::updateWeatherAqi);
        PrayerTimes.sync(this, this::updatePrayerTimes);
    }

    @Override
    public void onBackPressed() {
        handleBackPress();
    }

    private void handleBackPress() {
        long previous = lastHomeBackAt;
        lastHomeBackAt = -1L;
        if (LyricsOverlay.closeIfShowing()) return;
        if (movingPos >= 0) { finishMove(); return; }
        if (heroAppGrid != null && heroAppGrid.endMove()) return;
        if (pillDock != null && pillDock.endMove()) return;
        if (pillAllAppsDrawer != null) { hidePillAllAppsDrawer(true); return; }
        if (openMenu != null) { closeMenu(true); return; }
        if (openPopup != null && openPopup.isShowing()) { openPopup.dismiss(); return; }
        if (screensaverActive) { dismissScreensaver(); return; }
        long now = android.os.SystemClock.uptimeMillis();
        if (previous >= 0 && now - previous <= DOUBLE_BACK_DELAY_MS) showNightstandScreensaver();
        else lastHomeBackAt = now;
    }

    // ---- glass highlight -------------------------------------------------------------------------

    /** Reused by every focus move. */
    private final Rect tileRect = new Rect(), showRect = new Rect();

    @Override
    public void onTileFocused(int position, View card) {
        if (!resuming && hasWindowFocus()) SoundEffects.playNav();
        lastFocused = position;
        lastFocusedKey = adapter.keyAt(position);
        // CHOMBB: colour lives only on the focused app border, never across the wallpaper.
        if (ambient != null) {
            ambient.animate().cancel();
            ambient.setAlpha(0f);
        }
        Backdrop.setGlow(null, 0, 0, 1f, 0f);
        if (glider != null) {
            boolean glowEnabled = getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                    .getBoolean("focus_glow", true);
            glider.setAppGlow(adapter.ambientColorAt(position), glowEnabled);
        }
        // Tile rect in root coordinates, using layout positions (ignores the scale animation).
        Rect r = tileRect;
        r.set(0, 0, card.getWidth(), card.getHeight());
        root.offsetDescendantRectToMyCoords(card, r);
        float pad = 6f * density;        // matches GlassView's glow inset
        float w = card.getWidth() * AppAdapter.FOCUS_SCALE + 2 * pad;
        float h = card.getHeight() * AppAdapter.FOCUS_SCALE + 2 * pad;
        float x = r.exactCenterX() - w / 2f;
        float y = r.exactCenterY() - h / 2f;

        ViewGroup.LayoutParams lp = glass.getLayoutParams();
        if (lp.width != (int) w || lp.height != (int) h) {
            lp.width = (int) w;
            lp.height = (int) h;
            glass.setLayoutParams(lp);
            // The rim is drawn inset by pad, right on the zoomed tile, so its corners use the tile's radius as is.
            glass.setRadius(AppAdapter.cornerRadius(card.getWidth(), density) * AppAdapter.FOCUS_SCALE);
        }
        glassTargetX = x;
        glassTargetY = y;
        // Exactly the zoomed card, behind it: at rest the app hides it completely, so it never lies
        // over an app and only shows while it travels between places.
        float cardRadius = AppAdapter.cornerRadius(card.getWidth(), density) * AppAdapter.FOCUS_SCALE;
        if (gliderOnPill) {
            // Down from the top menu it travels dark, and turns to glass once it lands, unseen behind
            // the app.
            glider.moveTo(x + pad, y + pad, x + w - pad, y + h - pad, cardRadius);
            glider.onArrive(() -> {
                if (!gliderOnPill) glider.setStyle(Glider.GLASS);
            });
        } else {
            // From app to app it is a pane of glass gliding behind them.
            glider.setStyle(Glider.GLASS);
            glider.moveTo(x + pad, y + pad, x + w - pad, y + h - pad, cardRadius);
        }
        gliderOnPill = false;
        glider.setAlpha(getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                .getBoolean("focus_glow", true) ? 1f : 0f);
        glassShown = true;
        View item = (View) card.getParent();
        if (position < COLUMNS) {
            // Dock: park it at the bottom of the screen and show the top shelf for this app.
            int decoratedTop = item.getTop() - (int) (6 * density);
            int dy = decoratedTop - grid.getPaddingTop();
            // A 1px mismatch used to start a scroll on every dock move. Only scroll when the row is
            // actually off; reduced motion does it in one jump so it does not fight the highlight.
            boolean scroll = Math.abs(dy) > (int) (8 * density);
            if (scroll) {
                if (reducedMotion) grid.scrollBy(0, dy);
                else grid.smoothScrollBy(0, dy);
            }
            showHero(position, scroll ? r.top - dy : r.top);
        } else {
            // Below the dock there is no shelf, but the glow still takes this app's colour, so every
            // tile lights the room the same way the dock does.
            hideShelf();
            if (!getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                    .getBoolean("keep_wallpaper_on_selection", true)) {
                // Full-screen app-colour tint disabled: highlight colour belongs to tile only.
            }
            // Scroll just enough so the whole glass (not only the tile) is visible.
            showRect.set(0, -(int) pad * 2, item.getWidth(), item.getHeight() + (int) pad);
            grid.requestChildRectangleOnScreen(item, showRect, reducedMotion);
        }
    }

    // ---- top shelf -------------------------------------------------------------------------------

    private boolean isCustomWallpaper() {
        String activeCat = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");
        if ("Custom".equalsIgnoreCase(activeCat)) return true;
        if (wallpapers != null && !wallpapers.isEmpty()) {
            int idx = getSharedPreferences("wallpaper", MODE_PRIVATE).getInt("index", 0);
            if (idx >= 0 && idx < wallpapers.size()) {
                File f = wallpapers.get(idx);
                if (f != null && f.getAbsolutePath().contains("custom_wallpapers")) return true;
            }
        }
        return false;
    }

    private void showHero(int position, float dockTopInRoot) {
        int color = adapter.ambientColorAt(position);
        heroBottom = dockTopInRoot - HERO_GAP_DP * density;

        if (islamicShelf != null) {
            float iy = heroBottom - islamicShelf.getHeight();
            islamicShelf.setY(iy);
            if (!heroShown) {
                islamicShelf.animate().cancel();
                if (firstFrameHeld || resuming) islamicShelf.setAlpha(1f);
                else islamicShelf.animate().alpha(1f).setDuration(260).start();
            } else {
                islamicShelf.setAlpha(1f);
            }
        }

        // CHOMBB Glass Classic: focus changes tiles only, never the hero title/art.
        // The wallpaper image and its existing rotation/preferences remain untouched.
        if (getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                .getBoolean("keep_wallpaper_on_selection", true)) {
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }
            heroShown = true;
            return;
        }

        // When using custom wallpaper, disable the description part completely
        if (isCustomWallpaper()) {
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }
            showAmbient(color);
            heroShown = true;
            return;
        }

        if (heroShelf != null) {
            heroShelf.setVisibility(View.VISIBLE);
        }

        // The place the picture is of, when there is one; the app's own name is the fallback for
        // the user's own wallpapers, which carry no title.
        final String label = placeName != null ? placeName : adapter.labelAt(position);
        final String desc = placeName != null ? placeText : "";
        final String where = placeName != null ? placeCountry : "";
        float y = heroBottom - heroShelf.getHeight();
        boolean changed = !label.contentEquals(heroName.getText());

        if (reducedMotion) {
            // Snap the shelf instead of sliding and fading it: each of those frames repaints the
            // full-screen panel, and this switch exists for the GPUs that cannot afford it.
            heroShelf.animate().cancel();
            setHeroText(label, where, desc);
            heroShelf.setY(y);
            heroShelf.setTranslationX(0f);
            heroShelf.setAlpha(1f);
            showAmbient(color);
            heroShown = true;
            return;
        }

        if (!heroShown) {
            setHeroText(label, where, desc);
            heroShelf.setY(y);
            heroShelf.setTranslationX(0f);
            // Coming back to Home, the words are simply there with the picture: faded in after the
            // first frame, they arrived a beat behind everything else.
            heroShelf.animate().cancel();
            if (firstFrameHeld || resuming) heroShelf.setAlpha(1f);
            else heroShelf.animate().alpha(1f).setDuration(260).start();
            showAmbient(color);
            heroShown = true;
        } else if (changed) {
            heroShelf.animate().alpha(0f).translationX(-12 * density).setDuration(120).withEndAction(() -> {
                setHeroText(label, where, desc);
                heroShelf.setY(y);
                heroShelf.setTranslationX(12 * density);
                heroShelf.animate().alpha(1f).translationX(0f).setDuration(200).start();
            }).start();
            showAmbient(color);
        } else {
            // Same words, different app: every dock app shares the place's name, so the colour has
            // to follow focus on its own rather than ride along with a change of text.
            heroShelf.setY(y);
            showAmbient(color);
        }
    }

    /**
     * Lines the top-right buttons up with the dock: the Settings circle's right edge sits on the
     * right edge of the last dock card, and Inputs follows on its left. Card width follows the
     * column count and the screen, so the edge is measured rather than written down.
     */
    private void alignTopButtons() {
        if (!"classic".equals(getHomeLayout())) return;
        // This runs on every layout pass, which during a grid scroll is every frame, so it keeps
        // its views and rectangles rather than looking them up or allocating each time.
        if (topRow == null) {
            topRow = findViewById(R.id.topButtons);
            topSettings = findViewById(R.id.btnSettings);
        }
        if (topRow == null || topRow.getVisibility() != View.VISIBLE || topSettings.getWidth() == 0) return;
        RecyclerView.ViewHolder last = grid.findViewHolderForAdapterPosition(COLUMNS - 1);
        if (last == null) return;
        View card = last.itemView.findViewById(R.id.card);
        if (card == null || card.getWidth() == 0) return;
        // Layout positions, not drawn ones: a focused card is scaled up, and the row's own shift
        // must not be counted twice.
        alignCard.set(0, 0, card.getWidth(), card.getHeight());
        root.offsetDescendantRectToMyCoords(card, alignCard);
        alignButton.set(0, 0, topSettings.getWidth(), topSettings.getHeight());
        root.offsetDescendantRectToMyCoords(topSettings, alignButton);
        float shift = alignCard.right - alignButton.right;
        if (Math.abs(topRow.getTranslationX() - shift) >= 1f) topRow.setTranslationX(shift);
    }

    /**
     * The one focus shape (Glider) goes behind everything it marks; the pills' glass makes way for it
     * as it arrives, and the dock tray paints it over its own glass.
     */
    private void setUpGlider() {
        glider = new Glider(this, reducedMotion);
        // Behind the shelf's text, the pills and the tiles, so it never draws over any of them.
        root.addView(glider, root.indexOfChild(heroShelf), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // The glider replaces the glass selection outright.
        glass.setVisibility(View.GONE);
    }

    private boolean isTopPill(View v) {
        int id = v.getId();
        return id == R.id.btnInputs || id == R.id.btnWifi || id == R.id.btnSettings;
    }

    /** Sends the focus shape onto a pill: from a tile it glides up and narrows into the pill. */
    private void moveTopHighlight(View pill) {
        if (resuming) return;
        SoundEffects.playNav();
        pill.getLocationInWindow(pillAt);
        glider.getLocationInWindow(rootAt);
        float l = pillAt[0] - rootAt[0], t = pillAt[1] - rootAt[1];
        // The pills do not scroll with the grid, so the shape stops following the grid's scroll.
        glassShown = false;
        // Up to the top menu it is dark at once, and travels that way.
        gliderOnPill = true;
        glider.setStyle(Glider.DARK);
        glider.moveTo(l, t, l + pill.getWidth(), t + pill.getHeight(), pill.getHeight() / 2f);
    }

    /** The shelf's two lines. An empty description takes no room, so the title keeps its place. */
    private void setHeroText(String title, String where, String desc) {
        if (heroName == null || heroWhere == null || heroDesc == null) return;
        heroName.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, titleSizeSp(title));
        heroName.setText(title);
        heroWhere.setText(where);
        heroWhere.setVisibility(where == null || where.isEmpty() ? View.GONE : View.VISIBLE);
        // The description sits further down under a country line; with none, close under the name.
        ViewGroup.MarginLayoutParams descLp = (ViewGroup.MarginLayoutParams) heroDesc.getLayoutParams();
        if (descLp != null) {
            int top = Math.round(((where == null || where.isEmpty()) ? 6f : 9.5f) * density);
            if (descLp.topMargin != top) {
                descLp.topMargin = top;
                heroDesc.setLayoutParams(descLp);
            }
        }
        heroDesc.setText(desc);
        heroDesc.setVisibility(desc == null || desc.isEmpty() ? View.GONE : View.VISIBLE);
    }

    /**
     * Shouting titles are calmed down: "THE RIBBON HERO" becomes "The Ribbon Hero". A title that
     * already has lower case is left exactly as its studio wrote it, so "LEGO Star Wars" and
     * "WALL·E" keep their capitals instead of being flattened to "Lego" and "Wall·e".
     */
    private static String titleCase(String title) {
        if (title == null || title.isEmpty()) return title;
        for (int i = 0; i < title.length(); i++) {
            if (Character.isLowerCase(title.charAt(i))) return title;
        }
        StringBuilder out = new StringBuilder(title.length());
        boolean start = true;
        for (int i = 0; i < title.length(); i++) {
            char c = title.charAt(i);
            out.append(start ? Character.toUpperCase(c) : Character.toLowerCase(c));
            // A new word begins after a space or any of the marks a title tends to use.
            start = c == ' ' || c == '-' || c == ':' || c == '.' || c == '\'' || c == '(' || c == '/';
        }
        return out.toString();
    }

    /**
     * The largest size at which the name still fits on one line, up to its share of the width.
     * Names run longer than app names ("Wroclaw Market Square"), and a name cut short tells the
     * viewer nothing, so a long one is set smaller rather than clipped.
     */
    private float titleSizeSp(String title) {
        if (title == null || title.isEmpty() || heroNameMaxWidth <= 0) return HERO_TITLE_MAX_SP;
        android.text.TextPaint paint = new android.text.TextPaint(heroName.getPaint());
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        for (float sp = HERO_TITLE_MAX_SP; sp > HERO_TITLE_MIN_SP; sp -= 2f) {
            paint.setTextSize(sp * scaled);
            if (paint.measureText(title) <= heroNameMaxWidth) return sp;
        }
        return HERO_TITLE_MIN_SP;
    }

    /**
     * Follows the rotation: the shelf names whichever place is on screen. Called after the picture
     * changes, so the words and the picture never disagree.
     */
    private void setPlace(File picture) {
        if (picture != null && picture.getAbsolutePath().contains("custom_wallpapers")) {
            placeName = null;
            placeText = "";
            placeCountry = "";
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.animate().alpha(0f).setDuration(reducedMotion ? 100 : 250).withEndAction(() -> {
                    if (heroShelf != null) heroShelf.setVisibility(View.GONE);
                }).start();
            }
            return;
        }
        if (heroShelf != null) {
            heroShelf.setVisibility(View.VISIBLE);
        }
        String[] about = placesMode ? PlaceWallpapers.describe(picture) : OnlineWallpapers.describe(picture);
        String title = about != null ? titleCase(about[0]) : null;
        String overview = about != null ? about[1] : "";
        String country = about != null && about.length > 2 ? about[2] : "";
        if (country != null) {
            country = country.replaceAll("(?i)\\bunsplash\\s*•?\\s*", "").trim();
            if (country.startsWith("Malaysia_")) {
                String st = country.substring("Malaysia_".length());
                if ("WP".equalsIgnoreCase(st)) st = "Wilayah Persekutuan";
                else if ("NegeriSembilan".equalsIgnoreCase(st)) st = "Negeri Sembilan";
                else if ("PulauPinang".equalsIgnoreCase(st)) st = "Pulau Pinang";
                country = st + ", Malaysia";
            }
        }
        if (title != null) {
            title = title.replaceAll("(?i)\\bunsplash\\s*•?\\s*", "").trim();
        }
        if (title == null ? placeName == null : title.equals(placeName)) return;
        placeName = title;
        placeText = overview;
        placeCountry = country;
        // When the shelf is up, the words fade out with the old picture and back in with the new
        // one, inside the picture's own cross-fade: swapped at once, the next place's name sat over
        // the last one's picture while it faded. The layout listener puts the shelf back where it
        // belongs once the new lines have been measured.
        if (heroShown && title != null) {
            final String t = title;
            final String c = country;
            final String o = overview;
            heroShelf.animate().cancel();
            heroShelf.animate().alpha(0f).setDuration(reducedMotion ? 100 : 250).withEndAction(() -> {
                setHeroText(t, c, o);
                if (heroShown) heroShelf.animate().alpha(1f).setDuration(reducedMotion ? 120 : 400).start();
            }).start();
        }
    }

    /**
     * The glow used to be a full-screen radial GradientDrawable. On Android 10 that drawable is
     * drawn on the CPU, so fading it for half a second redrew 1920×1080 every frame and the
     * highlight looked like it was running at a few frames per second. A small bitmap stretched
     * over the screen is one texture; changing apps only uploads it once.
     */
    private void setAmbient(int color) {
        setAmbient(color, false);
    }

    private FadeTopFrame gridWrap;

    /** Turns the top fade on while any row reaches into its band, with room for a focused tile's zoom. */
    private void updateTopFade() {
        if (gridWrap == null) return;
        float band = 56 * density + 24 * density;
        boolean inBand = false;
        for (int i = 0; i < grid.getChildCount() && !inBand; i++) {
            View child = grid.getChildAt(i);
            inBand = grid.getTop() + child.getTop() + child.getTranslationY() < band;
        }
        gridWrap.setFadeStrength(inBand ? 1f : 0f);
    }

    /**
     * The dock row sits towards the bottom of the screen, leaving room for rows_below_dock grid rows
     * under it; the rest of the grid stays below until you press Down. Sets the grid's top padding
     * for that, and says whether it was already right.
     */
    private boolean parkDock() {
        int h = grid.getHeight();
        if (h <= 0) return false;
        // Item height follows the tile size, which follows the column count (AppAdapter.tileWidthPx).
        int inner = grid.getWidth() - grid.getPaddingLeft() - grid.getPaddingRight();
        int itemH = AppAdapter.itemHeightPx(AppAdapter.tileHeightPx(AppAdapter.tileWidthPx(inner, COLUMNS, density)), density);
        int dockRow = itemH + (int) ((6 + 12) * density);   // item height plus DockDecoration offsets
        int want = Math.max(0, h - dockRow - itemH * rowsBelowDockSetting - (int) (30 * density));
        if (grid.getPaddingTop() == want) return true;
        grid.setPadding(grid.getPaddingLeft(), want, grid.getPaddingRight(), grid.getPaddingBottom());
        return false;
    }

    /**
     * Home's first frame waits until Home is whole: tiles bound and laid out, the dock parked at the
     * bottom and the wallpaper in. Drawn as soon as the window was ready, it showed the glass tray
     * floating empty near the top, then the tiles, then the dock dropping into place. This matters
     * most after a long stay in another app, when Android has reclaimed the launcher and Home starts
     * from nothing. The wait is capped, so Home can never hang on a slow picture.
     */
    private void holdFirstFrame() {
        final long start = android.os.SystemClock.uptimeMillis();
        firstFrameHeld = true;
        final boolean expectsWallpaper = !wallpapers.isEmpty() || (config.wallpaper != null && !placesMode) || config.wallpaperOnline;
        root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                // Parked here rather than by the layout listener alone: while frames are held, the
                // second layout pass that listener relies on does not always come.
                boolean classic = "classic".equals(getHomeLayout());
                boolean parked = !classic || parkDock();
                // The place's name and lines come in the same frame as the picture they describe,
                // whenever focus lands in the dock, where the shelf shows. Other layouts never show the
                // Classic grid, so they wait only for the apps and the wallpaper (this used to hold
                // Hero, Pill and Material blank for the full 1.2 s timeout on every start).
                boolean whole = adapter != null && adapter.getItemCount() > 0
                        && (wallBitmap != null || !expectsWallpaper)
                        && (!classic || (grid.getChildCount() > 0 && parked && (heroShown || lastFocused >= COLUMNS)));
                if (!whole && android.os.SystemClock.uptimeMillis() - start < FIRST_FRAME_WAIT_MS) {
                    return false;   // skip this frame; the next traversal asks again
                }
                root.getViewTreeObserver().removeOnPreDrawListener(this);
                firstFrameHeld = false;
                android.util.Log.i("TvHome.Perf", "first frame after " + (android.os.SystemClock.uptimeMillis() - start)
                        + " ms" + (whole ? "" : " (gave up waiting: tiles=" + adapter.getItemCount()
                        + " laidOut=" + grid.getChildCount() + " dockParked=" + parked
                        + " wallpaper=" + (wallBitmap != null) + ")"));
                return true;
            }
        });
    }

    /** Tells the glass the glow's colour and strength, so what shows through matches around it. */
    private void syncGlassGlow() {
        Backdrop.setGlow(ambientShape(), glowFrom, ambientColor, glowMix, ambient.getAlpha());
    }

    /** Runs the glass through the same colour blend as the room's TransitionDrawable. */
    private void blendGlassGlow(int from, long ms) {
        if (glowBlend != null) glowBlend.cancel();
        glowFrom = from;
        glowMix = 0f;
        glowBlend = android.animation.ValueAnimator.ofFloat(0f, 1f);
        glowBlend.setDuration(ms);
        glowBlend.addUpdateListener(a -> {
            glowMix = (float) a.getAnimatedValue();
            syncGlassGlow();
        });
        glowBlend.start();
    }

    /** The glow's shape in white, drawn on first use and kept: a tint gives it each app's colour. */
    private Bitmap ambientShape() {
        if (ambientShape != null) return ambientShape;
        int w = 480;
        int h = 270;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setShader(new RadialGradient(
                w * 0.32f, h * 0.42f, w * 0.62f,
                new int[]{0x5CFFFFFF, 0x26FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.45f, 1f},
                Shader.TileMode.CLAMP));
        new Canvas(bmp).drawRect(0, 0, w, h, paint);
        ambientShape = bmp;
        return bmp;
    }

    /** With crossFade, the old glow fades into the new one (two small textures, one blend). */
    private void setAmbient(int color, boolean crossFade) {
        if (color == ambientColor && ambient.getBackground() != null) return;
        android.graphics.drawable.Drawable old = ambient.getBackground();
        if (old instanceof android.graphics.drawable.TransitionDrawable) {
            android.graphics.drawable.TransitionDrawable t = (android.graphics.drawable.TransitionDrawable) old;
            old = t.getDrawable(t.getNumberOfLayers() - 1);   // a blend still running: start from where it was heading
        }
        int previous = ambientColor;
        ambientColor = color;
        // Every app's glow is the same shape in a different colour, so the shape is drawn once and
        // each app only tints it. Drawing a fresh bitmap per move cost a CPU fill, half a megabyte
        // and a texture upload every time focus moved, which is what made moving around feel heavy
        // once every tile, not only the dock, tinted the room.
        BitmapDrawable drawable = new BitmapDrawable(getResources(), ambientShape());
        drawable.setGravity(Gravity.FILL);
        drawable.setColorFilter(new android.graphics.PorterDuffColorFilter(
                0xFF000000 | color, android.graphics.PorterDuff.Mode.SRC_IN));
        if (crossFade && old != null) {
            android.graphics.drawable.TransitionDrawable t = new android.graphics.drawable.TransitionDrawable(
                    new android.graphics.drawable.Drawable[]{old, drawable});
            t.setCrossFadeEnabled(true);
            ambient.setBackground(t);
            t.startTransition(450);
            // The glass blends with the room, over the same 450 ms, instead of jumping ahead of it.
            blendGlassGlow(previous, 450);
        } else {
            ambient.setBackground(drawable);
            if (glowBlend != null) glowBlend.cancel();
            glowFrom = color;
            glowMix = 1f;
            syncGlassGlow();
        }
    }

    /** Focus has left the apps altogether: both the shelf and the glow go. */
    private void hideHero() {
        hideShelf();
        if (!ambientShown) return;
        ambientShown = false;
        ambient.animate().alpha(0f).setDuration(reducedMotion ? 140 : 300)
                .setUpdateListener(a -> syncGlassGlow()).start();
    }

    private void hideShelf() {
        if (!heroShown) return;
        heroShown = false;
        heroShelf.animate().alpha(0f).setDuration(reducedMotion ? 100 : 160).start();
        if (islamicShelf != null) islamicShelf.animate().alpha(0f).setDuration(reducedMotion ? 100 : 160).start();
    }

    /**
     * Lights the room in this app's colour. From one app to the next it blends straight across,
     * with no dip to plain in between, whether the move is along the dock, down into the grid or
     * back up again.
     */
    private void showAmbient(int color) {
        // Never tint the screen from the focused app. Focus ring handles colour instead.
        if (ambient != null) {
            ambient.animate().cancel();
            ambient.setAlpha(0f);
        }
        ambientShown = false;
        Backdrop.setGlow(null, 0, 0, 1f, 0f);
    }

    private void hideGlass() {
        glassShown = false;
    }

    // ---- navigation ------------------------------------------------------------------------------

    // ---- arranging the tiles ---------------------------------------------------------------------

    /** The tile being moved (adapter position), or -1; its card wiggles while it is. */
    private int movingPos = -1;
    private View movingCard;
    private android.animation.ObjectAnimator wiggle;
    /** A key whose release is swallowed: the OK or Back that put a moved tile down must not also open it. */
    private int swallowRelease = -1;
    /**
     * Slides the tiles into their new places while an app is moved. The grid has no item animations
     * otherwise: they would replay on every rebuild and cost frames while scrolling.
     */
    private androidx.recyclerview.widget.DefaultItemAnimator moveSlide;

    /** Holding OK on an app: a glass menu to move it, or to open Android's page for it. */
    @Override
    public boolean onTileHeld(int position, View card) {
        if (openMenu != null || movingPos >= 0) return true;
        FrameLayout panel = (FrameLayout) getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        final String key = adapter.keyAt(position);
        if (adapter.canMove(position)) {
            addInputRow(rows, () -> {
                // No selection gliding back from the menu: it is simply gone, and the app wiggles.
                glider.hideNow();
                gliderOnPill = false;
                closeMenu(true);
            }, R.drawable.ic_move, getString(R.string.tile_move), -1, () -> startMove(key));
        }
        addInputRow(rows, () -> closeMenu(false), R.drawable.ic_info, getString(R.string.tile_app_info), -1,
                () -> adapter.openAppInfo(adapter.positionOf(key)));
        final String heldPkg = adapter.tileAt(position).pkg;
        addInputRow(rows, () -> closeMenu(false), R.drawable.ic_lock, "Sorok app", -1, () -> hideApp(heldPkg));
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int width = Math.max((int) (190 * density), panel.getMeasuredWidth());
        // Under the app when there is room; over it in the dock, which sits near the bottom.
        panel.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED);
        card.getLocationInWindow(menuAt);
        root.getLocationInWindow(menuGliderAt);
        int below = menuAt[1] - menuGliderAt[1] + card.getHeight() + (int) (18 * density) + panel.getMeasuredHeight();
        showMenu(panel, rows, card, width, below > root.getHeight() - (int) (24 * density));
        return true;
    }

    /** Picks the app up: it wiggles, the arrows carry it, and OK or Back puts it down. */
    private void startMove(String key) {
        int pos = adapter.positionOf(key);
        RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(pos);
        if (vh == null || !adapter.canMove(pos)) return;
        movingPos = pos;
        movingCard = vh.itemView.findViewById(R.id.card);
        movingCard.requestFocus();
        glider.setPaneHidden(true);
        if (moveSlide == null) {
            moveSlide = new androidx.recyclerview.widget.DefaultItemAnimator();
            moveSlide.setSupportsChangeAnimations(false);
            moveSlide.setMoveDuration(reducedMotion ? 140 : 220);
        }
        grid.setItemAnimator(moveSlide);
        float tilt = reducedMotion ? 0.8f : 1.4f;
        wiggle = android.animation.ObjectAnimator.ofFloat(movingCard, View.ROTATION, -tilt, tilt);
        wiggle.setDuration(reducedMotion ? 260 : 140);
        wiggle.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        wiggle.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        wiggle.start();
    }

    /** Puts the moving app down where it is; the order was kept as it moved. */
    private void finishMove() {
        if (movingPos < 0) return;
        if (wiggle != null) wiggle.cancel();
        wiggle = null;
        if (movingCard != null) movingCard.animate().rotation(0f).setDuration(120).start();
        movingCard = null;
        movingPos = -1;
        glider.setPaneHidden(false);
        // Back to no item animations once the last slide has finished.
        RecyclerView.ItemAnimator slide = grid.getItemAnimator();
        if (slide != null) slide.isRunning(() -> {
            if (movingPos < 0 && grid.getItemAnimator() == slide) grid.setItemAnimator(null);
        });
    }

    /** Carries the moving app one step, the other tiles making room, and the selection follows it. */
    private void stepMove(int keyCode) {
        int last = adapter.lastMovable();
        int to = movingPos;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (movingPos % COLUMNS > 0) to = movingPos - 1;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (movingPos % COLUMNS < COLUMNS - 1) to = Math.min(movingPos + 1, last);
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                if (movingPos >= COLUMNS) to = movingPos - COLUMNS;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (movingPos / COLUMNS < last / COLUMNS) to = Math.min(movingPos + COLUMNS, last);
                break;
            default:
                return;
        }
        if (!adapter.move(movingPos, to)) return;
        movingPos = to;
        final View card = movingCard;
        final int pos = to;
        // Once the tiles have shifted, glide the selection (and the shelf, and the scroll) to it.
        grid.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                grid.removeOnLayoutChangeListener(this);
                grid.post(() -> {
                    if (movingPos == pos && card != null && card.isAttachedToWindow()) onTileFocused(pos, card);
                });
            }
        });
        grid.requestLayout();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        lastUserInteraction = android.os.SystemClock.elapsedRealtime();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        lastUserInteraction = android.os.SystemClock.elapsedRealtime();
        if (screensaverActive) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                dismissScreensaver();
            }
            return true;
        }
        int code = event.getKeyCode();
        if (code != KeyEvent.KEYCODE_BACK && code != KeyEvent.KEYCODE_ESCAPE) lastHomeBackAt = -1L;
        // UI #3 modal drawer: remote focus stays inside until Back.
        if (pillAllAppsDrawer != null) {
            if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) {
                if (event.getAction() == KeyEvent.ACTION_UP && !event.isCanceled()) handleBackPress();
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN
                    || code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    View focused = getCurrentFocus();
                    if (drawerTiles != null && !drawerTiles.isEmpty()) {
                        int cur = focused == null ? -1 : drawerTiles.indexOf(focused);
                        int n = drawerTiles.size();
                        int to;
                        if (cur < 0) to = 0;
                        else if (code == KeyEvent.KEYCODE_DPAD_LEFT) to = cur - 1;
                        else if (code == KeyEvent.KEYCODE_DPAD_RIGHT) to = cur + 1;
                        else if (code == KeyEvent.KEYCODE_DPAD_UP) to = cur - drawerCols;
                        else {
                            to = cur + drawerCols;
                            // A short last row: DOWN from above it lands on its last tile instead of doing nothing.
                            if (to >= n && cur / drawerCols < (n - 1) / drawerCols) to = n - 1;
                        }
                        if (to >= 0 && to < n) drawerTiles.get(to).requestFocus();
                    } else if (focused == null || !isDescendantOf(focused, pillAllAppsDrawer)) {
                        pillAllAppsDrawer.requestFocus();
                    } else {
                        int direction = code == KeyEvent.KEYCODE_DPAD_UP ? View.FOCUS_UP
                                : code == KeyEvent.KEYCODE_DPAD_DOWN ? View.FOCUS_DOWN
                                : code == KeyEvent.KEYCODE_DPAD_LEFT ? View.FOCUS_LEFT : View.FOCUS_RIGHT;
                        View next = focused.focusSearch(direction);
                        if (next != null && isDescendantOf(next, pillAllAppsDrawer)) next.requestFocus();
                    }
                }
                return true;
            }
            if (code != KeyEvent.KEYCODE_DPAD_CENTER && code != KeyEvent.KEYCODE_ENTER
                    && code != KeyEvent.KEYCODE_NUMPAD_ENTER) return true;
        }
        if (code == swallowRelease && event.getAction() == KeyEvent.ACTION_UP) {
            swallowRelease = -1;
            return true;
        }
        if (code == KeyEvent.KEYCODE_APP_SWITCH) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                startActivity(new Intent(this, RecentAppsActivity.class));
            }
            return true;
        }
        if (code == KeyEvent.KEYCODE_HOME || code == KeyEvent.KEYCODE_ALL_APPS) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                if (LyricsOverlay.closeIfShowing()) return true;
                if (screensaverActive) {
                    dismissScreensaver();
                    return true;
                }
                long now = android.os.SystemClock.uptimeMillis();
                if (now - lastHomePressTime < DOUBLE_HOME_INTERVAL_MS) {
                    lastHomePressTime = 0;
                    if (singleHomeRunnable != null) {
                        handler.removeCallbacks(singleHomeRunnable);
                        singleHomeRunnable = null;
                    }
                    startActivity(new Intent(this, RecentAppsActivity.class));
                    return true;
                } else {
                    lastHomePressTime = now;
                    singleHomeRunnable = () -> {
                        singleHomeRunnable = null;
                        if (screensaverActive) {
                            dismissScreensaver();
                        } else {
                            if (cardPrompt != null) cardPrompt.dismiss();
                            if (openPopup != null) openPopup.dismiss();
                            closeMenu(false);
                            if (movingPos >= 0) finishMove();
                            showNightstandScreensaver();
                        }
                    };
                    handler.postDelayed(singleHomeRunnable, DOUBLE_HOME_INTERVAL_MS);
                    return true;
                }
            }
            return true;
        }
        if (movingPos < 0) {
            if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) {
                if (event.getAction() == KeyEvent.ACTION_UP) {
                    if (!event.isCanceled()) handleBackPress();
                }
                return true;
            }
            return super.dispatchKeyEvent(event);
        }
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (down) stepMove(code);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE:
                if (down) {
                    finishMove();
                    swallowRelease = code;
                }
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    @Override
    public boolean onTileVerticalKey(int position, int keyCode) {
        int count = adapter.getItemCount();
        int target;
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            int step = keyCode == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1;
            int next = position + step;
            if (next >= 0 && next < count && next / COLUMNS == position / COLUMNS) focusTile(next);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            if (position < COLUMNS) {
                if (!focusWidgets(true)) focusHomeSettings();
                return true;
            }
            target = position - COLUMNS;
        } else {
            int lastRowStart = ((count - 1) / COLUMNS) * COLUMNS;
            if (position >= lastRowStart) return true;     // already on the last row: stay put
            target = Math.min(position + COLUMNS, count - 1);
        }
        focusTile(target);
        return true;
    }

    /** The tile {@link #focusWhenSettled} focuses once the grid stops scrolling to it. */
    private int pendingFocus;
    private final RecyclerView.OnScrollListener focusWhenSettled = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(@NonNull RecyclerView rv, int newState) {
            if (newState != RecyclerView.SCROLL_STATE_IDLE) return;
            rv.removeOnScrollListener(this);
            RecyclerView.ViewHolder h = rv.findViewHolderForAdapterPosition(pendingFocus);
            View target = h != null ? h.itemView.findViewById(R.id.card) : rv.getChildAt(0);
            if (target != null) target.requestFocus();
        }
    };

    private void focusTile(int position) {
        if (adapter.getItemCount() == 0) {
            View clock = findViewById(R.id.clock);
            if (clock != null) clock.requestFocus();
            return;
        }
        final int pos = Math.max(0, Math.min(position, adapter.getItemCount() - 1));
        RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(pos);
        if (vh != null) {
            View card = vh.itemView.findViewById(R.id.card);
            // Already focused (e.g. back from an app): no focus change fires, so restore the glass by hand.
            if (card.isFocused()) onTileFocused(pos, card);
            else card.requestFocus();
            return;
        }
        // Not laid out yet: scroll there, then focus once the scroll settles. One listener at most,
        // aimed at the latest target, so asking again mid-scroll cannot pull focus back to an older one.
        pendingFocus = pos;
        grid.removeOnScrollListener(focusWhenSettled);
        grid.addOnScrollListener(focusWhenSettled);
        grid.smoothScrollToPosition(pos);
    }

    // ---- top bar ---------------------------------------------------------------------------------

    private void updateShamsiDate() {
        if (shamsi) shamsiDate.setText(Shamsi.today());
    }

    private void updatePrayerTimes() {
        if (prayerTimesView != null) {
            prayerTimesView.setText(PrayerTimes.getFormatted(this));
        }
        updateIslamicShelf();
        if (screensaverActive) {
            updateNightstandScreensaver();
        }
    }

    private void updateWeatherAqi() {
        WeatherCompactView compactWeather = findViewById(R.id.weatherCompact);
        if (compactWeather != null) compactWeather.update(WeatherAirQuality.getFullWeather(this));
        if (heroWeatherPill != null) heroWeatherPill.update(WeatherAirQuality.getFullWeather(this));
        if (pillsWeather != null) pillsWeather.update(WeatherAirQuality.getFullWeather(this));
        if (weatherAirQualityView != null) {
            weatherAirQualityView.setText(WeatherAirQuality.getFormatted(this));
        }
    }

    private void updateIslamicShelf() {
        if (islamicShelf == null) return;
        setupChombbWidgetShelf();
        if (!"classic".equals(getHomeLayout())) return;   // the prayer/ayat shelf is Classic only
        applyPrayerVisibility();
        applyAyatVisibility();
        DailyAyat.Ayat ayat = DailyAyat.getToday();
        if (ayatRef != null) ayatRef.setText(ayat.reference);
        if (ayatArabic != null) ayatArabic.setText(ayat.arabic);
        if (ayatTranslation != null) ayatTranslation.setText(ayat.translation);

        if (prayerHeader != null) {
            prayerHeader.setText("WAKTU SOLAT  •  " + PrayerTimes.getHijriDate().toUpperCase(Locale.ROOT));
        }

        PrayerTimes.PrayerItem[] items = PrayerTimes.getPrayerItems(this);
        if (items != null && items.length >= 6) {
            TextView[] labels = {lblSubuh, lblSyuruk, lblZohor, lblAsar, lblMaghrib, lblIsyak};
            TextView[] times = {timeSubuh, timeSyuruk, timeZohor, timeAsar, timeMaghrib, timeIsyak};

            for (int i = 0; i < 6; i++) {
                if (times[i] != null) times[i].setText(items[i].timeStr);
                if (labels[i] != null) {
                    labels[i].setText(items[i].name);
                    if (items[i].isNext) {
                        labels[i].setTextColor(0xFF4ADE80);
                        if (times[i] != null) times[i].setTextColor(0xFF4ADE80);
                    } else {
                        labels[i].setTextColor(0xB3FFFFFF);
                        if (times[i] != null) times[i].setTextColor(0xFFFFFFFF);
                    }
                }
            }
        }
    }

    private void updateDateAndPeriod() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        String period;
        if (hour >= 1 && hour < 12) period = "PG";
        else if (hour >= 12 && hour < 19) period = "PTG";
        else period = "MLM";

        int day = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        String[] malayMonths = {"JAN", "FEB", "MAC", "APR", "MEI", "JUN", "JUL", "OGO", "SEP", "OKT", "NOV", "DIS"};
        String mStr = (month >= 0 && month < 12) ? malayMonths[month] : "";
        String dateStr = day + " " + mStr + " " + year;

        if (ampmView != null) ampmView.setText(period);
        if (dateView != null) dateView.setText(dateStr);
    }

    /** Shows the Wi-Fi network name on the button when we can read it, otherwise the connection type. */
    private void updateWifiLabel() {
        if (btnWifi.getVisibility() == View.GONE) return;   // show_network_pill off
        String text = getString(R.string.wifi);
        boolean vpn = false, online = false;
        int icon = R.drawable.ic_wifi;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            boolean wifi = false, ethernet = false;
            // All networks, not just the active one: with a VPN up the active network is the VPN itself.
            for (Network net : cm != null ? cm.getAllNetworks() : new Network[0]) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(net);
                if (caps == null) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                    vpn = true;
                    continue;
                }
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                online = true;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) ethernet = true;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true;
            }
            if (!online) {
                text = getString(R.string.offline);
                vpn = false;
            } else if (ethernet) {
                text = getString(R.string.ethernet);
                icon = R.drawable.ic_ethernet;
            } else if (wifi) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo info = wm != null ? wm.getConnectionInfo() : null;
                String ssid = info != null ? info.getSSID() : null;
                if (ssid != null) {
                    ssid = ssid.replace("\"", "").trim();
                    if (!ssid.isEmpty() && !ssid.contains("unknown") && !ssid.equals("0x")) text = ssid;
                }
            }
        } catch (Exception ignored) {
        }
        btnWifi.setText(text);
        btnWifi.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
    }

    /** Shows an Apple TV-style frosted glass Wi-Fi control center popup. */
    private void showWifiPopup() {
        if (openMenu != null) return;
        SoundEffects.playSelect();
        View anchor = btnWifi;
        FrameLayout panel = (FrameLayout) getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        Runnable close = () -> closeMenu(false);

        String ssid = getString(R.string.wifi);
        String ip = "";
        boolean isConnected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            Network activeNet = cm != null ? cm.getActiveNetwork() : null;
            if (activeNet != null) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(activeNet);
                if (caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))) {
                    isConnected = true;
                }
            }
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wm.isWifiEnabled()) {
                WifiInfo info = wm.getConnectionInfo();
                if (info != null && info.getNetworkId() != -1) {
                    String s = info.getSSID();
                    if (s != null && !s.equals("<unknown ssid>") && !s.isEmpty()) {
                        ssid = s.replaceAll("^\"|\"$", "");
                    }
                    int ipVal = info.getIpAddress();
                    if (ipVal != 0) {
                        ip = String.format(Locale.getDefault(), "%d.%d.%d.%d",
                                (ipVal & 0xff), (ipVal >> 8 & 0xff), (ipVal >> 16 & 0xff), (ipVal >> 24 & 0xff));
                    }
                }
            }
        } catch (Exception ignored) {
        }

        int width = (int) (240 * density);

        // Row 1: Current Wi-Fi status & SSID
        addInputRow(rows, close, R.drawable.ic_wifi, ssid, isConnected ? TvInputManager.INPUT_STATE_CONNECTED : TvInputManager.INPUT_STATE_DISCONNECTED, () -> {
            SoundEffects.playSelect();
            open(systemIntent(Settings.ACTION_WIFI_SETTINGS));
        });

        addSeparator(rows);

        // Row 2: Tetapan Wi-Fi
        addInputRow(rows, close, R.drawable.ic_settings, "Tetapan Wi-Fi", -1, () -> {
            SoundEffects.playSelect();
            open(systemIntent(Settings.ACTION_WIFI_SETTINGS));
        });

        // Row 3: Tutup
        addInputRow(rows, close, R.drawable.ic_move, "Tutup", -1, () -> {
            SoundEffects.playSelect();
            closeMenu(true);
        });

        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        width = Math.max(width, panel.getMeasuredWidth());

        showMenu(panel, rows, anchor, width, false);
    }

    /** Compact CHOMBB quick panel, separate from the preserved full launcher settings. */
    /** The glass panel opened by the clock (see GlassSettingsPanel). */
    private void showGlassSettingsPanel() {
        if (openMenu != null) closeMenu(false);
        SoundEffects.playSelect();
        final View qsOrigin = getCurrentFocus();
        final int nextLayout = (homeLayoutIndex() + 1) % HOME_LAYOUTS.length;
        GlassSettingsPanel.Host qsHost = new GlassSettingsPanel.Host() {
            @Override public void openWifi() { open(systemIntent(Settings.ACTION_WIFI_SETTINGS)); }
            @Override public void openBluetooth() { open(systemIntent(Settings.ACTION_BLUETOOTH_SETTINGS)); }
            @Override public void openInputs() { showInputs(); }
            @Override public void turnOff() { turnOffTv(); }
            @Override public void nextWallpaper() {
                if (wallpapers.size() > 1) {
                    showNextWallpaper(true);
                    startWallpaperRotation();
                } else {
                    Toast.makeText(MainActivity.this, "Tiada gambar lain. Tambah wallpaper dulu.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public long wallpaperIntervalMs() { return wallpaperIntervalMs; }
            @Override public void setWallpaperIntervalMs(long ms) {
                wallpaperIntervalMs = ms;
                getSharedPreferences("wallpaper_ui", MODE_PRIVATE).edit().putLong("interval_ms", ms).apply();
                startWallpaperRotation();
            }
            @Override public void pickScreensaverWallpaper() { showScreensaverWallpaperDialog(); }
            @Override public void refreshLocationData() { refreshLocationDependentData(); }
            @Override public void preferences() { showSettingsPopup(); }
            @Override public void allSettings() { showChombbQuickSettings(); }
            @Override public String nextLayoutName() { return HOME_LAYOUT_NAMES[nextLayout]; }
            @Override public void nextLayout() { changeHomeLayout(nextLayout); }
        };
        if ("material".equals(getHomeLayout())) {
            MaterialPalette pal = pillDock != null ? pillDock.materialStyle().current() : MaterialPalette.of(MaterialPalette.DEFAULT_SEED);
            GlassSettingsPanel.showMaterial(this, qsHost, pal, qsOrigin);
        } else {
            GlassSettingsPanel.show(this, qsHost, getHomeLayout(), qsOrigin);
        }
    }

    /** Picks the picture behind the screensaver: follow Home, a slideshow, one uploaded picture, or plain dark. */
    private void showScreensaverWallpaperDialog() {
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        labels.add("Ikut wallpaper Home");
        actions.add(() -> StandbyWallpaper.set(this, StandbyWallpaper.HOME, null));
        labels.add("Slideshow semua gambar");
        actions.add(() -> StandbyWallpaper.set(this, StandbyWallpaper.SLIDESHOW, null));
        labels.add("Gelap (hitam sahaja)");
        actions.add(() -> StandbyWallpaper.set(this, StandbyWallpaper.DARK, null));
        int shown = 0;
        for (final File f : StandbyWallpaper.candidates(this)) {
            if (shown++ >= 40) break;
            labels.add("🖼  " + f.getName());
            actions.add(() -> StandbyWallpaper.set(this, StandbyWallpaper.FILE, f.getPath()));
        }
        labels.add("＋  Upload gambar baru dari phone (QR)");
        actions.add(this::showWallpaperUploadQrDialog);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Wallpaper screensaver (sekarang: " + StandbyWallpaper.describe(this) + ")")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    actions.get(which).run();
                    if (which < labels.size() - 1) {
                        Toast.makeText(this, "Wallpaper screensaver ditukar", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showChombbQuickSettings() {
        if (openMenu != null) closeMenu(false);
        SoundEffects.playSelect();
        final Dialog dialog = new Dialog(this);
        final float d = getResources().getDisplayMetrics().density;
        final int white = 0xFFF2F6FF;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pd = Math.round(10 * d);
        panel.setPadding(pd, pd, pd, pd);
        android.graphics.drawable.GradientDrawable panelBg = new android.graphics.drawable.GradientDrawable();
        int glassPercent = getSharedPreferences("chombb_appearance", MODE_PRIVATE).getInt("glass_transparency", 70);
        int cornerDp = getSharedPreferences("chombb_appearance", MODE_PRIVATE).getInt("corner_radius", 18);
        panelBg.setColor(Color.argb(Math.max(65, Math.min(235, glassPercent * 255 / 100)), 58, 70, 92));
        panelBg.setCornerRadius((cornerDp + 3) * d);
        panelBg.setStroke(Math.max(1, Math.round(d)), 0xB4F1F5FF);
        panel.setBackground(ChombbFrostedGlass.fromActivity(getWindow().getDecorView(),
                panel, d, cornerDp + 9, 145));
        android.widget.GridLayout tiles = new android.widget.GridLayout(this);
        tiles.setColumnCount(3);
        tiles.setUseDefaultMargins(false);
        panel.addView(tiles);

        final java.util.ArrayList<View> choices = new java.util.ArrayList<>();
        addChombbQuickTile(tiles, choices, "Wi-Fi", R.drawable.chombb_quick_wifi,
                () -> open(systemIntent(Settings.ACTION_WIFI_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Settings", R.drawable.chombb_quick_settings,
                () -> open(systemIntent(Settings.ACTION_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Preferences", R.drawable.chombb_quick_preferences,
                this::showSettingsPopup, d, white);
        addChombbQuickTile(tiles, choices, "Sound", R.drawable.chombb_quick_sound,
                () -> open(systemIntent(Settings.ACTION_SOUND_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Accessibility", R.drawable.chombb_quick_accessibility,
                () -> open(systemIntent(Settings.ACTION_ACCESSIBILITY_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Display", R.drawable.chombb_quick_display,
                () -> open(systemIntent(Settings.ACTION_DISPLAY_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Google Home", R.drawable.chombb_quick_home,
                () -> open(systemIntent(Settings.ACTION_SETTINGS)), d, white);
        addChombbQuickTile(tiles, choices, "Screensaver", R.drawable.chombb_quick_screensaver,
                () -> open(systemIntent(Settings.ACTION_DREAM_SETTINGS)), d, white);

        View divider = new View(this);
        divider.setBackgroundColor(0x66DCEAFF);
        LinearLayout.LayoutParams dividerP = new LinearLayout.LayoutParams(-1, Math.max(1, Math.round(d)));
        dividerP.topMargin = Math.round(6*d);
        panel.addView(divider, dividerP);
        TextView day = new TextView(this);
        day.setText(new SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH).format(new Date()));
        day.setTextColor(white);
        day.setGravity(Gravity.CENTER);
        day.setTextSize(11);
        day.setPadding(0, Math.round(7*d), 0, Math.round(1*d));
        panel.addView(day);

        for (int i = 0; i < choices.size(); i++) {
            final int pos = i;
            View tile = choices.get(i);
            tile.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                int next = pos;
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) next = pos - 1;
                else if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) next = pos + 1;
                else if (keyCode == KeyEvent.KEYCODE_DPAD_UP) next = pos - 3;
                else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) next = pos + 3;
                else if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
                    v.performClick(); return true;
                } else return false;
                if (next >= 0 && next < choices.size()) choices.get(next).requestFocus();
                return true;
            });
        }
        dialog.setContentView(panel);
        dialog.setCanceledOnTouchOutside(true);
        // Launch a sub-menu only after the quick panel has released DPAD focus.
        for (int i = 0; i < choices.size(); i++) {
            View tile = choices.get(i);
            Object stored = tile.getTag();
            if (!(stored instanceof Runnable)) continue;
            Runnable target = (Runnable) stored;
            final boolean opensPreferences = i == 2;
            tile.setOnClickListener(v -> {
                if (!opensPreferences) dialog.dismiss();
                target.run();
            });
        }
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            android.view.WindowManager.LayoutParams p = window.getAttributes();
            p.width = Math.min(Math.round(265*d),
                    Math.round(getResources().getDisplayMetrics().widthPixels * 0.21f));
            p.height = -2;
            p.gravity = Gravity.TOP | Gravity.RIGHT;
            p.x = Math.round(24*d);
            p.y = Math.round(82*d);
            p.dimAmount = 0.10f;
            window.setAttributes(p);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        if (!reducedMotion) PanelMotion.openDialog(dialog, panel, 0.86f);
        if (choices.size() > 1) choices.get(1).requestFocus();
    }

    private void addChombbQuickTile(android.widget.GridLayout grid, java.util.List<View> choices,
                                    String name, int iconRes, Runnable action, float d, int ink) {
        // Compact 3-3-2 glass tiles: the icon square highlights; the label remains below.
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setFocusable(true);
        column.setClickable(true);
        column.setTag(action);
        int margin = Math.round(3*d);
        android.widget.GridLayout.LayoutParams layout = new android.widget.GridLayout.LayoutParams();
        layout.width = 0;
        layout.height = Math.round(67*d);
        layout.columnSpec = android.widget.GridLayout.spec(choices.size() % 3, 1f);
        layout.setMargins(margin, margin, margin, margin);
        grid.addView(column, layout);

        LinearLayout iconBox = new LinearLayout(this);
        iconBox.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(
                Math.round(48*d), Math.round(43*d));
        boxParams.gravity = Gravity.CENTER_HORIZONTAL;
        column.addView(iconBox, boxParams);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(ink);
        iconBox.addView(icon, new LinearLayout.LayoutParams(Math.round(24*d), Math.round(24*d)));
        TextView text = new TextView(this);
        text.setText(name);
        text.setTextSize(10);
        text.setSingleLine(true);
        text.setEllipsize(TextUtils.TruncateAt.END);
        text.setTextColor(ink);
        text.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(-1, Math.round(20*d));
        column.addView(text, textParams);

        android.graphics.drawable.GradientDrawable plain = new android.graphics.drawable.GradientDrawable();
        plain.setColor(0x245E7792);
        plain.setCornerRadius(11*d);
        plain.setStroke(Math.max(1, Math.round(d)), 0x90D9E7F5);
        android.graphics.drawable.GradientDrawable focus = new android.graphics.drawable.GradientDrawable();
        focus.setColor(0xEE16283D);
        focus.setCornerRadius(11*d);
        focus.setStroke(Math.max(2, Math.round(2*d)), chombbAccentColor());
        iconBox.setBackground(plain);
        iconBox.setElevation(2*d);
        column.setOnFocusChangeListener((v, hasFocus) -> {
            iconBox.setBackground(hasFocus ? focus : plain);
            iconBox.setElevation((hasFocus ? 11 : 2)*d);
            boolean reduced = "Reduced".equals(getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                    .getString("ui_animation", "Smooth"));
            iconBox.setScaleX(hasFocus && !reduced ? 1.04f : 1f);
            iconBox.setScaleY(hasFocus && !reduced ? 1.04f : 1f);
            text.setTypeface(null, hasFocus ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        });
        choices.add(column);
    }

    private void showLauncherStyleDialog() {
        final String[] styles = {"Glass Classic (Original)", "Apple Glass (Preview)"};
        final String[] values = {"classic", "apple"};
        new android.app.AlertDialog.Builder(this)
                .setTitle("Appearance / Launcher Style")
                .setSingleChoiceItems(styles,
                        "apple".equals(getSharedPreferences("launcher_appearance", MODE_PRIVATE)
                                .getString("launcher_style", "classic")) ? 1 : 0,
                        (dialog, which) -> {
                            getSharedPreferences("launcher_appearance", MODE_PRIVATE)
                                    .edit().putString("launcher_style", values[which]).apply();
                            dialog.dismiss();
                            recreate();
                        })
                .setNegativeButton("Cancel", null).show();
    }

    private int chombbAccentColor() {
        String accent = getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                .getString("accent_color", "Blue");
        if ("Cyan".equals(accent)) return 0xFF18B9E7;
        if ("Purple".equals(accent)) return 0xFF8958DA;
        return 0xFF237ED9;
    }

    private android.graphics.drawable.GradientDrawable glassPanelBackground(int fill, int stroke, int radiusDp) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(radiusDp * density);
        bg.setStroke(Math.max(1, (int)density), stroke);
        return bg;
    }

    /** Shows an Apple TV-style frosted glass Settings dropdown menu. */
    private void showSettingsPopup() {
        if (openMenu != null) closeMenu(false);
        SoundEffects.playSelect();
        View anchor = findViewById(R.id.btnSettings);
        if (anchor == null) return;
        // A real modal dialog keeps DPAD focus inside Settings until BACK dismisses it.
        final android.app.Dialog settingsDialog = new android.app.Dialog(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding((int)(18*density), (int)(12*density),
                (int)(18*density), (int)(10*density));
        android.content.SharedPreferences appPref = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
        int opacity = Math.max(65, Math.min(240, Math.round(0xB3 * GlassStyle.factor)));   // same scale as the Home glass
        int radius = appPref.getInt("corner_radius", 18);
        container.setBackground(ChombbFrostedGlass.fromActivity(getWindow().getDecorView(),
                container, density, radius + 9, 154));

        // Mockup-matched title: the original settings callbacks remain intact below.
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleLine = new LinearLayout(this);
        titleLine.setGravity(Gravity.CENTER_VERTICAL);
        TextView settingsGlyph = new TextView(this);
        settingsGlyph.setText("☷");
        settingsGlyph.setTextSize(34);
        settingsGlyph.setGravity(Gravity.CENTER);
        settingsGlyph.setTextColor(0xFFF0F7FF);
        settingsGlyph.setBackground(glassPanelBackground(0x554B688C, 0x7EAED4FF, 15));
        titleLine.addView(settingsGlyph, new LinearLayout.LayoutParams(Math.round(59*density), Math.round(59*density)));
        LinearLayout titleText = new LinearLayout(this);
        titleText.setOrientation(LinearLayout.VERTICAL);
        titleText.setPadding(Math.round(12*density), 0, 0, 0);
        TextView heading = new TextView(this);
        heading.setText("Preferences");
        heading.setTextColor(0xFFFFFFFF);
        heading.setTextSize(25);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        titleText.addView(heading);
        TextView subheading = new TextView(this);
        subheading.setText("Customize your launcher");
        subheading.setTextColor(0xFFC9D2E2);
        subheading.setTextSize(12);
        titleText.addView(subheading);
        titleLine.addView(titleText);
        header.addView(titleLine);
        LinearLayout.LayoutParams headParams = new LinearLayout.LayoutParams(-1, Math.round(86*density));
        container.addView(header, headParams);
        android.widget.ScrollView scroller = new android.widget.ScrollView(this);
        scroller.setFillViewport(false);
        scroller.setVerticalScrollBarEnabled(true);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        scroller.addView(rows);
        container.addView(scroller, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        settingsDialog.setContentView(container);
        settingsDialog.setCanceledOnTouchOutside(false);
        Runnable close = settingsDialog::dismiss;

        // Row 1: Wallpaper
        addInputRow(rows, close, R.drawable.ic_wallpaper, "Wallpaper / Gambar", -1, () -> {
            SoundEffects.playSelect();
            showWallpaperDialog();
        });

        // Video wallpaper is optional; a still image remains the default on low-memory TVs.
        boolean videoOn = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("video_wallpaper_enabled", false);
        addInputRow(rows, close, R.drawable.ic_wallpaper,
                "Video Wallpaper: " + (videoOn ? "ON" : "OFF"), -1, () -> {
                    SoundEffects.playSelect();
                    showVideoWallpaperDialog();
                });

        boolean ayatOn = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("show_daily_ayat", true);
        addInputRow(rows, close, R.drawable.ic_mosque,
                "Ayat Al-Quran: " + (ayatOn ? "ON" : "OFF"), -1, () -> {
                    boolean next = !getSharedPreferences("launcher_settings", MODE_PRIVATE)
                            .getBoolean("show_daily_ayat", true);
                    getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                            .putBoolean("show_daily_ayat", next).apply();
                    applyAyatVisibility();
                    Toast.makeText(MainActivity.this,
                            "Ayat Al-Quran " + (next ? "dipaparkan" : "disembunyikan"),
                            Toast.LENGTH_SHORT).show();
                });

        boolean prayerOn = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("show_prayer_times", true);
        addInputRow(rows, close, R.drawable.ic_mosque,
                "Paparan Waktu Solat: " + (prayerOn ? "ON" : "OFF"), -1, () -> {
                    boolean next = !getSharedPreferences("launcher_settings", MODE_PRIVATE)
                            .getBoolean("show_prayer_times", true);
                    getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                            .putBoolean("show_prayer_times", next).apply();
                    applyPrayerVisibility();
                    Toast.makeText(MainActivity.this,
                            "Paparan waktu solat " + (next ? "dihidupkan" : "dimatikan"),
                            Toast.LENGTH_SHORT).show();
                });

        addInputRow(rows, close, R.drawable.ic_location, "Lokasi Cuaca (Malaysia)", -1, () -> {
            SoundEffects.playSelect();
            showWeatherLocationDialog();
        });

        // Official APIMS station for air-quality data.
        addInputRow(rows, close, R.drawable.ic_location, "Stesen Jerebu JAS / APIMS", -1, () -> {
            SoundEffects.playSelect();
            showHazeLocationDialog();
        });

        addInputRow(rows, close, R.drawable.ic_mosque, "Lokasi Waktu Solat JAKIM", -1, () -> {
            SoundEffects.playSelect();
            showPrayerZoneDialog();
        });

        // Sound Effects
        String currentSoundTheme = SoundEffects.getActiveTheme(this);
        String soundLabel = "Sound: " + SoundEffects.getThemeDisplayName(currentSoundTheme);
        addInputRow(rows, close, R.drawable.ic_sound, soundLabel, -1, () -> {
            SoundEffects.playSelect();
            showSoundEffectsDialog();
        });

        addSeparator(rows);
        addInputRow(rows, close, R.drawable.ic_wifi, "Wi-Fi Settings", -1, () -> {
            open(systemIntent(Settings.ACTION_WIFI_SETTINGS));
        });

        // Row 5: Check for Updates (OTA)
        addInputRow(rows, close, R.drawable.ic_update, "Check for Updates", -1, () -> {
            SoundEffects.playSelect();
            AppUpdateManager.checkForUpdates(MainActivity.this, true);
        });

        addSeparator(rows);

        // Row 6: All Settings (Android Settings)
        addInputRow(rows, close, R.drawable.ic_settings, "Android Settings", -1, () -> {
            SoundEffects.playSelect();
            open(systemIntent(Settings.ACTION_SETTINGS));
        });

        // Glass Classic preferences: sidebar categories and the original working controls.
        // Reparent the existing rows rather than rewriting their action callbacks.
        final java.util.ArrayList<View> originalRows = new java.util.ArrayList<>();
        for (int i = 0; i < rows.getChildCount(); i++) {
            View child = rows.getChildAt(i);
            if (child.isFocusable()) originalRows.add(child);
        }
        rows.removeAllViews();
        scroller.removeView(rows);
        LinearLayout split = new LinearLayout(this);
        split.setOrientation(LinearLayout.HORIZONTAL);
        android.widget.ScrollView sidebarScroller = new android.widget.ScrollView(this);
        sidebarScroller.setFillViewport(false);
        sidebarScroller.setVerticalScrollBarEnabled(true);
        sidebarScroller.setClipToPadding(false);
        split.addView(sidebarScroller, new LinearLayout.LayoutParams(0, -1, 0.35f));
        LinearLayout sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(0, 0, (int)(12*density), (int)(16*density));
        sidebarScroller.addView(sidebar);
        LinearLayout detail = new LinearLayout(this);
        detail.setOrientation(LinearLayout.VERTICAL);
        split.addView(detail, new LinearLayout.LayoutParams(0, -1, 0.65f));
        container.removeView(scroller);
        container.addView(split, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView keyHints = new TextView(this);
        keyHints.setText("◎  OK  Select         ←  Back         ⌂  Home");
        keyHints.setTextColor(0xFFE5ECF7);
        keyHints.setGravity(Gravity.CENTER);
        keyHints.setTextSize(12);
        container.addView(keyHints, new LinearLayout.LayoutParams(-1, Math.round(37*density)));
        detail.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1f));
        scroller.addView(rows);
        final String[] categories = {"Appearance", "Home & Dock", "Wallpaper", "Apps",
                "Widgets", "System", "About"};
        // Keep every original working action accessible after visual regrouping.
        final int[][] categoryRows = {{}, {}, {0,1}, {}, {}, {2,3,4,5,6,7,8,9,10}, {}};
        final java.util.ArrayList<TextView> sidebarItems = new java.util.ArrayList<>();
        final Runnable[] showCategory = new Runnable[1];
        final int[] activeCategory = {0};
        showCategory[0] = () -> {
            // Preserve the focused setting when a widget toggle/move rebuilds this panel.
            // Sidebar-initiated navigation must keep focus on the sidebar instead.
            View previousFocus = rows.findFocus();
            int restoreIndex = -1;
            if (previousFocus != null) {
                for (int fi = 0; fi < rows.getChildCount(); fi++) {
                    View child = rows.getChildAt(fi);
                    if (child == previousFocus || (child instanceof ViewGroup &&
                            isViewInside(previousFocus, child))) {
                        restoreIndex = fi;
                        break;
                    }
                }
            }
            rows.removeAllViews();
            for (int i = 0; i < sidebarItems.size(); i++) {
                TextView entry = sidebarItems.get(i);
                entry.setTextColor(i == activeCategory[0] ? 0xFFFFFFFF : 0xFFD0D9E8);
                entry.setTag(i == activeCategory[0] ? "chombb_sidebar_active" : "chombb_sidebar_other");
                entry.setBackground(glassPanelBackground(i == activeCategory[0] ? 0xD52885E9 : 0x184A5871,
                        i == activeCategory[0] ? 0xFFBDEAFF : 0x005F7999, 15));
            }
            if (activeCategory[0] == 0) {
                TextView sectionTitle = new TextView(this);
                sectionTitle.setText("◉  Appearance");
                sectionTitle.setTextSize(20);
                sectionTitle.setTypeface(null, android.graphics.Typeface.BOLD);
                sectionTitle.setTextColor(0xFFF8FAFF);
                sectionTitle.setPadding(Math.round(10*density), Math.round(4*density),0,Math.round(7*density));
                rows.addView(sectionTitle, new LinearLayout.LayoutParams(-1, Math.round(41*density)));
                addChombbAppearanceRows(rows);
            } else if (activeCategory[0] == 1) {
                addAppearanceRow(rows, "Dock", "5 Apps", () ->
                        Toast.makeText(this, "Dock uses your selected five pinned apps", Toast.LENGTH_SHORT).show());
                addAppearanceRow(rows, "App Grid Layout", COLUMNS + " Apps", () -> showChombbGridDialog());
            } else if (activeCategory[0] == 2) {
                File uploadedDir = new File(getFilesDir(), "custom_wallpapers");
                File[] uploadedImages = uploadedDir.listFiles((dir, name) -> {
                    String n = name.toLowerCase(java.util.Locale.ROOT);
                    return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png");
                });
                int uploadedCount = uploadedImages == null ? 0 : uploadedImages.length;
                addAppearanceRow(rows, "My Uploads", uploadedCount + " wallpaper", this::showCustomWallpaperManagerDialog);
                if (uploadedCount > 0) {
                    java.util.Arrays.sort(uploadedImages, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    android.widget.HorizontalScrollView uploadScroll = new android.widget.HorizontalScrollView(this);
                    LinearLayout uploadStrip = new LinearLayout(this);
                    uploadStrip.setOrientation(LinearLayout.HORIZONTAL);
                    uploadScroll.addView(uploadStrip);
                    rows.addView(uploadScroll, new LinearLayout.LayoutParams(-1, Math.round(116*density)));
                    final int thumbW = Math.round(160 * density);
                    for (File uploaded : uploadedImages) {
                        ImageView thumb = new ImageView(this);
                        thumb.setBackgroundColor(0x22FFFFFF);
                        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(thumbW, Math.round(94*density));
                        tp.setMargins(Math.round(3*density), Math.round(3*density), Math.round(9*density), Math.round(3*density));
                        uploadStrip.addView(thumb, tp);
                        // Decode one thumbnail at a time off the main thread: with many uploads the old
                        // all-at-once decode ran out of memory and left blank tiles.
                        wallDecoder.execute(() -> {
                            android.graphics.Bitmap tb = null;
                            try {
                                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                                o.inJustDecodeBounds = true;
                                android.graphics.BitmapFactory.decodeFile(uploaded.getAbsolutePath(), o);
                                int sm = 1;
                                while (o.outWidth / (sm * 2) >= thumbW) sm *= 2;
                                o.inJustDecodeBounds = false;
                                o.inSampleSize = sm;
                                o.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;
                                tb = android.graphics.BitmapFactory.decodeFile(uploaded.getAbsolutePath(), o);
                            } catch (Exception | OutOfMemoryError ignored) { }
                            final android.graphics.Bitmap done = tb;
                            handler.post(() -> { if (done != null && !isDestroyed()) thumb.setImageBitmap(done); });
                        });
                        thumb.setFocusable(true);
                        thumb.setClickable(true);
                        // A visible focus ring, so you can see which picture D-pad is on.
                        thumb.setOnFocusChangeListener((v, has) -> {
                            ChombbWidgets.springScale(v, has ? 1.08f : 1f, 420f, 0.66f);
                            v.setBackgroundColor(has ? 0x55FFFFFF : 0x22FFFFFF);
                            if (has) v.bringToFront();
                        });
                        thumb.setOnClickListener(v -> showSingleCustomActionDialog(uploaded));
                        // Long-press OK or Menu: straight to the picture's actions (set / delete).
                        thumb.setOnLongClickListener(v -> { showSingleCustomActionDialog(uploaded); return true; });
                        thumb.setOnKeyListener((v, keyCode, ev) -> {
                            if (ev.getAction() == KeyEvent.ACTION_UP && (keyCode == KeyEvent.KEYCODE_MENU
                                    || keyCode == KeyEvent.KEYCODE_DEL || keyCode == KeyEvent.KEYCODE_FORWARD_DEL)) {
                                showSingleCustomActionDialog(uploaded);
                                return true;
                            }
                            return false;
                        });
                    }
                }
                addAppearanceRow(rows, "Wallpaper Collection", getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural"), this::showWallpaperCollectionsFromPreferences);
                addAppearanceRow(rows, "Video Wallpaper", getSharedPreferences("launcher_settings", MODE_PRIVATE).getBoolean("video_wallpaper_enabled", false) ? "ON" : "OFF", this::showVideoWallpaperDialog);
                addAppearanceRow(rows, "Upload Wallpaper via QR", "Open QR  ›", this::showWallpaperUploadQrDialog);
            } else if (activeCategory[0] == 3) {
                addAppearanceRow(rows, "App Grid Layout", COLUMNS + " Apps", () -> showChombbGridDialog());
                addAppearanceRow(rows, "Show App Label", getSharedPreferences("chombb_appearance", MODE_PRIVATE)
                        .getBoolean("app_labels", true) ? "ON" : "OFF", () -> changeChombbLabels());
                addAppearanceRow(rows, "Hidden Apps", AppAdapter.userHidden(this).size() + " app",
                        () -> showHiddenAppsDialog(() -> showCategory[0].run()));
            } else if (activeCategory[0] == 4) {
                addAppearanceRow(rows,"Notification Access",NowPlaying.hasAccess(this)?"GRANTED":"ENABLE",()->{
                    requestNotificationAccess();
                    showCategory[0].run();
                });
                addAppearanceRow(rows,"Widget Size",ChombbWidgets.widthName(this),()->{
                    ChombbWidgets.changeWidth(this);refreshChombbWidgetShelf();showCategory[0].run();
                });
                addAppearanceRow(rows,"Now Playing Bar",ChombbWidgets.barStyleName(this),()->{
                    ChombbWidgets.changeBarStyle(this);refreshChombbWidgetShelf();showCategory[0].run();
                });
                addAppearanceRow(rows, "Gaya Lirik", LyricLineView.STYLES[ChombbWidgets.lyricStyle(this)], () ->
                        new android.app.AlertDialog.Builder(this).setTitle("Gaya Lirik")
                                .setSingleChoiceItems(LyricLineView.STYLES, ChombbWidgets.lyricStyle(this), (dlg, choice) -> {
                                    ChombbWidgets.setLyricStyle(this, choice);
                                    refreshChombbWidgetShelf();
                                    dlg.dismiss();
                                    showCategory[0].run();
                                }).setNegativeButton("Cancel", null).show());
                addAppearanceRow(rows, "Paparan Screensaver", StandbyView.MODES[StandbyView.mode(this)], () ->
                        new android.app.AlertDialog.Builder(this).setTitle("Paparan Screensaver")
                                .setSingleChoiceItems(StandbyView.MODES, StandbyView.mode(this), (dlg, choice) -> {
                                    StandbyView.setMode(this, choice);
                                    dlg.dismiss();
                                    showCategory[0].run();
                                }).setNegativeButton("Cancel", null).show());
                for (int wi=0;wi<ChombbWidgets.NAMES.length;wi++) {
                    final int idx=wi;
                    addAppearanceRow(rows, ChombbWidgets.NAMES[wi], ChombbWidgets.enabled(this,wi)?"ON":"OFF", () -> {
                        ChombbWidgets.toggle(this,idx); refreshChombbWidgetShelf();showCategory[0].run();
                    });
                    if(ChombbWidgets.enabled(this,wi)) {
                        addAppearanceRow(rows,"Move " + ChombbWidgets.NAMES[wi],"↑ Up",()->{
                            ChombbWidgets.move(this,idx,true);refreshChombbWidgetShelf();showCategory[0].run();
                        });
                        addAppearanceRow(rows,"Move " + ChombbWidgets.NAMES[wi],"↓ Down",()->{
                            ChombbWidgets.move(this,idx,false);refreshChombbWidgetShelf();showCategory[0].run();
                        });
                    }
                }
            } else if (activeCategory[0] == 6) {
                TextView info = new TextView(this);
                info.setText("Glass TV CHOMBB\nInstalled version: " + getInstalledVersion() + "\nLayout: " + getHomeLayout() + "\n\nUpdates can be checked below.");
                info.setTextColor(0xFFF2F6FF);
                info.setTextSize(16);
                info.setPadding((int)(14*density),(int)(14*density),(int)(14*density),(int)(14*density));
                rows.addView(info);
                addAppearanceRow(rows, "Check for Updates", "Check now", () -> AppUpdateManager.checkForUpdates(this, true));
                addAppearanceRow(rows, "Tutorial & Kebenaran", "Buka", () -> showFirstRunSetup());
                addAppearanceRow(rows, "Backup & Restore", "Telefon", () -> showWallpaperUploadQrDialog());
                addAppearanceRow(rows, "Crash Log", CrashLog.count(this) + " rekod", () -> CrashLog.show(this));
            } else {
                for (int index : categoryRows[activeCategory[0]]) {
                    if (index < originalRows.size()) {
                        View item = originalRows.get(index);
                        if (item.getParent() instanceof ViewGroup) ((ViewGroup)item.getParent()).removeView(item);
                        rows.addView(item);
                    }
                }
            }
            if (restoreIndex >= 0) {
                final int wantedIndex = restoreIndex;
                rows.post(() -> {
                    if (rows.getChildCount() == 0) return;
                    int target = Math.min(wantedIndex, rows.getChildCount() - 1);
                    for (int delta = 0; delta < rows.getChildCount(); delta++) {
                        int candidate = Math.max(0, target - delta);
                        View item = rows.getChildAt(candidate);
                        if (item.isFocusable() && item.requestFocus()) {
                            android.graphics.Rect rect = new android.graphics.Rect();
                            item.getDrawingRect(rect);
                            scroller.requestChildRectangleOnScreen(item, rect, false);
                            break;
                        }
                    }
                });
            } else scroller.scrollTo(0, 0);
        };
        for (int i = 0; i < categories.length; i++) {
            final int categoryIndex = i;
            TextView entry = new TextView(this);
            final String[] sidebarGlyphs = {"◉", "⌂", "▧", "▦", "▤", "⚙", "ⓘ"};
            entry.setText(sidebarGlyphs[i] + "   " + categories[i]);
            entry.setTextColor(0xFFF2F6FF);
            entry.setTextSize(16);
            entry.setGravity(Gravity.CENTER_VERTICAL);
            entry.setPadding((int)(12*density),0,(int)(8*density),0);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,(int)(48*density));
            ep.bottomMargin = (int)(5*density);
            sidebar.addView(entry,ep);
            entry.setFocusable(true);
            entry.setOnClickListener(v -> {activeCategory[0] = categoryIndex; showCategory[0].run();});
            entry.setOnFocusChangeListener((v, focused) -> {
                if (!reducedMotion) ChombbWidgets.springScale(v, focused ? 1.035f : 1f, 320f, 0.79f);
                if (focused) {
                    android.graphics.Rect bounds = new android.graphics.Rect();
                    v.getDrawingRect(bounds);
                    sidebarScroller.requestChildRectangleOnScreen(v, bounds, false);
                }
            });
            entry.setOnKeyListener((v,key,event) -> {
                if (event.getAction()!=KeyEvent.ACTION_DOWN) return false;
                if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
                    int next = categoryIndex + (key == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : -1);
                    if (next >= 0 && next < sidebarItems.size()) {
                        sidebarItems.get(next).requestFocus();
                        activeCategory[0] = next;
                        showCategory[0].run();
                    }
                    return true;
                }
                if (key == KeyEvent.KEYCODE_DPAD_RIGHT || key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                    entry.performClick();
                    for (int j = 0; j < rows.getChildCount(); j++) {
                        if (rows.getChildAt(j).isFocusable()) {
                            rows.getChildAt(j).requestFocus();
                            break;
                        }
                    }
                    return true;
                }
                return false;
            });
            sidebarItems.add(entry);
        }
        showCategory[0].run();

        // Explicit focus order for Android TV remotes. Scroll the selected item into view.
        final java.util.ArrayList<View> focusRows = new java.util.ArrayList<>();
        for (View row : originalRows) focusRows.add(row);
        for (int i = 0; i < focusRows.size(); i++) {
            final int index = i;
            View row = focusRows.get(i);
            // Apple TV-style selection: translucent white glass, subtle white rim, bold label.
            final android.graphics.drawable.GradientDrawable selectedBg = new android.graphics.drawable.GradientDrawable();
            selectedBg.setColor(0x55FFFFFF);
            selectedBg.setCornerRadius(12 * density);
            selectedBg.setStroke(Math.max(1, (int)(1.5f * density)), 0xCCFFFFFF);
            final TextView rowTitle = row.findViewById(R.id.title);
            row.setOnFocusChangeListener((v, hasFocus) -> {
                if (!reducedMotion) ChombbWidgets.springScale(v, hasFocus ? 1.025f : 1f, 320f, 0.79f);
                v.setBackground(hasFocus ? selectedBg : null);
                if (rowTitle != null) {
                    rowTitle.setTextColor(hasFocus ? 0xFFFFFFFF : 0xFFE0E5ED);
                    rowTitle.setTypeface(null, hasFocus ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
                }
                if (hasFocus) scroller.post(() -> {
                    android.graphics.Rect rect = new android.graphics.Rect();
                    v.getDrawingRect(rect);
                    scroller.requestChildRectangleOnScreen(v, rect, false);
                });
            });
            row.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    int step = keyCode == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : -1;
                    int next = index + step;
                    while (next >= 0 && next < focusRows.size() && focusRows.get(next).getParent() != rows) next += step;
                    if (next >= 0 && next < focusRows.size()) focusRows.get(next).requestFocus();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { sidebarItems.get(activeCategory[0]).requestFocus(); return true; }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) return true;
                if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                    v.performClick();
                    return true;
                }
                return false;
            });
        }
        settingsDialog.show();
        // Force an initial highlighted row, including after mouse/touch interaction.
        if (!sidebarItems.isEmpty()) sidebarItems.get(activeCategory[0]).requestFocus();
        android.view.Window window = settingsDialog.getWindow();
        if (window != null) {
            android.view.WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.width = Math.min((int)(1000*density),
                    (int)(getResources().getDisplayMetrics().widthPixels * 0.60f));
            attrs.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.80f);
            attrs.gravity = android.view.Gravity.LEFT | android.view.Gravity.CENTER_VERTICAL;
            attrs.x = (int)(getResources().getDisplayMetrics().widthPixels * 0.17f);
            attrs.dimAmount = 0.42f;
            window.setAttributes(attrs);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        if (!reducedMotion) PanelMotion.openDialog(settingsDialog, container, 0.92f);
        if (!sidebarItems.isEmpty()) sidebarItems.get(activeCategory[0]).requestFocus();
    }

    private static final String[] HOME_LAYOUTS = {"classic", "hero", "pills", "material"};
    private static final String[] HOME_LAYOUT_NAMES = {"Classic", "Hero", "Pill", "Material"};

    private int homeLayoutIndex() {
        return Math.max(0, java.util.Arrays.asList(HOME_LAYOUTS).indexOf(getHomeLayout()));
    }

    private void changeHomeLayout(int index) {
        String layout = HOME_LAYOUTS[index];
        if (layout.equals(getHomeLayout())) return;
        getSharedPreferences("chombb_appearance", MODE_PRIVATE).edit().putString("home_layout", layout).apply();
        recreate();
    }

    /** Controls for the mockup's Appearance category, all persisted locally. */
    private void addChombbAppearanceRows(LinearLayout rows) {
        android.content.SharedPreferences pref = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
        int selected = homeLayoutIndex();
        addAppearanceRow(rows, "Home Layout", HOME_LAYOUT_NAMES[selected], () ->
                new android.app.AlertDialog.Builder(this).setTitle("Home Layout")
                        .setSingleChoiceItems(HOME_LAYOUT_NAMES, homeLayoutIndex(), (dlg, choice) -> {
                            dlg.dismiss();
                            changeHomeLayout(choice);
                        }).setNegativeButton("Cancel", null).show());
        addAppearanceRow(rows, "Glass Transparency", pref.getInt("glass_transparency", 70) + "%", () ->
                showChombbAppearanceSlider("Glass Transparency", "glass_transparency", 70, 25, 100));
    }

    private void changeChombbLabels() {
        android.content.SharedPreferences pref = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
        pref.edit().putBoolean("app_labels", !pref.getBoolean("app_labels", true)).apply();
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void showChombbGridDialog() {
        final android.content.SharedPreferences pref = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
        final String[] sizes = {"4 Apps", "5 Apps", "6 Apps"};
        new android.app.AlertDialog.Builder(this).setTitle("Apps per row")
                .setSingleChoiceItems(sizes, Math.max(0, Math.min(2, COLUMNS - 4)), (dlg, selected) -> {
                    pref.edit().putInt("grid_columns", selected + 4).apply(); dlg.dismiss(); recreate();
                }).setNegativeButton("Cancel", null).show();
    }

    private void showChombbAppearanceSlider(String title, String key, int initial, int min, int max) {
        android.content.SharedPreferences pref = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
        android.widget.SeekBar slider = new android.widget.SeekBar(this);
        slider.setMax(max - min);
        slider.setProgress(pref.getInt(key, initial) - min);
        slider.setPadding(Math.round(22*density), Math.round(18*density), Math.round(22*density), Math.round(12*density));
        new android.app.AlertDialog.Builder(this).setTitle(title).setView(slider)
                .setPositiveButton("Apply", (dlg, which) -> {
                    int value = slider.getProgress() + min;
                    pref.edit().putInt(key, value).apply();
                    if ("glass_transparency".equals(key)) {
                        GlassStyle.load(this);   // every layout's glass reads it; rebuild Home to apply it
                        recreate();
                    }
                    Toast.makeText(this, title + " " + value, Toast.LENGTH_SHORT).show();
                }).setNegativeButton("Cancel", null).show();
    }

    private static boolean isViewInside(View candidate, View ancestor) {
        android.view.ViewParent parent = candidate.getParent();
        while (parent != null) {
            if (parent == ancestor) return true;
            parent = parent.getParent();
        }
        return false;
    }

    private void addAppearanceRow(LinearLayout rows, String name, String value, Runnable action) {
        final LinearLayout entry = new LinearLayout(this);
        entry.setOrientation(LinearLayout.HORIZONTAL);
        entry.setGravity(Gravity.CENTER_VERTICAL);
        entry.setPadding(Math.round(11*density), 0, Math.round(11*density), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.round(53*density));
        lp.bottomMargin = Math.round(5*density);
        rows.addView(entry, lp);
        entry.setFocusable(true);
        entry.setClickable(true);
        final LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        entry.addView(left, new LinearLayout.LayoutParams(0,-1,1f));
        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(0xFFF9FBFF);
        title.setTextSize(15);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        left.addView(title);
        TextView subtitle = new TextView(this);
        String detail = "";
        if ("UI Theme".equals(name)) detail = "Choose the overall look and feel";
        else if ("Background Blur".equals(name)) detail = "Adjust wallpaper blur strength";
        else if ("Focus Glow".equals(name)) detail = "Highlight effect on selected item";
        else if ("Show App Labels".equals(name)) detail = "Display app name below icons";
        else if ("App Grid Layout".equals(name)) detail = "Number of apps per row";
        subtitle.setText(detail);
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFFC2C9D7);
        left.addView(subtitle);
        final boolean sliderSetting = "Glass Transparency".equals(name) || "Corner Radius".equals(name);
        if (sliderSetting) {
            final boolean transparency = "Glass Transparency".equals(name);
            final int minimum = transparency ? 25 : 8;
            final int maximum = transparency ? 100 : 30;
            final String prefKey = transparency ? "glass_transparency" : "corner_radius";
            android.content.SharedPreferences appearance = getSharedPreferences("chombb_appearance", MODE_PRIVATE);
            android.widget.SeekBar slider = new android.widget.SeekBar(this);
            slider.setMax(maximum - minimum);
            slider.setProgress(appearance.getInt(prefKey, transparency ? 70 : 18) - minimum);
            slider.setFocusable(false);
            entry.addView(slider, new LinearLayout.LayoutParams(Math.round(126*density), -2));
            TextView indicator = new TextView(this);
            indicator.setText(value);
            indicator.setTextColor(0xFFFFFFFF);
            indicator.setTextSize(14);
            indicator.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            entry.addView(indicator, new LinearLayout.LayoutParams(Math.round(51*density), -1));
            slider.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(android.widget.SeekBar seekBar) { }
                public void onStopTrackingTouch(android.widget.SeekBar seekBar) { }
                public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                    int actual = progress + minimum;
                    indicator.setText(actual + (transparency ? "%" : "px"));
                    if (fromUser) appearance.edit().putInt(prefKey, actual).apply();
                }
            });
            entry.setTag(slider);
        } else if ("ON".equals(value) || "OFF".equals(value)) {
            boolean on = "ON".equals(value);
            LinearLayout switchBody = new LinearLayout(this);
            switchBody.setGravity(on ? Gravity.RIGHT | Gravity.CENTER_VERTICAL : Gravity.LEFT | Gravity.CENTER_VERTICAL);
            switchBody.setPadding(Math.round(3*density), 0, Math.round(3*density), 0);
            switchBody.setBackground(glassPanelBackground(on ? 0xFF258CF2 : 0xFF536177, 0x887ABAF7, 25));
            View knob = new View(this);
            knob.setBackground(glassPanelBackground(0xFFFFFFFF, 0xFFFFFFFF, 20));
            switchBody.addView(knob, new LinearLayout.LayoutParams(Math.round(22*density), Math.round(22*density)));
            entry.addView(switchBody, new LinearLayout.LayoutParams(Math.round(47*density), Math.round(28*density)));
        } else {
            TextView valueView = new TextView(this);
            valueView.setText(value + "  ›");
            valueView.setTextSize(15);
            valueView.setTextColor(0xFFFFFFFF);
            valueView.setGravity(Gravity.CENTER);
            valueView.setPadding(Math.round(11*density), Math.round(7*density), Math.round(11*density), Math.round(7*density));
            valueView.setBackground(glassPanelBackground(0x385B6682, 0x88E7F2FF, 12));
            entry.addView(valueView, new LinearLayout.LayoutParams(-2,-2));
        }
        final android.graphics.drawable.GradientDrawable plain = glassPanelBackground(0x26596683, 0x73E3ECFF, 13);
        final android.graphics.drawable.GradientDrawable focused = glassPanelBackground(0xA7347EB8, 0xFFE9F7FF, 13);
        entry.setBackground(plain);
        entry.setOnFocusChangeListener((v, has) -> {
            entry.setBackground(has ? focused : plain);
            if (has) {
                android.graphics.Rect rect = new android.graphics.Rect();
                entry.getDrawingRect(rect);
                if (entry.getParent() instanceof ViewGroup)
                    ((ViewGroup)entry.getParent()).requestChildRectangleOnScreen(entry, rect, false);
            }
        });
        entry.setOnClickListener(v -> action.run());
        entry.setOnKeyListener((v,key,event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER) {
                v.performClick(); return true;
            }
            if (key == KeyEvent.KEYCODE_DPAD_LEFT) {
                View preferenceRoot = rows.getRootView();
                View focusedSidebar = preferenceRoot.findViewWithTag("chombb_sidebar_active");
                if (focusedSidebar != null) focusedSidebar.requestFocus();
                return focusedSidebar != null;
            }
            if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN) {
                int at = rows.indexOfChild(v);
                int next = at + (key == KeyEvent.KEYCODE_DPAD_DOWN ? 1 : -1);
                if (next >= 0 && next < rows.getChildCount()) rows.getChildAt(next).requestFocus();
                return true;
            }
            return false;
        });
    }

    private boolean isVideoWallpaperEnabled() {
        return getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("video_wallpaper_enabled", false);
    }

    private void showVideoWallpaperDialog() {
        String saved = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getString("video_wallpaper_uri", "");
        boolean enabled = isVideoWallpaperEnabled();
        String[] options;
        if (saved.isEmpty()) {
            options = new String[]{"Pilih video MP4…", "Matikan video wallpaper"};
        } else if (enabled) {
            options = new String[]{"Pilih video lain…", "Matikan video wallpaper"};
        } else {
            options = new String[]{"Hidupkan video wallpaper", "Pilih video lain…", "Matikan video wallpaper"};
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("🎬 Video Wallpaper")
                .setItems(options, (dialog, which) -> {
                    if (saved.isEmpty()) {
                        if (which == 0) pickVideoWallpaper();
                        else disableVideoWallpaper();
                    } else if (enabled) {
                        if (which == 0) pickVideoWallpaper();
                        else disableVideoWallpaper();
                    } else {
                        if (which == 0) {
                            getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                                    .putBoolean("video_wallpaper_enabled", true).apply();
                            startVideoWallpaperFromPrefs();
                            Toast.makeText(this, "Video wallpaper dihidupkan", Toast.LENGTH_SHORT).show();
                        } else if (which == 1) {
                            pickVideoWallpaper();
                        } else {
                            disableVideoWallpaper();
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void pickVideoWallpaper() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("video/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(pick, REQUEST_PICK_VIDEO_WALLPAPER);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Tak jumpa pemilih video pada Mi Box", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_VIDEO_WALLPAPER || resultCode != RESULT_OK || data == null
                || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some file pickers return a readable URI without persistable grants.
        }
        getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                .putString("video_wallpaper_uri", uri.toString())
                .putBoolean("video_wallpaper_enabled", true)
                .apply();
        startVideoWallpaperFromPrefs();
        Toast.makeText(this, "Video wallpaper dipilih", Toast.LENGTH_SHORT).show();
    }

    private void disableVideoWallpaper() {
        getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                .putBoolean("video_wallpaper_enabled", false).apply();
        if (videoWallpaperView != null) {
            videoWallpaperView.stopPlayback();
            videoWallpaperView.setVisibility(View.GONE);
        }
        Backdrop.setVideoMode(false);
        if (wallView != null) wallView.setVisibility(View.VISIBLE);
        if (wallBitmap == null && !wallpapers.isEmpty()) showNextWallpaper(false);
        startWallpaperRotation();
        Toast.makeText(this, "Video wallpaper dimatikan", Toast.LENGTH_SHORT).show();
    }

    private void startVideoWallpaperFromPrefs() {
        if (!isVideoWallpaperEnabled()) return;
        String uriText = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getString("video_wallpaper_uri", "");
        if (uriText.isEmpty() || root == null) return;
        Uri uri;
        try {
            uri = Uri.parse(uriText);
            if (videoWallpaperView == null) {
                videoWallpaperView = new VideoView(this);
                videoWallpaperView.setFocusable(false);
                videoWallpaperView.setFocusableInTouchMode(false);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                root.addView(videoWallpaperView, 0, lp);
            }
            Backdrop.setVideoMode(true);
            videoWallpaperView.setVisibility(View.VISIBLE);
            if (wallView != null) wallView.setVisibility(View.GONE);
            videoWallpaperView.setOnPreparedListener(mp -> {
                try {
                    mp.setLooping(true);
                    mp.setVolume(0f, 0f);
                    videoWallpaperView.start();
                } catch (Exception ignored) { }
            });
            videoWallpaperView.setOnErrorListener((mp, what, extra) -> {
                Toast.makeText(this, "Video tak dapat dimainkan. Cuba MP4 H.264.", Toast.LENGTH_LONG).show();
                return true;
            });
            videoWallpaperView.setVideoURI(uri);
        } catch (Exception e) {
            Toast.makeText(this, "Tak dapat membuka video wallpaper", Toast.LENGTH_SHORT).show();
        }
    }


    private HeroCarousel heroCarousel;
    private HeroAppGrid heroAppGrid;
    private TextClock heroBigClock;
    private HeroWeatherPill heroWeatherPill;
    private HeroWeatherPill pillsWeather;   // plain mono weather under the Pill clock
    private HeroBlob heroBlob;

    /** The colour blob belongs to Classic-hero and Material only. Pill and Hero never show it (it used to flash in on song changes). */
    private boolean blobAllowed() {
        String l = getHomeLayout();
        return !"pills".equals(l) && !"hero".equals(l);
    }
    private PillDock pillDock;
    private TextView materialFocusedName;
    private View materialBackdropDim;
    private LinearLayout materialClockBlock;
    private LinearLayout materialWeatherPanel;
    private FrameLayout pillAllAppsDrawer;
    /** Drawer tiles in reading order, so the D-pad can walk the grid itself (left/right by one, up/down by a row). */
    private java.util.List<View> drawerTiles;
    private int drawerCols = 4;
    private final java.util.Map<View, Float> materialDrawerAlpha = new java.util.HashMap<>();
    private LinearLayout heroTopIcons;
    private TextClock heroDate;
    private LinearLayout pillsTopBlock;
    private ViewGroup originalWeatherParent;
    private ViewGroup.LayoutParams originalWeatherParams;
    private int originalWeatherIndex = -1;
    private int heroShelfVisibility = -1;
    private boolean pillObserverSet;
    private String appliedHeroVariant = "";

    private String getHomeLayout() {
        return getSharedPreferences("chombb_appearance", MODE_PRIVATE).getString("home_layout", "classic");
    }

    private boolean isHeroLayout() {
        return !"classic".equals(getHomeLayout());
    }

    /** One search for apps, Google Play, YouTube, the web and in-app search (ACTION_WEB_SEARCH has no handler on most TVs). */
    private void openLauncherSearch() {
        SoundEffects.playSelect();
        UniversalSearch.show(this);
    }

    private String getInstalledVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "Unknown"; }
    }

    /** Hero-only flat navigation glyphs inside the shared translucent capsule. */
    private View heroNavGlyph(int drawable, String description, Runnable action) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(drawable);
        icon.setColorFilter(Color.WHITE);
        int pad = Math.round(12*density);
        icon.setPadding(pad,pad,pad,pad);
        icon.setFocusable(true); icon.setClickable(true);
        icon.setContentDescription(description);
        GradientDrawable highlight = new GradientDrawable();
        highlight.setShape(GradientDrawable.OVAL);
        highlight.setColor(0x00000000);
        icon.setBackground(highlight);
        icon.setOnFocusChangeListener((v,focused)->{
            highlight.setColor(focused ? 0x55FFFFFF : 0x00000000);
            highlight.setStroke(Math.max(1,Math.round(density)),focused?0xDDFFFFFF:0x00FFFFFF);
            ChombbWidgets.springScale(v, focused?1.08f:1f, 420f, 0.66f);
        });
        icon.setOnClickListener(v->action.run());
        return icon;
    }

    private View heroIcon(int drawable, String description, Runnable action) {
        ImageView v = new ImageView(this);
        v.setImageResource(drawable);
        v.setColorFilter(Color.WHITE);
        int pad = Math.round(11 * density);
        v.setPadding(pad, pad, pad, pad);
        v.setContentDescription(description);
        v.setFocusable(true);
        v.setClickable(true);
        final GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x55101820);
        bg.setStroke(Math.round(1.5f * density), 0x44FFFFFF);
        v.setBackground(bg);
        v.setOnFocusChangeListener((view, f) -> {
            bg.setColor(f ? 0xAAFFFFFF : 0x55101820);
            bg.setStroke(Math.round((f ? 3 : 1.5f) * density), f ? 0xFFFFFFFF : 0x44FFFFFF);
            v.setColorFilter(f ? 0xFF101820 : Color.WHITE);
            ChombbWidgets.springScale(view, f ? 1.1f : 1f, 420f, 0.66f);
        });
        v.setOnClickListener(view -> action.run());
        return v;
    }

    // ===== Hero: weather capsule, nav capsule, large clock and date, 5x2 icon grid over the wallpaper =====
    private FrameLayout heroHome;
    private LinearLayout heroNav;
    private ViewTreeObserver.OnGlobalLayoutListener heroGuard;
    private final Runnable heroReload = () -> { if (heroAppGrid != null) heroAppGrid.reload(false); };

    /**
     * Hero is one light layer over the wallpaper. Everything the other layouts draw is set GONE, so a slow
     * box draws only the wallpaper, one shade, two capsules, two clocks and ten icons.
     */
    private void applyHeroHome() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        if (heroHome == null) {
            heroHome = new FrameLayout(this);
            heroHome.setClipChildren(false);
            heroHome.setClipToPadding(false);
            // A plain gradient, no blur: keeps white text readable on bright wallpapers at almost no cost.
            heroHome.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x4D000000, 0x14000000, 0x38000000}));
            int above = -1;
            if (wallView != null) above = Math.max(above, root.indexOfChild(wallView));
            if (videoWallpaperView != null) above = Math.max(above, root.indexOfChild(videoWallpaperView));
            root.addView(heroHome, above + 1, new FrameLayout.LayoutParams(-1, -1));

            int pillH = Math.round(64 * s), edge = Math.round(32 * s);
            heroWeatherPill = new HeroWeatherPill(this);
            FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(-2, pillH, Gravity.TOP | Gravity.START);
            wp.leftMargin = edge; wp.topMargin = edge;
            heroHome.addView(heroWeatherPill, wp);
            heroWeatherPill.update(WeatherAirQuality.getFullWeather(this));

            heroNav = new LinearLayout(this);
            heroNav.setOrientation(LinearLayout.HORIZONTAL);
            heroNav.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable navGlass = new GradientDrawable();
            navGlass.setColor(GlassStyle.tint(0x40FFFFFF));
            navGlass.setCornerRadius(pillH / 2f);
            navGlass.setStroke(Math.max(1, Math.round(1.5f * s)), 0x73FFFFFF);
            heroNav.setBackground(navGlass);
            heroNav.setPadding(Math.round(12 * s), 0, Math.round(12 * s), 0);
            int[] icons = {R.drawable.ic_hero_ring, R.drawable.ic_hero_apps, R.drawable.ic_hero_sliders};
            String[] names = {"Search", "All Apps", "Quick Settings"};
            Runnable[] acts = {this::openLauncherSearch, this::showPillAllAppsDrawer, this::showGlassSettingsPanel};
            int btn = Math.round(52 * s);
            for (int i = 0; i < icons.length; i++) {
                final int idx = i, last = icons.length - 1;
                View b = heroNavButton(icons[i], names[i], acts[i], s);
                b.setOnKeyListener((v, code, ev) -> {
                    if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
                    if (code == KeyEvent.KEYCODE_DPAD_DOWN) { if (!focusWidgets(false)) focusHomeApps(); return true; }
                    if (code == KeyEvent.KEYCODE_DPAD_UP) return true;
                    if (code == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0) return true;
                    return code == KeyEvent.KEYCODE_DPAD_RIGHT && idx == last;
                });
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(btn, btn);
                if (i > 0) bp.leftMargin = Math.round(6 * s);
                heroNav.addView(b, bp);
            }
            FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-2, pillH, Gravity.TOP | Gravity.END);
            np.rightMargin = edge; np.topMargin = edge;
            heroHome.addView(heroNav, np);

            heroBigClock = new TextClock(this);
            heroBigClock.setFormat12Hour("h:mm");
            heroBigClock.setFormat24Hour("H:mm");
            heroStyle(heroBigClock, 172 * s, 0xFFFFFFFF, 500, s);
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            cp.topMargin = Math.round(dm.heightPixels * 0.135f);
            heroHome.addView(heroBigClock, cp);

            heroDate = new TextClock(this);
            heroDate.setFormat12Hour("EEE d MMM");
            heroDate.setFormat24Hour("EEE d MMM");
            heroStyle(heroDate, 52 * s, 0xE0FFFFFF, 450, s);
            FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            dp.topMargin = Math.round(dm.heightPixels * 0.337f);
            heroHome.addView(heroDate, dp);
        }
        // The adapter is made after the first call (onCreate), so the grid is built on the call that has it.
        if (heroAppGrid == null && adapter != null) {
            heroAppGrid = new HeroAppGrid(this, adapter, new HeroAppGrid.Host() {
                @Override public void focusTop() {
                    if (!focusWidgets(true)) focusHomeSettings();
                }
                @Override public boolean focusWidget(View app) {
                    View nearest = nearestHeroWidget(app);
                    return nearest != null && nearest.requestFocus();
                }
                @Override public void onHold(int tile, View anchor) {
                    showTileActions(tile, anchor, () -> { if (heroAppGrid != null) heroAppGrid.startMove(tile); });
                }
            });
            FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(heroAppGrid.viewWidth(), heroAppGrid.viewHeight(),
                    Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            // First row of icons centred at 54% of the height, as in the reference.
            gp.topMargin = Math.round(dm.heightPixels * 0.543f - heroAppGrid.padV - heroAppGrid.cell / 2f);
            heroHome.addView(heroAppGrid, gp);
            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override public void onChanged() { queueHeroReload(); }
                @Override public void onItemRangeInserted(int a, int b) { queueHeroReload(); }
                @Override public void onItemRangeRemoved(int a, int b) { queueHeroReload(); }
                @Override public void onItemRangeMoved(int a, int b, int c) { queueHeroReload(); }
            });
            handler.post(() -> {
                View f = getCurrentFocus();
                if (heroAppGrid != null && (f == null || !f.isShown())) heroAppGrid.focusFirst();
            });
        }
        hideBehindHero();
        refreshChombbWidgetShelf();
        if (heroGuard == null) {
            // Other code shows these again (wallpaper place names, prayer shelf...); keep them out of Hero.
            heroGuard = this::hideBehindHero;
            root.getViewTreeObserver().addOnGlobalLayoutListener(heroGuard);
        }
    }

    /** OK held on an app in Hero, Pill or Material: Move (when it can) and App info. */
    private void showTileActions(int tile, View anchor, Runnable move) {
        if (adapter == null || tile < 0 || tile >= adapter.tileCount()) return;
        final String key = adapter.keyAt(tile);
        SoundEffects.playSelect();
        final String pkg = adapter.tileAt(tile).pkg;
        TileActionMenu.show(this, anchor, adapter.tileAt(tile).label, null, adapter.canMove(tile) ? move : null,
                () -> adapter.openAppInfo(adapter.positionOf(key)), () -> hideApp(pkg));
    }

    /**
     * OK held on an app in All Apps. Pill and Material: "Move to dock" puts it in the dock's last place
     * and picks it up, so LEFT/RIGHT set its spot. Hero: picks it up in the grid.
     */
    /**
     * Material All Apps: a full-screen Material 3 surface in the current dynamic palette, with a large
     * title and a recycling grid of banner cards (focus = primary ring, lift and bold label).
     */
    private void showMaterialAppsDrawer() {
        // The "All apps" card (or whatever opened it): the drawer grows out of it and folds back into it.
        View from = getCurrentFocus();
        if (from instanceof LinearLayout && ((LinearLayout) from).getChildCount() > 0) from = ((LinearLayout) from).getChildAt(0);
        materialDrawerOrigin = from;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        final MaterialStyle style = pillDock != null ? pillDock.materialStyle() : null;
        final MaterialPalette pal = style != null ? style.current() : MaterialPalette.of(MaterialPalette.DEFAULT_SEED);
        android.graphics.Typeface face;
        try { face = getResources().getFont(R.font.outfit); } catch (Exception e) { face = android.graphics.Typeface.DEFAULT; }
        final android.graphics.Typeface font = face;

        final java.util.ArrayList<Integer> apps = new java.util.ArrayList<>();
        for (int i = 0; i < adapter.tileCount(); i++) if (adapter.tileAt(i).kind == AppAdapter.Entry.APP) apps.add(i);

        pillAllAppsDrawer = new FrameLayout(this);
        pillAllAppsDrawer.setBackgroundColor((pal.surface & 0x00FFFFFF) | 0xF7000000);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        int side = Math.round(96 * s);
        body.setPadding(side, Math.round(60 * s), side, 0);

        TextView title = new TextView(this);
        title.setText("Apps");
        title.setTextColor(pal.onSurface);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, 58 * s);
        title.setTypeface(font);
        try { title.setFontVariationSettings("'wght' 450"); } catch (Exception ignored) { }
        title.setIncludeFontPadding(false);
        body.addView(title);
        TextView sub = new TextView(this);
        sub.setText(apps.size() + " apps");
        sub.setTextColor(pal.onSurfaceVariant);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_PX, 22 * s);
        sub.setTypeface(font);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = Math.round(8 * s);
        body.addView(sub, sp);

        final int cols = 6;
        final int cellW = Math.round((dm.widthPixels - 2 * side) / (float) cols);
        final int pad = Math.round(12 * s);
        final int artW = cellW - 2 * pad, artH = Math.round(artW * 9f / 16f);
        final float radius = 24 * s;
        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new androidx.recyclerview.widget.GridLayoutManager(this, cols));
        list.setItemAnimator(null);
        list.setHasFixedSize(true);
        list.setClipToPadding(false);
        list.setClipChildren(false);
        list.setPadding(0, Math.round(28 * s), 0, Math.round(80 * s));
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type) {
                LinearLayout cell = new LinearLayout(parent.getContext());
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(pad, pad, pad, pad);
                cell.setFocusable(true);
                cell.setClickable(true);
                cell.setClipChildren(false);
                FrameLayout art = new FrameLayout(parent.getContext());
                GradientDrawable artBg = new GradientDrawable();
                artBg.setColor(pal.containerHigh);
                artBg.setCornerRadius(radius);
                art.setBackground(artBg);
                art.setOutlineProvider(new android.view.ViewOutlineProvider() {
                    @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius); }
                });
                art.setClipToOutline(true);
                ImageView image = new ImageView(parent.getContext());
                art.addView(image, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
                GradientDrawable ring = new GradientDrawable();
                ring.setCornerRadius(radius);
                ring.setColor(0x00000000);
                ring.setStroke(Math.max(2, Math.round(5 * s)), 0x00000000);
                art.setForeground(ring);
                cell.addView(art, new LinearLayout.LayoutParams(artW, artH));
                TextView label = new TextView(parent.getContext());
                label.setTextColor(pal.onSurfaceVariant);
                label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20 * s);
                label.setTypeface(font);
                label.setGravity(Gravity.CENTER);
                label.setSingleLine(true);
                label.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.topMargin = Math.round(10 * s);
                cell.addView(label, lp);
                cell.setOnFocusChangeListener((v, f) -> {
                    ring.setStroke(Math.max(2, Math.round(5 * s)), f ? pal.primary : 0x00000000);
                    label.setTextColor(f ? pal.onSurface : pal.onSurfaceVariant);
                    try { label.setFontVariationSettings(f ? "'wght' 650" : "'wght' 400"); } catch (Exception ignored) { }
                    v.animate().scaleX(f ? 1.07f : 1f).scaleY(f ? 1.07f : 1f).translationZ(f ? 10 * s : 0f)
                            .setDuration(MaterialStyle.FOCUS_MS).setInterpolator(MaterialStyle.FAST_SPATIAL).start();
                    if (f) SoundEffects.playNav();
                });
                return new RecyclerView.ViewHolder(cell) { };
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int index) {
                final int pos = apps.get(index);
                AppAdapter.Entry e = adapter.tileAt(pos);
                LinearLayout cell = (LinearLayout) h.itemView;
                FrameLayout art = (FrameLayout) cell.getChildAt(0);
                ImageView image = (ImageView) art.getChildAt(0);
                ((TextView) cell.getChildAt(1)).setText(e.label);
                boolean banner = e.banner != null;
                IconLoader.into(image, e.pkg, banner ? e.banner : e.icon, Math.round(artH * 0.62f));
                image.setScaleType(banner ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
                FrameLayout.LayoutParams ip = (FrameLayout.LayoutParams) image.getLayoutParams();
                int iconSide = Math.round(artH * 0.62f);
                ip.width = banner ? -1 : iconSide;
                ip.height = banner ? -1 : iconSide;
                image.setLayoutParams(ip);
                cell.setOnClickListener(v -> { hidePillAllAppsDrawer(false); adapter.launchAt(pos); });
                cell.setOnLongClickListener(v -> { showDrawerTileActions(pos, v); return true; });
            }
            @Override public int getItemCount() { return apps.size(); }
        });
        body.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        pillAllAppsDrawer.addView(body, new FrameLayout.LayoutParams(-1, -1));
        root.addView(pillAllAppsDrawer, new FrameLayout.LayoutParams(-1, -1));
        pillAllAppsDrawer.bringToFront();
        pillAllAppsDrawer.setElevation(1000f * getResources().getDisplayMetrics().density);
        materialDrawerPalette = pal;
        morphMaterialDrawer(pillAllAppsDrawer, body, true, null);
        list.post(() -> {
            RecyclerView.ViewHolder vh = list.findViewHolderForAdapterPosition(0);
            if (vh != null) vh.itemView.requestFocus(); else list.requestFocus();
        });
    }

    private View materialDrawerOrigin;
    private final java.util.Map<View, SpringAnimation> drawerMorphs = new java.util.IdentityHashMap<>();
    private MaterialPalette materialDrawerPalette;

    /**
     * Material container transform: the drawer grows from the card's rectangle and colour to the full
     * screen surface, corners straightening as it goes, the grid fading in once there is room for it.
     * Closing runs the same path back into the card. Only scale, translation, outline and alpha change.
     */
    private void morphMaterialDrawer(FrameLayout drawer, View content, boolean open, Runnable end) {
        final View o = materialDrawerOrigin;
        final int W = root.getWidth(), H = root.getHeight();
        final MaterialPalette pal = materialDrawerPalette != null ? materialDrawerPalette : MaterialPalette.of(MaterialPalette.DEFAULT_SEED);
        final int surface = (pal.surface & 0x00FFFFFF) | 0xF7000000, card = pal.primaryContainer | 0xFF000000;
        if (o == null || !o.isAttachedToWindow() || W == 0 || H == 0) {
            // Nothing to grow from: a plain fade.
            drawer.setAlpha(open ? 0f : 1f);
            drawer.animate().alpha(open ? 1f : 0f).setDuration(open ? 260 : 200)
                    .withEndAction(() -> { if (end != null) end.run(); }).start();
            return;
        }
        int[] oa = new int[2], ra = new int[2];
        o.getLocationInWindow(oa);
        root.getLocationInWindow(ra);
        final float ox = oa[0] - ra[0], oy = oa[1] - ra[1];
        View scaledParent = o.getParent() instanceof View ? (View) o.getParent() : o;
        final float sx0 = Math.max(0.05f, o.getWidth() * scaledParent.getScaleX() / W);
        final float sy0 = Math.max(0.05f, o.getHeight() * scaledParent.getScaleY() / H);
        final float startRadius = 40 * Math.min(W / 1920f, H / 1080f);
        final float[] radius = {startRadius};
        drawer.setPivotX(0f);
        drawer.setPivotY(0f);
        drawer.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline out) {
                out.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius[0]);
            }
        });
        drawer.setClipToOutline(true);
        final android.animation.ArgbEvaluator mix = new android.animation.ArgbEvaluator();
        SpringAnimation previous = drawerMorphs.remove(drawer);
        if (previous != null) previous.cancel();
        float initial = open ? 0f : Math.max(0f, Math.min(1f, (drawer.getScaleX() - sx0) / Math.max(0.01f, 1f - sx0)));
        FloatPropertyCompat<View> progress = new FloatPropertyCompat<View>("drawerProgress") {
            private float value;

            @Override public float getValue(View view) { return value; }

            @Override public void setValue(View view, float position) {
                value = position;
                float f = Math.max(0f, Math.min(1f, position));
                float sx = sx0 + (1f - sx0) * f, sy = sy0 + (1f - sy0) * f;
                drawer.setScaleX(sx);
                drawer.setScaleY(sy);
                drawer.setTranslationX(ox * (1f - f));
                drawer.setTranslationY(oy * (1f - f));
                radius[0] = startRadius * (1f - f) / Math.max(0.05f, Math.min(sx, sy));
                drawer.invalidateOutline();
                drawer.setBackgroundColor((Integer) mix.evaluate(Math.min(1f, f * 1.6f), card, surface));
                content.setAlpha(Math.max(0f, Math.min(1f, (f - 0.35f) / 0.45f)));
            }
        };
        SpringAnimation drawerMorph = new SpringAnimation(drawer, progress, open ? 1f : 0f);
        drawerMorphs.put(drawer, drawerMorph);
        drawerMorph.setMinimumVisibleChange(0.003f);
        drawerMorph.setStartValue(initial);
        progress.setValue(drawer, initial);
        drawerMorph.getSpring().setStiffness(175f).setDampingRatio(0.84f);
        drawerMorph.addEndListener((animation, canceled, value, velocity) -> {
            if (canceled) return;
            drawerMorphs.remove(drawer);
            if (open) { drawer.setClipToOutline(false); drawer.setBackgroundColor(surface); }
            if (end != null) end.run();
        });
        drawerMorph.start();
    }

    private void showDrawerTileActions(int pos, View anchor) {
        if (adapter == null || pos < 0 || pos >= adapter.tileCount()) return;
        final String key = adapter.keyAt(pos);
        boolean hero = "hero".equals(getHomeLayout());
        boolean docked = !hero && pillDock != null && pillDock.inDock(pos);
        String label = hero ? getString(R.string.tile_move) : (docked ? getString(R.string.tile_move) : "Pindah ke Dock");
        SoundEffects.playSelect();
        final String pkg = adapter.tileAt(pos).pkg;
        TileActionMenu.show(this, anchor, adapter.tileAt(pos).label, label,
                adapter.canMove(pos) ? () -> moveFromDrawer(key) : null,
                () -> adapter.openAppInfo(adapter.positionOf(key)), () -> {
                    hidePillAllAppsDrawer(false);
                    hideApp(pkg);
                });
    }

    private void moveFromDrawer(String key) {
        hidePillAllAppsDrawer(false);
        int pos = adapter.positionOf(key);
        if (pos < 0) return;
        if ("hero".equals(getHomeLayout())) {
            if (heroAppGrid != null) heroAppGrid.startMove(pos);
            return;
        }
        if (pillDock == null) return;
        if (!pillDock.inDock(pos)) {
            int target = pillDock.lastDockTile();
            if (target >= 0 && target < pos) adapter.move(pos, target);
        }
        pillDock.refresh();
        final int now = adapter.positionOf(key);
        handler.post(() -> { if (pillDock != null) pillDock.startMove(now); });
    }

    /** Hides an app from every layout's dock, grid and All Apps; Preferences > Apps > Hidden Apps brings it back. */
    private void hideApp(String pkg) {
        if (pkg == null) return;
        if (heroAppGrid != null) heroAppGrid.endMove();
        if (pillDock != null) pillDock.endMove();
        String label = pkg;
        try { label = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception ignored) { }
        AppAdapter.setUserHidden(this, pkg, true);
        reloadApps(false);
        Toast.makeText(this, label + " disorok. Preferences > Apps > Hidden Apps untuk tunjuk semula.", Toast.LENGTH_LONG).show();
    }

    private void showHiddenAppsDialog(Runnable after) {
        final java.util.List<String> pkgs = new java.util.ArrayList<>(AppAdapter.userHidden(this));
        if (pkgs.isEmpty()) { Toast.makeText(this, "Tiada app disorok", Toast.LENGTH_SHORT).show(); return; }
        String[] labels = new String[pkgs.size()];
        for (int i = 0; i < labels.length; i++) {
            String l = pkgs.get(i);
            try { l = getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkgs.get(i), 0)).toString(); }
            catch (Exception ignored) { l = l + " (tiada)"; }
            labels[i] = l;
        }
        new android.app.AlertDialog.Builder(this).setTitle("App disorok · pilih untuk tunjuk semula")
                .setItems(labels, (d, w) -> {
                    AppAdapter.setUserHidden(this, pkgs.get(w), false);
                    reloadApps(false);
                    if (after != null) after.run();
                })
                .setNegativeButton("Tutup", null).show();
    }

    /**
     * Now Playing and Live Lyrics need Notification Access. Grants it directly when the launcher already has
     * WRITE_SECURE_SETTINGS, opens the system screen when the TV has one, and otherwise shows the adb command.
     */
    private void requestNotificationAccess() {
        if (NowPlaying.ensureAccess(this)) {
            Toast.makeText(this, "Notification Access aktif", Toast.LENGTH_SHORT).show();
            refreshChombbWidgetShelf();
            return;
        }
        if (NowPlaying.openSettings(this)) {
            Toast.makeText(this, "Cari GlassTV dan hidupkan aksesnya", Toast.LENGTH_LONG).show();
            return;
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Notification Access")
                .setMessage("TV ini tiada skrin Notification Access. Sambungkan PC ke TV dengan adb dan jalankan:\n\n"
                        + NowPlaying.adbGrant(this)
                        + "\n\natau (sekali sahaja, untuk semua kebenaran):\n\nadb shell pm grant " + getPackageName()
                        + " android.permission.WRITE_SECURE_SETTINGS\n\nSelepas itu buka semula Home.")
                .setPositiveButton("OK", null).show();
    }

    private static final int REQ_LOCATION = 701;

    private void showFirstRunSetup() {
        if (isFinishing() || isDestroyed()) return;
        FirstRunSetup.show(this, new FirstRunSetup.Host() {
            @Override public void requestLocation() {
                if (FirstRunSetup.hasLocation(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Lokasi sudah dibenarkan", Toast.LENGTH_SHORT).show();
                    return;
                }
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            }
            @Override public void requestNotificationAccess() { MainActivity.this.requestNotificationAccess(); }
            @Override public void onSetupFinished() {
                // Weather and prayer times follow where the TV is, from now on.
                AutoLocation.setAuto(MainActivity.this, true);
                AutoLocation.refreshNow(MainActivity.this, MainActivity.this::refreshLocationDependentData);
                refreshChombbWidgetShelf();
                Toast.makeText(MainActivity.this, "Siap! Selamat menggunakan GlassTV", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_LOCATION) return;
        FirstRunSetup.refresh();
        if (FirstRunSetup.hasLocation(this)) {
            AutoLocation.setAuto(this, true);
            AutoLocation.refreshNow(this, this::refreshLocationDependentData);
        }
    }

    private void queueHeroReload() {
        handler.removeCallbacks(heroReload);
        handler.postDelayed(heroReload, 120);   // one reload fires several changes at once
    }

    /**
     * Hero, Pill and Material never show Classic's content column, place shelf, prayer shelf or glass
     * highlight. GONE (not merely invisible or alpha 0) so they are neither laid out nor drawn.
     */
    private void hideBehindHero() {
        if ("classic".equals(getHomeLayout())) return;
        View[] behind = {mainContent, heroShelf, islamicShelf, glass, glider, ambient};
        for (View v : behind) if (v != null && v.getVisibility() != View.GONE) v.setVisibility(View.GONE);
    }

    private void heroStyle(TextView t, float px, int color, int weight, float s) {
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        t.setIncludeFontPadding(false);
        t.setShadowLayer(10 * s, 0, 2 * s, 0x40000000);
        t.setFocusable(false);
        try {
            t.setTypeface(getResources().getFont(R.font.outfit));
            t.setFontVariationSettings("'wght' " + weight);
        } catch (Exception ignored) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
    }

    /** Pill top-right button, as in the reference: a bare white icon; focused, a white disc with its name under it. */
    private View pillNavItem(int drawable, String title, Runnable action) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float s = Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER_HORIZONTAL);
        item.setFocusable(true);
        item.setClickable(true);
        item.setContentDescription(title);
        item.setPadding(Math.round(8 * s), 0, Math.round(8 * s), 0);
        ImageView glyph = new ImageView(this);
        glyph.setImageResource(drawable);
        glyph.setColorFilter(Color.WHITE);
        int d = Math.round(92 * s), pad = Math.round(25 * s);
        glyph.setPadding(pad, pad, pad, pad);
        GradientDrawable disc = new GradientDrawable();
        disc.setShape(GradientDrawable.OVAL);
        disc.setColor(0x00FFFFFF);
        glyph.setBackground(disc);
        item.addView(glyph, new LinearLayout.LayoutParams(d, d));
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_PX, 21 * s);
        try { label.setTypeface(getResources().getFont(R.font.outfit)); } catch (Exception ignored) { }
        label.setShadowLayer(4 * s, 0, s, 0x66000000);
        label.setAlpha(0f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = Math.round(6 * s);
        item.addView(label, lp);
        item.setOnFocusChangeListener((v, f) -> {
            disc.setColor(f ? 0xF2FFFFFF : 0x00FFFFFF);
            // Soft white glow ring (the app pills glow in their own colour; these glow white).
            disc.setStroke(f ? Math.round(7 * s) : 0, f ? 0x55FFFFFF : 0x00FFFFFF);
            glyph.setColorFilter(f ? 0xFF1A1F27 : Color.WHITE);
            ChombbWidgets.springScale(glyph, f ? 1.12f : 1f, 420f, 0.66f);
            label.animate().alpha(f ? 1f : 0f).setDuration(140).start();
        });
        item.setOnClickListener(v -> { SoundEffects.playSelect(); action.run(); });
        return item;
    }

    /** One round button in the nav capsule: a white line icon, a soft glass disc when focused. */
    private View heroNavButton(int drawable, String description, Runnable action, float s) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(drawable);
        icon.setColorFilter(Color.WHITE);
        int pad = Math.round(12 * s);
        icon.setPadding(pad, pad, pad, pad);
        icon.setFocusable(true);
        icon.setClickable(true);
        icon.setContentDescription(description);
        GradientDrawable disc = new GradientDrawable();
        disc.setShape(GradientDrawable.OVAL);
        disc.setColor(0x00FFFFFF);
        icon.setBackground(disc);
        icon.setOnFocusChangeListener((v, focused) -> {
            disc.setColor(focused ? 0x4DFFFFFF : 0x00FFFFFF);
            ChombbWidgets.springScale(v, focused ? 1.08f : 1f, 420f, 0.66f);
        });
        icon.setOnClickListener(v -> { SoundEffects.playSelect(); action.run(); });
        return icon;
    }

    /**
     * "Hero · Now Playing" layout, after the Figma design: clock and date top-left, three round buttons top-right
     * with a rotating widget pill under them (Now Playing / prayer / weather) on a colour shape that takes the
     * album art's colour, and one row of glass pills for every app on the box along the bottom. "Classic"
     * puts the old grid, clock and widget shelf back.
     */
    private void applyHomeLayout() {
        if ("hero".equals(getHomeLayout())) { applyHeroHome(); return; }
        boolean hero = isHeroLayout();
        boolean pillsMode = "pills".equals(getHomeLayout());
        boolean materialMode = "material".equals(getHomeLayout());
        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (hero && heroCarousel != null && !getHomeLayout().equals(appliedHeroVariant)) {
            root.removeView(heroCarousel); root.removeView(heroBlob);
            if(heroAppGrid!=null){root.removeView(heroAppGrid);heroAppGrid=null;}
            if(heroBigClock!=null){root.removeView(heroBigClock);heroBigClock=null;}
            if(heroWeatherPill!=null){root.removeView(heroWeatherPill);heroWeatherPill=null;}
            root.removeView(heroTopIcons); root.removeView(heroDate);
            heroCarousel = null; heroBlob = null; heroTopIcons = null; heroDate = null;
        }
        if (hero) appliedHeroVariant = getHomeLayout();

        if (hero && heroCarousel == null) {
            heroBlob = materialMode ? new MaterialBlob(this) : new HeroBlob(this);
            // Material must be ABOVE the wallpaper. The previous index=0 put the blob behind it.
            // Keep Classic/Hero ordering unchanged.
            if (materialMode) {
                FrameLayout.LayoutParams blobLp = new FrameLayout.LayoutParams(
                        Math.round(dm.heightPixels * 1.309f), Math.round(dm.heightPixels * 1.309f), Gravity.TOP | Gravity.END);
                blobLp.topMargin = -Math.round(dm.heightPixels * 0.30f);
                blobLp.rightMargin = -Math.round(dm.heightPixels * 0.29f);
                root.addView(heroBlob, blobLp);
                // Wallpaper and other legacy surfaces may be re-ordered after layout creation.
                // Material shape is a separate layer above wallpaper, below controls.
                ((MaterialBlob)heroBlob).setWallpaper(wallBitmap);
                heroBlob.setElevation(2f * density);
                heroBlob.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            }
            else root.addView(heroBlob, 0, new FrameLayout.LayoutParams(
                    Math.round(dm.widthPixels * 0.50f), Math.round(dm.heightPixels * 0.62f), Gravity.TOP | Gravity.END));

            heroCarousel = new HeroCarousel(this, new HeroCarousel.Host() {
                @Override public void focusClock() { View ck = findViewById(R.id.clock); if (ck != null) ck.requestFocus(); }
                @Override public void focusTopIcons() { if (heroTopIcons != null) heroTopIcons.getChildAt(0).requestFocus(); }
                @Override public void focusDock() { if (pillDock != null) pillDock.focusCurrent(); }
                @Override public void accent(int color, boolean musicActive) {
                    if (heroBlob != null && blobAllowed()) heroBlob.setAccent(color, musicActive);
                }
            });
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
            lp.topMargin = Math.round(104 * density);
            lp.rightMargin = Math.round(56 * density);
            root.addView(heroCarousel, lp);

            heroTopIcons = new LinearLayout(this);
            heroTopIcons.setOrientation(LinearLayout.HORIZONTAL);
            heroTopIcons.setClipChildren(false);
            heroTopIcons.setClipToPadding(false);
            if ("hero".equals(getHomeLayout())) { GradientDrawable heroNav = new GradientDrawable(); heroNav.setColor(0x66404A57); heroNav.setCornerRadius(90*density); heroNav.setStroke(Math.max(1,Math.round(density)),0x88FFFFFF); heroTopIcons.setBackground(heroNav); heroTopIcons.setPadding(Math.round(9*density),Math.round(5*density),Math.round(9*density),Math.round(5*density)); }
            if (materialMode) {
                GradientDrawable navBg = new GradientDrawable();
                navBg.setColor(0xEE291B1C);
                navBg.setCornerRadius(Math.round(40*density));
                heroTopIcons.setBackground(navBg);
                heroTopIcons.setPadding(Math.round(9*density),Math.round(7*density),Math.round(9*density),Math.round(7*density));
            }
            final int size = Math.round(46 * density), gap = Math.round(("hero".equals(getHomeLayout()) ? 5 : 14) * density);
            Runnable[] acts = "hero".equals(getHomeLayout()) ? new Runnable[]{() -> {if(heroAppGrid!=null)heroAppGrid.focusFirst();}, this::openLauncherSearch, this::showGlassSettingsPanel} : materialMode
                    ? new Runnable[]{this::openLauncherSearch, this::showGlassSettingsPanel}
                    : pillsMode ? new Runnable[]{this::showGlassSettingsPanel, this::openLauncherSearch}
                    : new Runnable[]{this::showInputs, () -> open(systemIntent(Settings.ACTION_WIFI_SETTINGS)), this::showSettingsPopup};
            int[] icons = "hero".equals(getHomeLayout()) ? new int[]{R.drawable.ic_material_apps, R.drawable.ic_search, R.drawable.ic_settings} : materialMode
                    ? new int[]{R.drawable.ic_search, R.drawable.ic_settings}
                    : pillsMode ? new int[]{R.drawable.ic_settings, R.drawable.ic_search}
                    : new int[]{R.drawable.ic_input, R.drawable.ic_wifi, R.drawable.ic_settings};
            String[] names = "hero".equals(getHomeLayout()) ? new String[]{"Apps", "Search", "Quick Settings"} : materialMode
                    ? new String[]{"Search", "Settings"}
                    : pillsMode ? new String[]{"Settings", "Search"}
                    : new String[]{"Inputs", "Wi-Fi", "Preferences"};
            for (int i = 0; i < acts.length; i++) {
                final int idx = i;
                View icon = materialMode ? createMaterialNavItem(icons[i], names[i], acts[i])
                        : pillsMode ? pillNavItem(icons[i], names[i], acts[i])
                        : "hero".equals(getHomeLayout()) ? heroNavGlyph(icons[i], names[i], acts[i]) : heroIcon(icons[i], names[i], acts[i]);
                if (materialMode) {
                    GradientDrawable navItem = new GradientDrawable();
                    navItem.setCornerRadius(Math.round(35*density));
                    navItem.setColor(0x00000000);
                    icon.setBackground(navItem);
                    icon.setOnFocusChangeListener((v,f)->{
                        navItem.setColor(f ? 0xFFFFB4AC : 0x00000000);
                        if (v instanceof LinearLayout) {
                            LinearLayout item = (LinearLayout)v;
                            ImageView glyph = (ImageView)item.getChildAt(0);
                            TextView caption = (TextView)item.getChildAt(1);
                            glyph.setColorFilter(f ? 0xFF38151A : 0xFFEBD7D6);
                            caption.setTextColor(f ? 0xFF38151A : 0xFFEBD7D6);
                        }
                    });
                }
                icon.setOnKeyListener((v, keyCode, event) -> {
                    if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                    if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                        if (focusWidgets(false)) return true;
                        if (materialMode && pillDock != null) pillDock.focusCurrent();
                        else if (pillsMode && pillDock != null) pillDock.focusCurrent();
                        else if (heroAppGrid != null && "hero".equals(getHomeLayout())) heroAppGrid.focusFirst();
                        else heroCarousel.requestFocus();
                        return true;
                    }
                    if (keyCode == KeyEvent.KEYCODE_DPAD_UP) return true;
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0) {
                        View ck = findViewById(R.id.clock);
                        if (ck != null) ck.requestFocus();
                        return true;
                    }
                    if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && idx == acts.length - 1) return true;
                    return false;
                });
                LinearLayout.LayoutParams ip = pillsMode ? new LinearLayout.LayoutParams(-2, -2)
                        : new LinearLayout.LayoutParams(materialMode ? Math.round(125*density) : size, size);
                if (i > 0 && !materialMode && !pillsMode) ip.leftMargin = gap;
                heroTopIcons.addView(icon, ip);
            }
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
            tp.topMargin = pillsMode ? Math.round(dm.heightPixels * 0.03f) : Math.round((materialMode ? 32 : 26) * density);
            tp.rightMargin = pillsMode ? Math.round(dm.widthPixels * 0.055f) : Math.round((materialMode ? 48 : ("hero".equals(getHomeLayout()) ? 24 : 56)) * density);
            root.addView(heroTopIcons, tp);
            if (materialMode) heroTopIcons.setElevation(5f * density);

            heroDate = new TextClock(this);
            String pattern = android.text.format.DateFormat.getBestDateTimePattern(java.util.Locale.getDefault(), "EEEEMMMMd");
            heroDate.setFormat12Hour(pattern);
            heroDate.setFormat24Hour(pattern);
            heroDate.setTextColor(0xDDFFFFFF);
            heroDate.setTextSize(TypedValue.COMPLEX_UNIT_SP, "hero".equals(getHomeLayout()) ? 29 : 16);
            if ("hero".equals(getHomeLayout())) { heroDate.setFormat12Hour("EEE d MMM"); heroDate.setFormat24Hour("EEE d MMM"); }
            heroDate.setShadowLayer(4f, 0f, 1f, 0x80000000);
            try { heroDate.setTypeface(getResources().getFont(R.font.outfit)); } catch (Exception ignored) { }
            FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
            dp.topMargin = "hero".equals(getHomeLayout()) ? Math.round(dm.heightPixels*0.36f) : Math.round(72*density);
            dp.leftMargin = Math.round(68 * density);
            if("hero".equals(getHomeLayout()))dp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;
            root.addView(heroDate, dp);
        }

        if (hero && adapter != null && pillDock == null) {
            pillDock = new PillDock(this, adapter, new PillDock.Host() {
                @Override public void focusTop() {
                    if (!focusWidgets(true)) focusHomeSettings();
                }
                @Override public void onAppFocused(String label, int accent) {
                    if ("material".equals(getHomeLayout())) {
                        if (heroBlob != null && blobAllowed()) heroBlob.setAccent(accent, true);
                        if (materialFocusedName != null) materialFocusedName.setText(label);
                    }
                }
                @Override public void appInfo(int tilePosition) { adapter.openAppInfo(tilePosition); }
                @Override public void onHold(int tilePosition, View anchor) {
                    showTileActions(tilePosition, anchor, () -> { if (pillDock != null) pillDock.startMove(tilePosition); });
                }
                @Override public void allApps() {
                    if ("pills".equals(getHomeLayout()) || "material".equals(getHomeLayout())) showPillAllAppsDrawer();
                    else if (gridWrap != null) {
                        gridWrap.setVisibility(View.VISIBLE);
                        gridWrap.bringToFront();
                        gridWrap.requestFocus();
                    }
                }
            });
            FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            pp.bottomMargin = Math.round(dm.heightPixels * (materialMode ? 0.035f : 0.07f));
            root.addView(pillDock, pp);
            if (materialMode) pillDock.setElevation(6f * density);
            if (!pillObserverSet) {
                pillObserverSet = true;
                adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                    @Override public void onChanged() { refreshPillDock(); }
                    @Override public void onItemRangeInserted(int a, int b) { refreshPillDock(); }
                    @Override public void onItemRangeRemoved(int a, int b) { refreshPillDock(); }
                    @Override public void onItemRangeChanged(int a, int b) { refreshPillDock(); }
                });
            }
        }

        View hs = findViewById(R.id.heroShelf);
        if (hero && hs != null && heroShelfVisibility < 0) heroShelfVisibility = hs.getVisibility();
        if (hs != null) hs.setVisibility(hero ? View.GONE : (heroShelfVisibility >= 0 ? heroShelfVisibility : hs.getVisibility()));
        if (gridWrap != null) gridWrap.setVisibility(hero ? View.GONE : View.VISIBLE);
        if (heroBigClock!=null)heroBigClock.setVisibility("hero".equals(getHomeLayout())?View.VISIBLE:View.GONE);
        View originalClock=findViewById(R.id.clock);
        if(originalClock!=null && "hero".equals(getHomeLayout()))originalClock.setVisibility(View.INVISIBLE);
        View heroLegacyTop = findViewById(R.id.leftBlock);
        if (heroLegacyTop != null && !materialMode && !pillsMode) heroLegacyTop.setVisibility("hero".equals(getHomeLayout()) ? View.GONE : View.VISIBLE);
        if(heroWeatherPill!=null)heroWeatherPill.setVisibility("hero".equals(getHomeLayout())?View.VISIBLE:View.GONE);
        if (!pillsMode && !materialMode) hidePillAllAppsDrawer(false);
        configurePillsTop(pillsMode);
        if (!pillsMode && !materialMode) moveClockBlock(hero);
        configureMaterialLayout(materialMode);
        if (heroBlob != null && materialMode) heroBlob.setElevation(2f * density);
        if (heroTopIcons != null && materialMode) heroTopIcons.setElevation(5f * density);
        if (pillDock != null && materialMode) pillDock.setElevation(6f * density);

        if (heroCarousel != null) {
            int vis = hero ? View.VISIBLE : View.GONE;
            heroCarousel.setVisibility((pillsMode || materialMode || "hero".equals(getHomeLayout())) ? View.GONE : vis);
            if(heroAppGrid!=null)heroAppGrid.setVisibility("hero".equals(getHomeLayout())?View.VISIBLE:View.GONE);
            heroTopIcons.setVisibility(vis);
            heroDate.setVisibility(pillsMode || materialMode ? View.GONE : vis);
            heroCarousel.setActive(hero && !materialMode && !"hero".equals(getHomeLayout()));
            if (!hero) heroBlob.setAccent(0xFF3A86FF, false);
            else if (materialMode) heroBlob.setAccent(0xFFB21C21, true);
            else if (pillsMode) heroBlob.setAccent(0xFF3A86FF, false);
            heroBlob.setVisibility((pillsMode || "hero".equals(getHomeLayout())) ? View.GONE : vis);
        }
        if (hero) {
            hideBehindHero();
            if (heroGuard == null) {
                heroGuard = this::hideBehindHero;
                root.getViewTreeObserver().addOnGlobalLayoutListener(heroGuard);
            }
        }
        if (pillDock != null) {
            FrameLayout.LayoutParams dockParams = (FrameLayout.LayoutParams)pillDock.getLayoutParams();
            dockParams.bottomMargin = Math.round(dm.heightPixels * (materialMode ? 0.035f : (pillsMode ? 0f : 0.07f)));
            pillDock.setPadding(pillDock.getPaddingLeft(), pillDock.getPaddingTop(), pillDock.getPaddingRight(),
                    pillsMode ? Math.round(dm.heightPixels * 0.28f) : 0);   // Pill dock + Apps pill raised from the bottom
            pillDock.setLayoutParams(dockParams);
            pillDock.setVisibility(hero && !"hero".equals(getHomeLayout()) ? View.VISIBLE : View.GONE);
            if (hero) { pillDock.setMode(getHomeLayout()); refreshPillDock(); }
        }
        if (chombbWidgetShelf != null) refreshChombbWidgetShelf();
    }

    /** Material-only labelled navigation, preserving GlassTV's existing actions. */
    private View createMaterialNavItem(int drawable, String title, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.HORIZONTAL);
        item.setGravity(Gravity.CENTER);
        item.setFocusable(true);
        item.setClickable(true);
        ImageView glyph = new ImageView(this);
        glyph.setImageResource(drawable);
        glyph.setColorFilter(Color.WHITE);
        item.addView(glyph, new LinearLayout.LayoutParams(Math.round(21*density),Math.round(21*density)));
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP,16);
        label.setTypeface(null,android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2,-2);
        lp.leftMargin = Math.round(9*density);
        item.addView(label,lp);
        item.setOnClickListener(v -> action.run());
        return item;
    }

    /** Material UI: app-driven animated blob over the existing selected wallpaper. */
    private void configureMaterialLayout(boolean enabled) {
        View classicLeft = findViewById(R.id.leftBlock);
        if (classicLeft != null) classicLeft.setVisibility(enabled || "pills".equals(getHomeLayout()) ? View.GONE : View.VISIBLE);
        if (enabled && materialBackdropDim == null) {
            // Preserve user's wallpaper but lower its contrast to match A9's tonal background.
            materialBackdropDim = new View(this);
            materialBackdropDim.setBackgroundColor(Color.BLACK);
            materialBackdropDim.setClickable(false);
            materialBackdropDim.setFocusable(false);
            root.addView(materialBackdropDim, new FrameLayout.LayoutParams(-1, -1));
            materialBackdropDim.setElevation(1f * density);
        }
        if (materialBackdropDim != null) materialBackdropDim.setVisibility(enabled ? View.VISIBLE : View.GONE);
        if (enabled && materialClockBlock == null) {
            materialClockBlock = new LinearLayout(this);
            materialClockBlock.setOrientation(LinearLayout.VERTICAL);
            TextClock clock = new TextClock(this);
            clock.setFormat12Hour("h:mm"); clock.setFormat24Hour("HH:mm");
            clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 62);
            clock.setTextColor(Color.WHITE);
            clock.setIncludeFontPadding(false);
            try { clock.setTypeface(getResources().getFont(R.font.outfit)); } catch(Exception ignored) {}
            materialClockBlock.addView(clock);
            TextClock date = new TextClock(this);
            date.setFormat12Hour("EEEE, MMMM d"); date.setFormat24Hour("EEEE, MMMM d");
            date.setTextColor(0xFFF0F0F0);
            date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            try { date.setTypeface(getResources().getFont(R.font.outfit)); } catch(Exception ignored) {}
            materialClockBlock.addView(date);
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);
            cp.leftMargin = Math.round(70*density); cp.topMargin = Math.round(38*density);
            root.addView(materialClockBlock,cp);
            materialClockBlock.setElevation(5f * density);
        }
        if (materialClockBlock != null) materialClockBlock.setVisibility(enabled ? View.VISIBLE : View.GONE);
        if (false && enabled && materialWeatherPanel == null) {
            materialWeatherPanel = new LinearLayout(this);
            materialWeatherPanel.setGravity(Gravity.CENTER_VERTICAL);
            materialWeatherPanel.setOrientation(LinearLayout.HORIZONTAL);
            GradientDrawable weatherBg = new GradientDrawable();
            weatherBg.setColor(0xE91B1E24);
            weatherBg.setCornerRadius(Math.round(52*density));
            materialWeatherPanel.setBackground(weatherBg);
            materialWeatherPanel.setPadding(Math.round(22*density),Math.round(10*density),Math.round(22*density),Math.round(10*density));
            View original = findViewById(R.id.weatherCompact);
            // Reuse the existing animated weather component, without changing its data source.
            if (original != null && original.getParent() instanceof ViewGroup) {
                if (originalWeatherParent == null) {
                    originalWeatherParent = (ViewGroup) original.getParent();
                    originalWeatherIndex = originalWeatherParent.indexOfChild(original);
                    originalWeatherParams = original.getLayoutParams();
                }
                ((ViewGroup)original.getParent()).removeView(original);
                materialWeatherPanel.addView(original,new LinearLayout.LayoutParams(-2,-1));
            }
            FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(Math.round(380*density),Math.round(92*density),Gravity.TOP|Gravity.END);
            wp.topMargin = Math.round(100*density); wp.rightMargin = Math.round(56*density);
            root.addView(materialWeatherPanel,wp);
            materialWeatherPanel.setElevation(5f * density);
        }
        if (materialWeatherPanel != null) materialWeatherPanel.setVisibility(View.GONE);
        if (materialWeatherPanel != null && originalWeatherParent != null) {
            View original = findViewById(R.id.weatherCompact);
            if (original != null && original.getParent() == materialWeatherPanel) {
                materialWeatherPanel.removeView(original);
                originalWeatherParent.addView(original,Math.min(originalWeatherIndex,originalWeatherParent.getChildCount()),originalWeatherParams);
            }
        }
        if (enabled && materialFocusedName == null) {
            materialFocusedName = new TextView(this);
            materialFocusedName.setTextColor(Color.WHITE);
            materialFocusedName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 70);
            try { materialFocusedName.setTypeface(getResources().getFont(R.font.outfit), android.graphics.Typeface.BOLD); } catch(Exception ignored) { materialFocusedName.setTypeface(null, android.graphics.Typeface.BOLD); }
            materialFocusedName.setShadowLayer(5f, 0, 2f, 0xAA000000);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2,-2,Gravity.START|Gravity.BOTTOM);
            lp.leftMargin = Math.round(68*density);
            lp.bottomMargin = Math.round(240*density);
            root.addView(materialFocusedName,lp);
            materialFocusedName.setElevation(5f * density);
        }
        if (materialFocusedName != null) materialFocusedName.setVisibility(enabled ? View.VISIBLE : View.GONE);
    }

    /** UI #3 only: slide-up installed apps, with dark grey tiles and full-colour icons on focus. */
    private boolean isDescendantOf(View view, View parent) {
        View current = view;
        while (current != null) {
            if (current == parent) return true;
            android.view.ViewParent p = current.getParent();
            current = p instanceof View ? (View) p : null;
        }
        return false;
    }

    private void showPillAllAppsDrawer() {
        if (!("pills".equals(getHomeLayout()) || "material".equals(getHomeLayout()) || "hero".equals(getHomeLayout())) || adapter == null || pillAllAppsDrawer != null) return;
        if ("material".equals(getHomeLayout())) { showMaterialAppsDrawer(); return; }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final float scale = dm.widthPixels / 1920f;
        int pad = Math.round(32 * scale);
        pillAllAppsDrawer = new FrameLayout(this);
        pillAllAppsDrawer.setFocusableInTouchMode(true);
        boolean sideDrawer = "material".equals(getHomeLayout());
        GradientDrawable panel = sideDrawer ? new GradientDrawable()
                : new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xF0213041, 0xFC101923});
        panel.setCornerRadii(new float[]{pad*1.5f,pad*1.5f,pad*1.5f,pad*1.5f,0,0,0,0});
        panel.setStroke(Math.max(1, Math.round(1.5f*scale)), 0x24FFFFFF);
        final MaterialStyle drawerStyle = sideDrawer && pillDock != null ? pillDock.materialStyle() : null;
        final MaterialPalette drawerPalette = drawerStyle != null ? drawerStyle.current() : MaterialPalette.of(MaterialPalette.DEFAULT_SEED);
        if (sideDrawer) {
            panel.setColor((drawerPalette.container & 0x00FFFFFF) | 0xF2000000);
            panel.setCornerRadius(Math.round(80*scale));
            panel.setStroke(0,Color.TRANSPARENT);
        }
        pillAllAppsDrawer.setBackground(panel);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setClipChildren(false);
        body.setClipToPadding(false);
        body.setPadding(sideDrawer ? pad*2 : pad,pad,pad,pad);
        TextView title = new TextView(this);
        title.setText("All Apps"); title.setTextColor(sideDrawer ? drawerPalette.onSurface : Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        body.addView(title);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, Math.round(10*scale), 0, Math.round(10*scale));
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        rows.setClipChildren(false);
        rows.setClipToPadding(false);
        LinearLayout current = null;
        int count = 0;
        View first = null;
        drawerTiles = new java.util.ArrayList<>();
        drawerCols = sideDrawer ? 3 : 4;
        for (int i=0; i<adapter.tileCount(); i++) {
            AppAdapter.Entry e = adapter.tileAt(i);
            if (e.kind != AppAdapter.Entry.APP) continue;
            if (count % (sideDrawer ? 3 : 4) == 0) {
                current = new LinearLayout(this);
                current.setOrientation(LinearLayout.HORIZONTAL);
                current.setClipChildren(false);
                current.setClipToPadding(false);
                rows.addView(current, new LinearLayout.LayoutParams(-1, Math.round((sideDrawer ? 178 : 142)*scale)));
            }
            final int pos = i;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(sideDrawer ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
            tile.setGravity(Gravity.CENTER);
            tile.setFocusable(true);
            tile.setClickable(true);
            GradientDrawable tileBg = new GradientDrawable();
            tileBg.setCornerRadius(Math.round((sideDrawer ? 40 : 70)*scale));
            tileBg.setColor(sideDrawer ? drawerPalette.containerHigh : PillDock.PILL_UNFOCUSED);
            if (!sideDrawer) tileBg.setStroke(Math.max(1, Math.round(1.5f*scale)), 0x24FFFFFF);
            tile.setBackground(tileBg);
            ImageView icon = new ImageView(this);
            IconLoader.into(icon, e.pkg, e.icon, Math.round((sideDrawer ? 88 : 56) * scale));
            if (!sideDrawer) icon.setColorFilter(PillDock.PILL_ICON_GREY, android.graphics.PorterDuff.Mode.SRC_IN);
            icon.setAlpha(1f);
            tile.addView(icon, new LinearLayout.LayoutParams(Math.round((sideDrawer ? 88 : 56)*scale),Math.round((sideDrawer ? 88 : 56)*scale)));
            TextView label = new TextView(this);
            label.setText(e.label); label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setTextColor(sideDrawer ? drawerPalette.onSurface : 0xFFFFFFFF);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, sideDrawer ? 15 : 12);
            label.setGravity(Gravity.CENTER);
            if (sideDrawer) tile.addView(label, new LinearLayout.LayoutParams(-1,-2));
            else {
                label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0,-2,1);
                llp.leftMargin = Math.round(14*scale);
                tile.addView(label, llp);
                tile.setPadding(Math.round(26*scale),0,Math.round(20*scale),0);
            }
            tile.setOnFocusChangeListener((v,focused)->{
                if (!sideDrawer) {
                    // Pill focus: bright glass fill, dark text, a lift and a soft white glow.
                    tileBg.setColor(focused ? PillDock.PILL_FOCUSED : PillDock.PILL_UNFOCUSED);
                    tileBg.setStroke(Math.max(1, Math.round((focused ? 3 : 1.5f)*scale)), focused ? 0x66FFFFFF : 0x24FFFFFF);
                    label.setTextColor(focused ? PillDock.PILL_LABEL_DARK : Color.WHITE);
                    tile.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f).translationZ(focused ? 16*scale : 0f)
                            .setDuration(200).start();
                }
                if (focused) icon.clearColorFilter();
                else if (!sideDrawer) icon.setColorFilter(PillDock.PILL_ICON_GREY, android.graphics.PorterDuff.Mode.SRC_IN);
                if (sideDrawer) {
                    GradientDrawable focusBg = new GradientDrawable();
                    focusBg.setCornerRadius(Math.round(40*scale));
                    MaterialPalette palette = drawerStyle != null ? drawerStyle.current() : drawerPalette;
                    focusBg.setColor(palette.containerHigh);
                    focusBg.setStroke(focused ? Math.max(2,Math.round(6*scale)) : 0,palette.primary);
                    tile.setBackground(focusBg);
                    tile.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f)
                        .setDuration(350).setInterpolator(MaterialStyle.FAST_SPATIAL).start();
                }
            });
            if (drawerStyle != null) drawerStyle.addListener(palette -> {
                tileBg.setColor(palette.containerHigh);
                label.setTextColor(palette.onSurface);
                if (!tile.isFocused()) tile.setBackground(tileBg);
            });
            tile.setOnClickListener(v -> adapter.launchAt(pos));
            tile.setOnLongClickListener(v -> { showDrawerTileActions(pos, v); return true; });
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,-1,1);
            tp.setMargins(Math.round(7*scale),Math.round(7*scale),Math.round(7*scale),Math.round(7*scale));
            current.addView(tile,tp);
            drawerTiles.add(tile);
            if (first == null) first = tile;
            count++;
        }
        scroll.addView(rows);
        body.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        pillAllAppsDrawer.addView(body,new FrameLayout.LayoutParams(-1,-1));
        FrameLayout.LayoutParams lp = sideDrawer
                ? new FrameLayout.LayoutParams(Math.round(dm.widthPixels*0.49f),-1,Gravity.RIGHT|Gravity.TOP)
                : new FrameLayout.LayoutParams(-1,Math.round(dm.heightPixels*0.72f),Gravity.BOTTOM);
        if (drawerStyle != null) drawerStyle.addListener(palette -> {
            panel.setColor((palette.container & 0x00FFFFFF) | 0xF2000000);
            title.setTextColor(palette.onSurface);
        });
        root.addView(pillAllAppsDrawer,lp);
        pillAllAppsDrawer.bringToFront();
        // Keep the drawer above the animated blob and every dock overlay.
        pillAllAppsDrawer.setElevation(1000f * getResources().getDisplayMetrics().density);
        if (sideDrawer) {
            materialDrawerAlpha.clear();
            for (int i=0;i<root.getChildCount();i++) {
                View child = root.getChildAt(i);
                if (child == pillAllAppsDrawer) continue;
                materialDrawerAlpha.put(child,child.getAlpha());
                child.animate().translationX(-Math.round(dm.widthPixels*0.23f))
                        .alpha(child.getAlpha()*0.35f).setDuration(360).start();
            }
            pillAllAppsDrawer.setTranslationX(lp.width);
            springTo(pillAllAppsDrawer, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_X, 0f, 250f, 0.78f);
        } else {
            if (pillDock != null) pillDock.animate().alpha(0.25f).setDuration(300).start();
            pillAllAppsDrawer.setTranslationY(lp.height);
            springTo(pillAllAppsDrawer, androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, 0f, 245f, 0.75f);
        }
        if (first != null) first.requestFocus();
    }

    /** Starts a spring on one view property (soft, ColorOS-style settle). */
    private SpringAnimation drawerOpeningSpring;

    private void springTo(View v, androidx.dynamicanimation.animation.DynamicAnimation.ViewProperty prop, float target, float stiffness, float damping) {
        androidx.dynamicanimation.animation.SpringAnimation sp = new androidx.dynamicanimation.animation.SpringAnimation(v, prop, target);
        sp.getSpring().setStiffness(stiffness);
        sp.getSpring().setDampingRatio(damping);
        drawerOpeningSpring = sp;
        sp.start();
    }

    private void hidePillAllAppsDrawer(boolean animate) {
        if (pillAllAppsDrawer == null) return;
        FrameLayout drawer = pillAllAppsDrawer;
        if (drawerOpeningSpring != null) {
            drawerOpeningSpring.cancel();
            drawerOpeningSpring = null;
        }
        pillAllAppsDrawer = null;
        drawerTiles = null;
        boolean sideDrawer = "material".equals(getHomeLayout());
        if (sideDrawer) {
            for (java.util.Map.Entry<View,Float> item : materialDrawerAlpha.entrySet()) {
                View child = item.getKey();
                if (animate) child.animate().translationX(0).alpha(item.getValue()).setDuration(360).start();
                else { child.setTranslationX(0); child.setAlpha(item.getValue()); }
            }
            materialDrawerAlpha.clear();
            if (animate && drawer.getChildCount() > 0) morphMaterialDrawer(drawer, drawer.getChildAt(0), false, () -> root.removeView(drawer));
            else root.removeView(drawer);
        } else {
            if (pillDock != null) pillDock.animate().alpha(1f).setDuration(300).start();
            if (animate) {
                androidx.dynamicanimation.animation.SpringAnimation sp = new androidx.dynamicanimation.animation.SpringAnimation(drawer,
                        androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, drawer.getHeight());
                sp.getSpring().setStiffness(260f);
                sp.getSpring().setDampingRatio(1f);
                sp.addEndListener((an, c, v, vel) -> root.removeView(drawer));
                sp.start();
            }
            else root.removeView(drawer);
        }
        View back = materialDrawerOrigin != null && materialDrawerOrigin.getParent() instanceof View ? (View) materialDrawerOrigin.getParent() : null;
        if ("material".equals(getHomeLayout()) && back != null && back.isAttachedToWindow() && back.isFocusable()) back.requestFocus();
        else if (pillDock != null && ("pills".equals(getHomeLayout()) || "material".equals(getHomeLayout()))) pillDock.focusCurrent();
        else if (heroAppGrid != null && "hero".equals(getHomeLayout())) heroAppGrid.focusCurrent();
    }

    private void refreshPillDock() {
        if (pillDock == null) return;
        handler.removeCallbacks(pillRefresh);
        handler.postDelayed(pillRefresh, 150);   // a reload fires several changes at once
    }

    private final Runnable pillRefresh = new Runnable() {
        @Override public void run() { if (pillDock != null && isHeroLayout()) pillDock.refresh(); }
    };

    /** Pill layout has its own clock/date column and reuses the animated Classic weather view. */
    private void configurePillsTop(boolean enabled) {
        View classicClock = findViewById(R.id.clock);
        View classicSearch = findViewById(R.id.classicSearch);
        View leftBlock = findViewById(R.id.leftBlock);
        View weather = findViewById(R.id.weatherCompact);
        if (classicClock != null) classicClock.setVisibility(enabled ? View.GONE : View.VISIBLE);
        if (classicSearch != null) classicSearch.setVisibility(isHeroLayout() ? View.GONE : View.VISIBLE);
        if (pillsTopBlock == null) {
            pillsTopBlock = new LinearLayout(this);
            pillsTopBlock.setOrientation(LinearLayout.VERTICAL);
            pillsTopBlock.setGravity(Gravity.START);
            pillsTopBlock.setClipChildren(false);
            TextClock largeClock = new TextClock(this);
            float ps = Math.min(getResources().getDisplayMetrics().widthPixels / 1920f, getResources().getDisplayMetrics().heightPixels / 1080f);
            largeClock.setFormat12Hour("h:mm a");
            largeClock.setFormat24Hour("HH:mm");
            largeClock.setTextSize(TypedValue.COMPLEX_UNIT_PX, 70 * ps);
            largeClock.setTextColor(Color.WHITE);
            largeClock.setIncludeFontPadding(false);
            largeClock.setShadowLayer(4f, 0, 2f, 0x99000000);
            try { largeClock.setTypeface(getResources().getFont(R.font.outfit)); largeClock.setFontVariationSettings("'wght' 400"); } catch (Exception ignored) {}
            largeClock.setFocusable(false);
            pillsTopBlock.addView(largeClock, new LinearLayout.LayoutParams(-2,-2));
            TextClock date = new TextClock(this);
            date.setFormat12Hour("d MMM ''yy");
            date.setFormat24Hour("d MMM ''yy");
            date.setAllCaps(true);
            date.setLetterSpacing(0.03f);
            try { date.setTypeface(getResources().getFont(R.font.outfit)); } catch (Exception ignored) {}
            date.setTextSize(TypedValue.COMPLEX_UNIT_PX, 28 * ps);
            date.setTextColor(0xFFE6EAF1);
            date.setShadowLayer(3f,0,1f,0x99000000);
            date.setFocusable(false);
            LinearLayout.LayoutParams dateLp = new LinearLayout.LayoutParams(-2,-2);
            dateLp.topMargin = Math.round(4*density);
            pillsTopBlock.addView(date,dateLp);
            // Weather under the date: mono white icon and temperature, no capsule.
            pillsWeather = new HeroWeatherPill(this, true);
            pillsWeather.update(WeatherAirQuality.getFullWeather(this));
            LinearLayout.LayoutParams pwLp = new LinearLayout.LayoutParams(-2, Math.round(44 * ps));
            pwLp.topMargin = Math.round(8 * density);
            pillsTopBlock.addView(pillsWeather, pwLp);
            FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);
            topLp.leftMargin = Math.round(getResources().getDisplayMetrics().widthPixels * 0.06f);
            topLp.topMargin = Math.round(getResources().getDisplayMetrics().heightPixels * 0.055f);
            root.addView(pillsTopBlock,topLp);
        }
        final boolean weatherInPills = false;   // the reference Pill screen has no weather chip
        if (enabled && weatherInPills && weather != null) {
            if (originalWeatherParent == null && weather.getParent() instanceof ViewGroup) {
                originalWeatherParent = (ViewGroup) weather.getParent();
                originalWeatherIndex = originalWeatherParent.indexOfChild(weather);
                originalWeatherParams = weather.getLayoutParams();
            }
            if (weather.getParent() != pillsTopBlock) {
                if (weather.getParent() instanceof ViewGroup) ((ViewGroup)weather.getParent()).removeView(weather);
                LinearLayout.LayoutParams weatherLp = new LinearLayout.LayoutParams(-2,Math.round(58*density));
                weatherLp.topMargin = Math.round(5*density);
                pillsTopBlock.addView(weather,weatherLp);
            }
        } else if (!enabled && weather != null && originalWeatherParent != null && weather.getParent() == pillsTopBlock) {
            pillsTopBlock.removeView(weather);
            originalWeatherParent.addView(weather,Math.min(originalWeatherIndex,originalWeatherParent.getChildCount()),originalWeatherParams);
        }
        pillsTopBlock.setVisibility(enabled ? View.VISIBLE : View.GONE);
        if (leftBlock != null) leftBlock.setVisibility(enabled ? View.GONE : View.VISIBLE);
    }

    /** Hero puts the clock top-left, clock first and the weather chip after it; Classic puts it back. */
    private void moveClockBlock(boolean hero) {
        View block = findViewById(R.id.leftBlock);
        View weather = findViewById(R.id.weatherCompact);
        View clock = findViewById(R.id.clock);
        if (block == null || weather == null || clock == null) return;
        RelativeLayout.LayoutParams rp = (RelativeLayout.LayoutParams) block.getLayoutParams();
        LinearLayout.LayoutParams wp = (LinearLayout.LayoutParams) weather.getLayoutParams();
        LinearLayout parent = (LinearLayout) block;
        if (hero) {
            rp.removeRule(RelativeLayout.ALIGN_PARENT_END);
            rp.addRule(RelativeLayout.ALIGN_PARENT_START);
            wp.setMarginEnd(0);
            wp.setMarginStart(Math.round(12 * density));
            if (parent.indexOfChild(weather) == 0) { parent.removeView(weather); parent.addView(weather, wp); }
        } else {
            rp.removeRule(RelativeLayout.ALIGN_PARENT_START);
            rp.addRule(RelativeLayout.ALIGN_PARENT_END);
            wp.setMarginStart(0);
            wp.setMarginEnd(Math.round(12 * density));
            if (parent.indexOfChild(weather) != 0) { parent.removeView(weather); parent.addView(weather, 0, wp); }
        }
        block.setLayoutParams(rp);
        weather.setLayoutParams(wp);
    }

    // ---- home widgets (Preferences > Widgets) -------------------------------------------------------
    /** Horizontal row of columns; cards fill a column down to the free space's bottom, then the next column. */
    private LinearLayout chombbWidgetShelf;
    private final java.util.List<View> widgetCards = new java.util.ArrayList<>();
    private int shelfSignature;
    private int shelfPackedFor = -1;
    /** Classic: where the dock row sits when the grid is not scrolled, so the shelf can ride up with it. */
    private float classicRestDockTop = -1f;
    private final int[] shelfAt = new int[2], shelfRootAt = new int[2];
    private final Runnable lyricWidgetRefresh = new Runnable() {
        @Override public void run() {
            if (chombbWidgetShelf == null || !chombbWidgetShelf.isShown() || screensaverActive) return;
            for (View card : widgetCards) {
                if (ChombbWidgets.kindOf(card) == ChombbWidgets.LYRICS) {
                    if (hasWindowFocus()) ChombbWidgets.update(MainActivity.this, card, false);
                    handler.postDelayed(this, 100);
                    return;
                }
            }
        }
    };
    private final Runnable chombbWidgetRefresh = new Runnable() {
        @Override public void run() {
            if (chombbWidgetShelf == null || chombbWidgetShelf.getVisibility() != View.VISIBLE || screensaverActive) return;
            for (View card : widgetCards) {
                if (ChombbWidgets.kindOf(card) != ChombbWidgets.LYRICS) ChombbWidgets.update(MainActivity.this, card, false);
            }
            handler.postDelayed(this, 1000);
        }
    };

    /** Creates the shelf once (below the screensaver); later calls only refresh it. */
    private void setupChombbWidgetShelf() {
        if (chombbWidgetShelf == null) {
            chombbWidgetShelf = new LinearLayout(this);
            chombbWidgetShelf.setOrientation(LinearLayout.HORIZONTAL);
            chombbWidgetShelf.setClipChildren(false);
            chombbWidgetShelf.setClipToPadding(false);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
            int at = screensaverView != null ? root.indexOfChild(screensaverView) : -1;
            if (at >= 0) root.addView(chombbWidgetShelf, at, params);
            else root.addView(chombbWidgetShelf, params);
            chombbWidgetShelf.addOnLayoutChangeListener((v, l, tp, r, b, ol, ot, or, ob) -> {
                if (b - tp != ob - ot || r - l != or - ol) placeWidgetShelf();
            });
        }
        refreshChombbWidgetShelf();
    }

    private void refreshChombbWidgetShelf() {
        if (chombbWidgetShelf == null) return;
        java.util.List<Integer> want = ChombbWidgets.ordered(this);
        int sig = (want.hashCode() * 31 + ChombbWidgets.widthPx(this)) * 31 + ChombbWidgets.barStyle(this);
        boolean rebuilt = false;
        if (sig != shelfSignature || widgetCards.size() != want.size()) {
            shelfSignature = sig;
            rebuilt = true;
            buildWidgetCards(ChombbWidgets.sizeFactor(this));
        }
        // Material's black backdrop and dock are raised (elevation); the shelf goes above them there.
        chombbWidgetShelf.setElevation("material".equals(getHomeLayout()) ? 7f * density : 0f);
        boolean show = !widgetCards.isEmpty() && !screensaverActive;
        chombbWidgetShelf.setVisibility(show ? View.VISIBLE : View.GONE);
        handler.removeCallbacks(chombbWidgetRefresh);
        handler.removeCallbacks(lyricWidgetRefresh);
        if (!show) return;
        handler.postDelayed(lyricWidgetRefresh, 100);
        for (View card : widgetCards) ChombbWidgets.update(this, card, rebuilt);
        placeWidgetShelf();
        // The dock or grid it sits beside may lay out a moment later: place it again then.
        handler.removeCallbacks(placeShelfLater);
        handler.postDelayed(placeShelfLater, 600);
        handler.postDelayed(chombbWidgetRefresh, 1000);
    }

    private final Runnable placeShelfLater = this::placeWidgetShelf;
    private float widgetFactor = 1f;

    private void buildWidgetCards(float factor) {
        widgetFactor = factor;
        for (View card : widgetCards) if (card.getParent() instanceof ViewGroup) ((ViewGroup) card.getParent()).removeView(card);
        widgetCards.clear();
        for (int kind : ChombbWidgets.ordered(this)) {
            View card = ChombbWidgets.card(this, kind, factor);
            if (kind == ChombbWidgets.LYRICS) ChombbWidgets.interactive(card, () -> LyricsOverlay.show(this, card));
            else if (kind == ChombbWidgets.MEDIA) {
                // OK = open the music app that is playing. Hold OK or Menu = save / like the song. No play/pause button.
                ChombbWidgets.interactive(card, () -> openPlayingApp());
                card.setOnLongClickListener(v -> { ChombbWidgets.popHeart(card, ChombbWidgets.mediaSave(this)); return true; });
            }
            else if (kind == ChombbWidgets.RECENT) ChombbWidgets.interactive(card, () -> startActivity(new Intent(this, RecentAppsActivity.class)));
            if (!card.isFocusable()) ChombbWidgets.focusable(card);
            card.setOnKeyListener((v, code, ev) -> widgetKey(v, code, ev));
            ChombbWidgets.update(this, card, true);
            widgetCards.add(card);
        }
        shelfPackedFor = -1;
    }

    /**
     * Free space for widgets in this layout, at rest: {top, bottom, left, right} in root pixels. Never over
     * the dock, the Hero grid, the clocks or the Classic shelves.
     */
    private float[] widgetArea() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float s = ChombbWidgets.scale(this);
        float W = dm.widthPixels, H = dm.heightPixels;
        float top, bottom, left, right = W - 48 * s;
        switch (getHomeLayout()) {
            case "hero": {
                top = H * 0.13f;
                bottom = H - 40 * s;
                float gridRight = heroAppGrid != null && heroAppGrid.getWidth() > 0
                        ? heroAppGrid.getX() + heroAppGrid.getWidth() : (W + 5 * 195 * s) / 2f;
                left = gridRight + 36 * s;
                break;
            }
            case "pills":
            case "material": {
                boolean pills = "pills".equals(getHomeLayout());
                top = H * (pills ? 0.145f : 0.36f);
                float dockTop = pillDock != null && pillDock.getHeight() > 0 ? pillDock.getY() + 20 * s : H * 0.66f;
                bottom = dockTop - (pills ? 16 : 44) * s;   // Material's dock cards lift on focus: keep widgets clear of them
                left = W * (pills ? 0.35f : 0.5f);   // Material: its clock and app name live on the left
                if (pills) right = W * 0.945f;
                break;
            }
            default: {
                top = 120 * s;
                bottom = classicRestDockTop > 0 ? classicRestDockTop - 28 * s : H * 0.6f;
                left = W * 0.40f;                    // the place name shelf is on the left
                if (islamicShelf != null && islamicShelf.getVisibility() == View.VISIBLE && islamicShelf.getWidth() > 0)
                    right = Math.min(right, islamicShelf.getX() - 24 * s);
                break;
            }
        }
        float safeRight = W - 20 * s;
        float safeLeft = Math.min(left, safeRight - 100 * s);
        return new float[]{top, Math.max(top + 100 * s, bottom), safeLeft,
                Math.min(safeRight, Math.max(safeLeft + 100 * s, right))};
    }

    /**
     * Fills columns top to bottom within {@code height} (first column rightmost). Returns whether every card
     * fits inside {@code maxWidth}.
     */
    private boolean packWidgetColumns(int height, int maxWidth) {
        float s = ChombbWidgets.scale(this) * widgetFactor;
        int w = ChombbWidgets.widthPx(this, widgetFactor), gap = Math.round(14 * s);
        for (View card : widgetCards) if (card.getParent() instanceof ViewGroup) ((ViewGroup) card.getParent()).removeView(card);
        chombbWidgetShelf.removeAllViews();
        LinearLayout column = null;
        int used = 0, cols = 0;
        boolean tooTall = false;
        for (View card : widgetCards) {
            card.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED);
            int h = card.getMeasuredHeight();
            if (h > height) tooTall = true;
            if (column == null || (column.getChildCount() > 0 && used + gap + h > height)) {
                column = new LinearLayout(this);
                column.setOrientation(LinearLayout.VERTICAL);
                column.setClipChildren(false);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(w, -2);
                if (chombbWidgetShelf.getChildCount() > 0) cl.rightMargin = gap;
                chombbWidgetShelf.addView(column, 0, cl);   // new columns go to the left
                used = 0;
                cols++;
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            if (column.getChildCount() > 0) lp.topMargin = gap;
            column.addView(card, lp);
            used += (column.getChildCount() > 1 ? gap : 0) + h;
        }
        return !tooTall && cols * w + Math.max(0, cols - 1) * gap <= maxWidth;
    }

    private int shelfFitKey = -1;

    /** Fits the cards with room for the focused card's outline and scale. */
    private void fitWidgets(float[] area) {
        int height = Math.round(area[1] - area[0]), maxWidth = Math.round(area[3] - area[2]);
        int focusRoom = Math.round(24 * ChombbWidgets.scale(this));
        height = Math.max(1, height - focusRoom);
        maxWidth = Math.max(1, maxWidth - focusRoom);
        int key = (height * 31 + maxWidth) * 31 + shelfSignature;
        if (key == shelfFitKey && chombbWidgetShelf.getChildCount() > 0) return;
        shelfFitKey = key;
        float chosen = ChombbWidgets.sizeFactor(this);
        if (widgetFactor != chosen) buildWidgetCards(chosen);
        while (!packWidgetColumns(height, maxWidth) && widgetFactor > 0.41f) {
            buildWidgetCards(Math.max(0.4f, widgetFactor - 0.08f));
        }
    }

    /**
     * Puts the shelf in each layout's free space so it never covers the dock or apps. Classic: right side,
     * resting on the dock row and moving up with it as the grid scrolls, fading under the top bar.
     */
    private void placeWidgetShelf() {
        if (chombbWidgetShelf == null || chombbWidgetShelf.getVisibility() != View.VISIBLE) return;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float s = ChombbWidgets.scale(this);
        boolean classic = "classic".equals(getHomeLayout());
        int off = 0;
        if (classic) {
            RecyclerView.LayoutManager lm = grid != null ? grid.getLayoutManager() : null;
            View first = lm != null ? lm.findViewByPosition(0) : null;
            off = grid != null ? grid.computeVerticalScrollOffset() : 0;
            if (first != null) {
                grid.getLocationInWindow(shelfAt);
                root.getLocationInWindow(shelfRootAt);
                classicRestDockTop = shelfAt[1] - shelfRootAt[1] + first.getTop() + off;
            }
            if (classicRestDockTop < 0) { chombbWidgetShelf.setAlpha(0f); return; }
        }
        float[] area = widgetArea();
        fitWidgets(area);
        // Laid-out size when there is one (every scroll frame lands here); measure only after a repack.
        int w = chombbWidgetShelf.getWidth(), h = chombbWidgetShelf.getHeight();
        if (w == 0 || chombbWidgetShelf.isLayoutRequested()) {
            chombbWidgetShelf.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            w = chombbWidgetShelf.getMeasuredWidth();
            h = chombbWidgetShelf.getMeasuredHeight();
        }
        float x = Math.max(area[2], area[3] - w - 10 * s);
        float y, alpha = 1f;
        if ("hero".equals(getHomeLayout())) {
            y = Math.max(area[0], Math.min(dm.heightPixels * 0.63f - h / 2f, area[1] - h));
        } else if (classic) {
            float rest = Math.max(area[0], area[1] - h);   // sits on the dock row
            y = rest - off;
            if (y < area[0]) alpha = Math.max(0f, 1f - (area[0] - y) / (220 * s));
        } else {
            y = Math.max(area[0], area[1] - h);           // rests just above the dock
        }
        chombbWidgetShelf.setX(x);
        chombbWidgetShelf.setY(y);
        chombbWidgetShelf.setAlpha(alpha);
    }

    private void focusHomeSettings() {
        View target = findViewById(R.id.btnSettings);
        switch (getHomeLayout()) {
            case "hero":
                if (heroNav != null) target = heroNav.getChildAt(heroNav.getChildCount() - 1);
                break;
            case "pills":
            case "material":
                if (heroTopIcons != null) target = heroTopIcons.getChildAt("pills".equals(getHomeLayout()) ? 0 : 1);
                break;
        }
        // On Classic the clock is the visible Settings shortcut when the legacy top buttons are hidden.
        if (target == null || !target.isShown()) target = findViewById(R.id.clock);
        if (target != null) target.requestFocus();
    }

    private void focusHomeApps() {
        switch (getHomeLayout()) {
            case "hero":
                if (heroAppGrid != null) heroAppGrid.focusCurrent();
                break;
            case "pills":
            case "material":
                if (pillDock != null) pillDock.focusCurrent();
                break;
            default:
                focusTile(Math.max(0, lastFocused) % COLUMNS);
        }
    }

    private boolean focusWidgets(boolean fromApps) {
        if (chombbWidgetShelf == null || !chombbWidgetShelf.isShown() || widgetCards.isEmpty()) return false;
        if ("classic".equals(getHomeLayout()) && grid != null && grid.computeVerticalScrollOffset() != 0) {
            grid.stopScroll();
            grid.scrollToPosition(0);
            chombbWidgetShelf.setAlpha(1f);
        }
        return widgetCards.get(fromApps ? widgetCards.size() - 1 : 0).requestFocus();
    }

    private View nearestHeroWidget(View app) {
        if (chombbWidgetShelf == null || !chombbWidgetShelf.isShown() || chombbWidgetShelf.getChildCount() == 0) return null;
        LinearLayout column = (LinearLayout) chombbWidgetShelf.getChildAt(0);
        int y = screenCenterY(app);
        View best = null;
        int distance = Integer.MAX_VALUE;
        for (int i = 0; i < column.getChildCount(); i++) {
            View card = column.getChildAt(i);
            int nextDistance = Math.abs(screenCenterY(card) - y);
            if (nextDistance < distance) {
                best = card;
                distance = nextDistance;
            }
        }
        return best;
    }

    static int screenCenterY(View view) {
        int[] at = new int[2];
        view.getLocationOnScreen(at);
        return at[1] + view.getHeight() / 2;
    }

    private boolean widgetKey(View card, int code, KeyEvent event) {
        if (code == KeyEvent.KEYCODE_MENU && ChombbWidgets.kindOf(card) == ChombbWidgets.MEDIA) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) card.performLongClick();
            return true;
        }
        if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
        int index = widgetCards.indexOf(card);
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (index > 0) widgetCards.get(index - 1).requestFocus();
                else focusHomeSettings();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (index + 1 < widgetCards.size()) widgetCards.get(index + 1).requestFocus();
                else focusHomeApps();
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (card.getParent() instanceof LinearLayout) {
                    LinearLayout column = (LinearLayout) card.getParent();
                    int next = chombbWidgetShelf.indexOfChild(column) + (code == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1);
                    View sibling = chombbWidgetShelf.getChildAt(next);
                    if (next < 0 && "hero".equals(getHomeLayout()) && heroAppGrid != null) {
                        heroAppGrid.focusFromWidget(screenCenterY(card));
                        return true;
                    }
                    if (sibling instanceof LinearLayout) {
                        View target = ((LinearLayout) sibling).getChildAt(column.indexOfChild(card));
                        if (target != null) target.requestFocus();
                    }
                }
                return true;
            default:
                return false;
        }
    }

    /** Now Playing card: opens the app that is playing (Spotify, YouTube Music...), at its player when it says where. */
    private void openPlayingApp() {
        android.media.session.MediaController m = NowPlaying.active(this);
        if (m == null) {
            if (!NowPlaying.hasAccess(this)) requestNotificationAccess();
            else Toast.makeText(this, "Tiada lagu dimainkan", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            android.app.PendingIntent player = m.getSessionActivity();
            if (player != null) { player.send(); return; }
        } catch (Exception ignored) { }
        String pkg = m.getPackageName();
        Intent launch = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
        if (launch == null) launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) { Toast.makeText(this, "Tidak dapat buka app muzik", Toast.LENGTH_SHORT).show(); return; }
        try { startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { Toast.makeText(this, "Tidak dapat buka app muzik", Toast.LENGTH_SHORT).show(); }
    }

    private void applyAyatVisibility() {
        boolean show = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("show_daily_ayat", true);
        int visibility = show ? View.VISIBLE : View.GONE;
        if (ayatRef != null) ayatRef.setVisibility(visibility);
        if (ayatArabic != null) ayatArabic.setVisibility(visibility);
        if (ayatTranslation != null) ayatTranslation.setVisibility(visibility);
    }

    private void applyPrayerVisibility() {
        boolean show = getSharedPreferences("launcher_settings", MODE_PRIVATE)
                .getBoolean("show_prayer_times", true);
        View header = prayerHeader != null ? prayerHeader : findViewById(R.id.prayerHeader);
        View table = findViewById(R.id.prayerTable);
        if (header != null) header.setVisibility(show ? View.VISIBLE : View.GONE);
        if (table != null) table.setVisibility(show ? View.VISIBLE : View.GONE);
        View pill = prayerTimesView != null ? prayerTimesView : findViewById(R.id.prayerTimes);
        if (pill != null) pill.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private static final class WeatherPreset {
        final String name;
        final double lat, lon;
        WeatherPreset(String name, double lat, double lon) {
            this.name = name; this.lat = lat; this.lon = lon;
        }
    }

    /** The small weather badge opens a date/time/weather glass panel; no preference changes. */
    private void showCompactWeatherDetails() {
        final float d = getResources().getDisplayMetrics().density;
        final WeatherAirQuality.FullWeather weather = WeatherAirQuality.getFullWeather(this);
        final java.text.SimpleDateFormat timeFmt = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
        final java.text.SimpleDateFormat dateFmt = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", new java.util.Locale("ms", "MY"));
        String temp = weather == null ? "--°C" : weather.temp + "°C";
        String condition = weather == null || weather.condition == null ? "Cuaca tidak tersedia" : weather.condition;
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding((int)(22*d), (int)(18*d), (int)(22*d), (int)(20*d));
        body.setBackground(glassPanelBackground(0xDB303D56, 0xC8DDEEFF, 23));
        TextView heading = new TextView(this);
        String location = AppLocationManager.getLocationName(this);
        if (location == null || location.trim().isEmpty()) location = "Lokasi tidak ditetapkan";
        TextView locationView = new TextView(this);
        locationView.setText("⌖  " + location);
        locationView.setTextColor(0xFFEAF7FF);
        locationView.setTextSize(16);
        locationView.setTypeface(null, android.graphics.Typeface.BOLD);
        locationView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams locationParams = new LinearLayout.LayoutParams(-1, -2);
        locationParams.bottomMargin = (int)(9*d);
        body.addView(locationView, locationParams);
        heading.setText(temp + "  •  " + condition);
        heading.setTextColor(0xFFF4F9FF);
        heading.setTextSize(17);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        body.addView(heading);
        TextView clock = new TextView(this);
        clock.setText(timeFmt.format(new java.util.Date()));
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(46);
        clock.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = (int)(12*d);
        body.addView(clock, cp);
        TextView date = new TextView(this);
        date.setText(dateFmt.format(new java.util.Date()));
        date.setTextSize(15);
        date.setTextColor(0xFFE6EEFA);
        date.setGravity(Gravity.CENTER);
        body.addView(date);
        View line = new View(this);
        line.setBackgroundColor(0x55FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Math.max(1, (int)d));
        lp.topMargin = (int)(14*d);
        lp.bottomMargin = (int)(10*d);
        body.addView(line, lp);
        TextView footer = new TextView(this);
        footer.setText("Malaysia (MYT)  •  UTC+08:00");
        footer.setGravity(Gravity.CENTER);
        footer.setTextColor(0xFFD3E3F8);
        footer.setTextSize(13);
        body.addView(footer);
        Dialog dialog = new Dialog(this);
        dialog.setContentView(body);
        dialog.setCanceledOnTouchOutside(true);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams a = w.getAttributes();
            a.width = Math.min((int)(330*d), (int)(getResources().getDisplayMetrics().widthPixels * .46f));
            a.height = -2;
            a.gravity = Gravity.TOP | Gravity.RIGHT;
            a.x = (int)(28*d);
            a.y = (int)(86*d);
            a.dimAmount = 0.18f;
            w.setAttributes(a);
        }
        dialog.show();
        if (dialog.getWindow() != null) {
            Window dw = dialog.getWindow();
            android.view.WindowManager.LayoutParams a = dw.getAttributes();
            a.width = Math.min((int)(330*d), (int)(getResources().getDisplayMetrics().widthPixels * .46f));
            a.height = -2;
            a.gravity = Gravity.TOP | Gravity.RIGHT;
            a.x = (int)(28*d);
            a.y = (int)(86*d);
            a.dimAmount = 0.18f;
            dw.setAttributes(a);
        }
    }

    private void showWeatherLocationDialog() {
        final WeatherPreset[] presets = new WeatherPreset[]{
                new WeatherPreset("Tumpat, Kelantan", 6.19775, 102.17098),
                new WeatherPreset("Kampung Kajang Sebidang, Tumpat", 6.1677, 102.1090),
                new WeatherPreset("Kota Bharu, Kelantan", 6.1256, 102.2386),
                new WeatherPreset("Kuala Krai, Kelantan", 5.5333, 102.2000),
                new WeatherPreset("Gua Musang, Kelantan", 4.8833, 101.9667),
                new WeatherPreset("Kuala Lumpur", 3.1390, 101.6869),
                new WeatherPreset("Putrajaya", 2.9264, 101.6964),
                new WeatherPreset("Kajang, Selangor", 2.9935, 101.7871),
                new WeatherPreset("Shah Alam, Selangor", 3.0738, 101.5183),
                new WeatherPreset("Petaling Jaya, Selangor", 3.1073, 101.6067),
                new WeatherPreset("Seremban, Negeri Sembilan", 2.7297, 101.9381),
                new WeatherPreset("Melaka", 2.1896, 102.2501),
                new WeatherPreset("Johor Bahru, Johor", 1.4927, 103.7414),
                new WeatherPreset("Kuantan, Pahang", 3.8077, 103.3260),
                new WeatherPreset("Kuala Terengganu", 5.3302, 103.1408),
                new WeatherPreset("Ipoh, Perak", 4.5975, 101.0901),
                new WeatherPreset("Taiping, Perak", 4.8500, 100.7333),
                new WeatherPreset("Alor Setar, Kedah", 6.1248, 100.3678),
                new WeatherPreset("Kangar, Perlis", 6.4414, 100.1986),
                new WeatherPreset("George Town, Pulau Pinang", 5.4141, 100.3288),
                new WeatherPreset("Kota Kinabalu, Sabah", 5.9804, 116.0735),
                new WeatherPreset("Sandakan, Sabah", 5.8402, 118.1179),
                new WeatherPreset("Tawau, Sabah", 4.2448, 117.8912),
                new WeatherPreset("Kuching, Sarawak", 1.5533, 110.3592),
                new WeatherPreset("Miri, Sarawak", 4.3995, 113.9914),
                new WeatherPreset("Sibu, Sarawak", 2.2870, 111.8305),
                new WeatherPreset("Labuan", 5.2831, 115.2308),
                new WeatherPreset("Kota Bharu (Pantai Senok / Bachok)", 6.0330, 102.4230)
        };
        String current = AppLocationManager.getLocationName(this);
        int selected = 0;
        CharSequence[] labels = new CharSequence[presets.length];
        for (int i = 0; i < presets.length; i++) {
            labels[i] = presets[i].name;
            if (presets[i].name.equalsIgnoreCase(current)) selected = i;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("🌤️ Pilih Lokasi Cuaca Malaysia")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    WeatherPreset p = presets[which];
                    AppLocationManager.Station nearest = AppLocationManager.findNearestStation(p.lat, p.lon);
                    AppLocationManager.setCustomLocation(this, nearest.id, p.name, nearest.place,
                            p.lat, p.lon);
                    dialog.dismiss();
                    updateWeatherAqi();
                    WeatherAirQuality.sync(this, this::updateWeatherAqi);
                    Toast.makeText(this, "Lokasi cuaca: " + p.name, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showSoundVolumeDialog() {
        android.widget.SeekBar slider = new android.widget.SeekBar(this);
        slider.setMax(100);
        slider.setProgress(SoundEffects.getVolumePercent(this));
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setPadding(pad, pad, pad, pad);
        container.addView(slider);
        android.widget.TextView value = new android.widget.TextView(this);
        value.setTextSize(20);
        value.setText("Volume: " + slider.getProgress() + "%");
        container.addView(value);
        slider.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(android.widget.SeekBar bar, int progress, boolean fromUser) {
                value.setText("Volume: " + progress + "%");
            }
            public void onStartTrackingTouch(android.widget.SeekBar bar) {}
            public void onStopTrackingTouch(android.widget.SeekBar bar) {}
        });
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Launcher Sound Volume")
                .setView(container)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    SoundEffects.setVolumePercent(this, slider.getProgress());
                    SoundEffects.playSelect();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showSoundEffectsDialog() {
        final String[] soundOptions = new String[]{
                "🎮 PlayStation 5 (Lalai / Default Chime)",
                "🕹️ Nintendo Switch (Click & Snap Pop)",
                "🟩 Xbox Series X/S (Warm Harmonic Chime)",
                "🔇 Matikan Bunyi (Off / Muted)"
        };

        final String[] soundKeys = new String[]{
                SoundEffects.THEME_PS5,
                SoundEffects.THEME_SWITCH,
                SoundEffects.THEME_XBOX,
                SoundEffects.THEME_OFF
        };

        String currentTheme = SoundEffects.getActiveTheme(this);
        int selectedIndex = 0;
        for (int i = 0; i < soundKeys.length; i++) {
            if (soundKeys[i].equalsIgnoreCase(currentTheme)) {
                selectedIndex = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("🔊 Pilih Kesan Bunyi (Sound Effects)");
        builder.setSingleChoiceItems(soundOptions, selectedIndex, (dialog, which) -> {
            dialog.dismiss();
            String chosenKey = soundKeys[which];
            SoundEffects.setTheme(MainActivity.this, chosenKey);
            String displayName = SoundEffects.getThemeDisplayName(chosenKey);

            if (SoundEffects.THEME_OFF.equalsIgnoreCase(chosenKey)) {
                Toast.makeText(MainActivity.this, "🔇 Kesan Bunyi Dimatikan", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "🔊 Kesan Bunyi: " + displayName, Toast.LENGTH_SHORT).show();
                // Play sample of the selected theme
                handler.postDelayed(() -> SoundEffects.playSelect(), 120);
            }
        });
        builder.setNeutralButton("Volume (" + SoundEffects.getVolumePercent(this) + "%)", (dialog, which) -> showSoundVolumeDialog());
        builder.setNegativeButton("Tutup / Cancel", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private int inlineWallpaperQrPort = 8080;
    private Dialog qrUploadDialog;
    private WallpaperUploadServer uploadServer;
    private ImageView qrImageView;
    private Bitmap qrCodeBitmap;
    private String qrUploadUrl;
    private TextView qrStatusText;
    private TextView qrUrlText;

    /** Preferences-specific collection picker: QR upload and Next Photo remain in Quick Settings. */
    private void showWallpaperCollectionsFromPreferences() {
        final String[] names = {"Natural", "Malaysia", "Skyscraper", "Space", "Ocean", "Minimalist"};
        final String[] labels = {"Natural / Alam Semula Jadi", "Malaysia / Pilih Negeri",
                "Skyscraper / Bandar", "Deep Space / Angkasa", "Ocean & Coastal", "Minimalist Dark"};
        new AlertDialog.Builder(this).setTitle("Wallpaper Collections")
                .setItems(labels, (dialog, which) -> {
                    if (which == 1) showMalaysiaStateSelectorDialog();
                    else switchWallpaperCategory(names[which]);
                }).setNegativeButton("Back", null).show();
    }

    private void showWallpaperDialog() {
        File customDir = new File(getFilesDir(), "custom_wallpapers");
        File[] customFiles = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
        boolean hasCustom = customFiles != null && customFiles.length > 0;

        String currentKey = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");

        List<String> catList = new ArrayList<>();
        List<String> keyList = new ArrayList<>();

        catList.add("🌿 Natural / Alam Semula Jadi");
        keyList.add("Natural");

        String malaysiaLabel;
        if (currentKey.startsWith("Malaysia_")) {
            malaysiaLabel = "🇲🇾 Malaysia: " + getStateDisplayName(currentKey) + " (Tukar Negeri ▶)";
        } else if ("Malaysia".equalsIgnoreCase(currentKey)) {
            malaysiaLabel = "🇲🇾 Malaysia: Semua Negeri (Tukar Negeri ▶)";
        } else {
            malaysiaLabel = "🇲🇾 Malaysia / Mengikut Negeri (Pilih Negeri ▶)";
        }
        catList.add(malaysiaLabel);
        keyList.add("MALAYSIA_PICKER");

        catList.add("🏙️ Skyscraper / Pencakar Langit & Bandar");
        keyList.add("Skyscraper");

        catList.add("🌌 Deep Space / Angkasa & Kosmos");
        keyList.add("Space");

        catList.add("🌊 Ocean & Coastal / Lautan & Pantai");
        keyList.add("Ocean");

        catList.add("🔲 Minimalist Dark / Minimalis Gelap");
        keyList.add("Minimalist");

        if (hasCustom) {
            boolean isSingle = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getBoolean("custom_single_mode", false);
            String customLabel = isSingle
                    ? "📱 Custom / 1 Gambar Kekal (" + customFiles.length + " foto)"
                    : "📱 Custom / Putar Semua Gambar (" + customFiles.length + " foto)";
            catList.add(customLabel);
            keyList.add("Custom");

            catList.add("🗑️ Urus Gambar Dimuat Naik (Pilih / Padam)");
            keyList.add("MANAGE_CUSTOM");
        }

        catList.add("📲 Upload Wallpaper via Phone (QR Code)");
        keyList.add("UPLOAD_QR");

        catList.add("🔀 Tukar Gambar Seterusnya (Next)");
        keyList.add("NEXT");

        final String[] categories = catList.toArray(new String[0]);
        final String[] keys = keyList.toArray(new String[0]);

        int selectedIndex = 0;
        for (int i = 0; i < keys.length; i++) {
            if (keys[i].equalsIgnoreCase(currentKey) || ("MALAYSIA_PICKER".equals(keys[i]) && currentKey.startsWith("Malaysia"))) {
                selectedIndex = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("🖼️ Pilih Koleksi Wallpaper");
        builder.setSingleChoiceItems(categories, selectedIndex, (dialog, which) -> {
            dialog.dismiss();
            String chosenKey = keys[which];
            if ("NEXT".equals(chosenKey)) {
                if (wallpapers != null && !wallpapers.isEmpty()) {
                    showNextWallpaper(true);
                    Toast.makeText(MainActivity.this, "Menukar ke gambar seterusnya...", Toast.LENGTH_SHORT).show();
                }
            } else if ("MALAYSIA_PICKER".equals(chosenKey)) {
                showMalaysiaStateSelectorDialog();
            } else if ("UPLOAD_QR".equals(chosenKey)) {
                showWallpaperUploadQrDialog();
            } else if ("MANAGE_CUSTOM".equals(chosenKey)) {
                showCustomWallpaperManagerDialog();
            } else {
                switchWallpaperCategory(chosenKey);
            }
        });
        builder.setNegativeButton("Tutup / Cancel", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private String getStateDisplayName(String key) {
        if (key == null) return "Semua Negeri";
        if (key.equalsIgnoreCase("Malaysia_Johor")) return "Johor";
        if (key.equalsIgnoreCase("Malaysia_Kedah")) return "Kedah";
        if (key.equalsIgnoreCase("Malaysia_Kelantan")) return "Kelantan";
        if (key.equalsIgnoreCase("Malaysia_Melaka")) return "Melaka";
        if (key.equalsIgnoreCase("Malaysia_NegeriSembilan")) return "Negeri Sembilan";
        if (key.equalsIgnoreCase("Malaysia_Pahang")) return "Pahang";
        if (key.equalsIgnoreCase("Malaysia_Perak")) return "Perak";
        if (key.equalsIgnoreCase("Malaysia_Perlis")) return "Perlis";
        if (key.equalsIgnoreCase("Malaysia_PulauPinang")) return "Pulau Pinang";
        if (key.equalsIgnoreCase("Malaysia_Sabah")) return "Sabah";
        if (key.equalsIgnoreCase("Malaysia_Sarawak")) return "Sarawak";
        if (key.equalsIgnoreCase("Malaysia_Selangor")) return "Selangor";
        if (key.equalsIgnoreCase("Malaysia_Terengganu")) return "Terengganu";
        if (key.equalsIgnoreCase("Malaysia_WP")) return "Wilayah Persekutuan";
        return "Semua Negeri";
    }

    private void showMalaysiaStateSelectorDialog() {
        final String[] stateLabels = new String[]{
                "🇲🇾 Semua Negeri di Malaysia (Putar Keseluruhan)",
                "📍 Johor — Pulau Rawa & Pesisir Pantai",
                "📍 Kedah — Langkawi Sky Bridge & Sawah Padi",
                "📍 Kelantan — Pantai Cahaya Bulan & Senok",
                "📍 Melaka — Bandaraya Bersejarah & Sungai Melaka",
                "📍 Negeri Sembilan — Pantai Port Dickson & Teluk Kemang",
                "📍 Pahang — Ladang Teh Cameron Highlands",
                "📍 Perak — Pekan Warisan Ipoh & Kellie's Castle",
                "📍 Perlis — Gua Kelam & Banjaran Nakawan",
                "📍 Pulau Pinang — Georgetown UNESCO & Kek Lok Si",
                "📍 Sabah — Puncak Gunung Kinabalu",
                "📍 Sarawak — Pinnacles Mulu & Kuching Waterfront",
                "📍 Selangor — Batu Caves & Masjid Negeri Shah Alam",
                "📍 Terengganu — Pulau Perhentian & Masjid Kristal",
                "📍 Wilayah Persekutuan — Menara Berkembar KLCC"
        };

        final String[] stateKeys = new String[]{
                "Malaysia",
                "Malaysia_Johor",
                "Malaysia_Kedah",
                "Malaysia_Kelantan",
                "Malaysia_Melaka",
                "Malaysia_NegeriSembilan",
                "Malaysia_Pahang",
                "Malaysia_Perak",
                "Malaysia_Perlis",
                "Malaysia_PulauPinang",
                "Malaysia_Sabah",
                "Malaysia_Sarawak",
                "Malaysia_Selangor",
                "Malaysia_Terengganu",
                "Malaysia_WP"
        };

        String currentCat = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");
        int selectedIndex = 0;
        for (int i = 0; i < stateKeys.length; i++) {
            if (stateKeys[i].equalsIgnoreCase(currentCat)) {
                selectedIndex = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("🇲🇾 Koleksi Malaysia — Pilih Negeri");
        builder.setSingleChoiceItems(stateLabels, selectedIndex, (dialog, which) -> {
            dialog.dismiss();
            String chosenKey = stateKeys[which];
            switchWallpaperCategory(chosenKey);
        });
        builder.setNegativeButton("Kembali / Back", (dialog, which) -> {
            dialog.dismiss();
            showWallpaperDialog();
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void switchWallpaperCategory(String category) {
        getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit().putString("active_category", category).apply();
        String displayLabel = category.startsWith("Malaysia_") ? ("Malaysia (" + getStateDisplayName(category) + ")") : category;
        Toast.makeText(this, "Kategori: " + displayLabel, Toast.LENGTH_SHORT).show();

        if ("Natural".equalsIgnoreCase(category)) {
            placesMode = true;
            List<File> places = PlaceWallpapers.list(this);
            if (!places.isEmpty()) {
                wallpapers = places;
                showNextWallpaper(true);
                return;
            }
        } else if ("Custom".equalsIgnoreCase(category)) {
            placesMode = false;
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }
            File customDir = new File(getFilesDir(), "custom_wallpapers");
            File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
            boolean singleMode = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getBoolean("custom_single_mode", false);
            String singleFile = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("custom_single_file", null);
            if (singleMode && singleFile != null) {
                File sf = new File(customDir, singleFile);
                if (sf.exists() && sf.length() > 0) {
                    wallpapers = Collections.singletonList(sf);
                    getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
                    showNextWallpaper(true);
                    return;
                }
            }
            if (files != null && files.length > 0) {
                Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                wallpapers = new ArrayList<>(Arrays.asList(files));
                getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
                showNextWallpaper(true);
                return;
            }
        } else {
            placesMode = false;
            if (heroShelf != null) {
                heroShelf.setVisibility(View.VISIBLE);
            }
        }

        List<File> matching = OnlineWallpapers.listByCategory(this, category);
        if (!matching.isEmpty()) {
            wallpapers = matching;
            showNextWallpaper(true);
        } else {
            Toast.makeText(this, "Memuat turun 4K Wallpaper " + displayLabel + "...", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                boolean downloaded = OnlineWallpapers.syncCategory(getApplicationContext(), category);
                handler.post(() -> {
                    if (isDestroyed()) return;
                    List<File> fresh = OnlineWallpapers.listByCategory(MainActivity.this, category);
                    if (!fresh.isEmpty()) {
                        wallpapers = fresh;
                        showNextWallpaper(true);
                    }
                });
            }, "wall-cat-sync").start();
        }
    }

    private void showWallpaperUploadQrDialog() {
        if (uploadServer != null) {
            uploadServer.stop();
            uploadServer = null;
        }

        String localIp = WallpaperUploadServer.getLocalIpAddress();
        int port = 8080;
        WallpaperUploadServer.UploadListener listener = createUploadListener();
        uploadServer = new WallpaperUploadServer(this, port, listener);
        boolean started = uploadServer.start();
        if (!started) {
            port = 8888;
            uploadServer = new WallpaperUploadServer(this, port, listener);
            started = uploadServer.start();
        }

        if (!started) {
            Toast.makeText(this, "Ralat: Tidak dapat memulakan pelayan muat naik tempatan.", Toast.LENGTH_LONG).show();
            return;
        }

        String uploadUrl = "http://" + localIp + ":" + port;
        Bitmap qrBmp = QrBitmapUtil.createQrBitmap(uploadUrl, Math.round(260 * density));
        qrCodeBitmap = qrBmp;
        qrUploadUrl = uploadUrl;

        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        int padH = Math.round(36 * density);
        int padV = Math.round(28 * density);
        rootLayout.setPadding(padH, padV, padH, padV);
        rootLayout.setBackgroundColor(0xF0131722); // Elegant dark slate

        // Title
        TextView title = new TextView(this);
        title.setText("📲 Muat Naik Wallpaper Dari Telefon");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        rootLayout.addView(title);

        // Subtitle instructions
        TextView sub = new TextView(this);
        sub.setText("Sambungkan telefon pada Wi-Fi yang sama, kemudian imbas kod QR di bawah:");
        sub.setTextColor(0xFF94A3B8);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Math.round(6 * density), 0, Math.round(18 * density));
        rootLayout.addView(sub);

        // QR Code Container (Crisp White Card with subtle margin)
        FrameLayout qrContainer = new FrameLayout(this);
        qrContainer.setBackgroundColor(0xFFFFFFFF);
        int qrPad = Math.round(12 * density);
        qrContainer.setPadding(qrPad, qrPad, qrPad, qrPad);
        LinearLayout.LayoutParams qrLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        qrLp.gravity = Gravity.CENTER_HORIZONTAL;
        qrContainer.setLayoutParams(qrLp);

        qrImageView = new ImageView(this);
        if (qrBmp != null) {
            qrImageView.setImageBitmap(qrBmp);
        }
        int qrDim = Math.round(220 * density);
        FrameLayout.LayoutParams imgLp = new FrameLayout.LayoutParams(qrDim, qrDim);
        imgLp.gravity = Gravity.CENTER;
        qrImageView.setLayoutParams(imgLp);
        qrContainer.addView(qrImageView);
        rootLayout.addView(qrContainer);

        // Web URL pill
        qrUrlText = new TextView(this);
        qrUrlText.setText("🌐 " + uploadUrl);
        qrUrlText.setTextColor(0xFF38BDF8);
        qrUrlText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        qrUrlText.setTypeface(Typeface.DEFAULT_BOLD);
        qrUrlText.setGravity(Gravity.CENTER);
        qrUrlText.setPadding(0, Math.round(14 * density), 0, Math.round(4 * density));
        rootLayout.addView(qrUrlText);

        // Status text
        qrStatusText = new TextView(this);
        qrStatusText.setText("📡 Menunggu imbasan kamera atau fail dari telefon...");
        qrStatusText.setTextColor(0xFFCBD5E1);
        qrStatusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        qrStatusText.setGravity(Gravity.CENTER);
        qrStatusText.setPadding(0, 0, 0, Math.round(18 * density));
        rootLayout.addView(qrStatusText);

        // Close button
        Button btnClose = new Button(this);
        btnClose.setText("Tutup / Cancel");
        btnClose.setTextColor(0xFFFFFFFF);
        btnClose.setBackgroundResource(R.drawable.pill_bg);
        btnClose.setFocusable(true);
        btnClose.setFocusableInTouchMode(true);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                Math.round(180 * density), Math.round(42 * density));
        btnLp.gravity = Gravity.CENTER_HORIZONTAL;
        btnClose.setLayoutParams(btnLp);
        rootLayout.addView(btnClose);

        // Watermark credit
        TextView credit = new TextView(this);
        credit.setText("✨ Powered by MFR");
        credit.setTextColor(0xFF94A3B8);
        credit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        credit.setTypeface(Typeface.DEFAULT_BOLD);
        credit.setGravity(Gravity.CENTER);
        credit.setPadding(0, Math.round(14 * density), 0, 0);
        rootLayout.addView(credit);

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setView(rootLayout);
        qrUploadDialog = builder.create();

        btnClose.setOnClickListener(v -> qrUploadDialog.dismiss());

        qrUploadDialog.setOnDismissListener(dialog -> {
            if (uploadServer != null) {
                uploadServer.stop();
                uploadServer = null;
            }
            qrUploadDialog = null;
        });

        qrUploadDialog.show();
        btnClose.requestFocus();
    }

    private WallpaperUploadServer.UploadListener createUploadListener() {
        return new WallpaperUploadServer.UploadListener() {
            @Override
            public void onUploaded(File imageFile) {
                onCustomWallpaperUploaded(imageFile);
            }

            @Override
            public void onVideoUploaded(File videoFile) {
                runOnUiThread(() -> {
                    getSharedPreferences("launcher_settings", MODE_PRIVATE).edit()
                            .putString("video_wallpaper_uri", Uri.fromFile(videoFile).toString())
                            .putBoolean("video_wallpaper_enabled", true).apply();
                    if (videoWallpaperView != null) videoWallpaperView.stopPlayback();
                    startVideoWallpaperFromPrefs();
                    Toast.makeText(MainActivity.this,
                            "Video wallpaper dari telefon berjaya dipasang", Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onDeleted(File file) {
                onCustomWallpaperDeleted(file);
            }

            @Override
            public void onSelected(File file) {
                onCustomWallpaperSelected(file);
            }

            @Override
            public void onSlideshowMode() {
                onCustomWallpaperSlideshow();
            }

            @Override
            public void onRestored() {
                // Settings came from a backup: rebuild Home so every layout, widget and order takes effect.
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Setting dipulihkan dari backup", Toast.LENGTH_LONG).show();
                    recreate();
                });
            }

            @Override
            public void onCleared() {
                onCustomWallpaperCleared();
            }
        };
    }

    private void onCustomWallpaperUploaded(File file) {
        runOnUiThread(() -> {
            SoundEffects.playSelect();
            Toast.makeText(this, "✅ Wallpaper berjaya dimuat naik dari telefon!", Toast.LENGTH_LONG).show();

            getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit()
                    .putString("active_category", "Custom")
                    .putBoolean("custom_single_mode", false)
                    .remove("custom_single_file")
                    .apply();

            placesMode = false;
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }
            File customDir = new File(getFilesDir(), "custom_wallpapers");
            File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
            if (files != null && files.length > 0) {
                Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                wallpapers = new ArrayList<>(Arrays.asList(files));
            } else {
                wallpapers = Collections.singletonList(file);
            }

            getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
            showNextWallpaper(true);

            if (qrStatusText != null) {
                qrStatusText.setText("🎉 Berjaya Diterima & Dipaparkan di TV!");
                qrStatusText.setTextColor(0xFF4ADE80);
            }
            if (qrUrlText != null) {
                qrUrlText.setText("✅ Wallpaper Aktif: " + file.getName());
                qrUrlText.setTextColor(0xFF4ADE80);
            }
            if (qrImageView != null) {
                try {
                    Bitmap thumb = decodeWallpaper(file);
                    if (thumb != null) {
                        qrImageView.setImageBitmap(thumb);
                        qrImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    }
                } catch (Exception ignored) {}
            }

            // Keep the QR window (and the upload server behind it) open so the phone page stays alive and
            // more pictures can follow. After a few seconds the status goes back to "ready".
            handler.postDelayed(() -> {
                if (qrUploadDialog != null && qrUploadDialog.isShowing()) {
                    if (qrStatusText != null) {
                        qrStatusText.setText("📡 Sedia untuk gambar seterusnya. Tekan Tutup bila selesai.");
                        qrStatusText.setTextColor(0xFFCBD5E1);
                    }
                    // Put the QR code and address back, so the next picture can be sent straight away.
                    if (qrImageView != null && qrCodeBitmap != null) {
                        qrImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        qrImageView.setImageBitmap(qrCodeBitmap);
                    }
                    if (qrUrlText != null && qrUploadUrl != null) {
                        qrUrlText.setText("🌐 " + qrUploadUrl);
                        qrUrlText.setTextColor(0xFF38BDF8);
                    }
                }
            }, 4000);
        });
    }

    private void onCustomWallpaperSelected(File file) {
        runOnUiThread(() -> {
            SoundEffects.playSelect();
            getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit()
                    .putString("active_category", "Custom")
                    .putBoolean("custom_single_mode", true)
                    .putString("custom_single_file", file.getName())
                    .apply();

            placesMode = false;
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }
            wallpapers = Collections.singletonList(file);
            getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
            showNextWallpaper(true);
            Toast.makeText(this, "📌 Kunci 1 Wallpaper: " + file.getName(), Toast.LENGTH_SHORT).show();
        });
    }

    private void onCustomWallpaperSlideshow() {
        runOnUiThread(() -> {
            SoundEffects.playSelect();
            getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit()
                    .putString("active_category", "Custom")
                    .putBoolean("custom_single_mode", false)
                    .remove("custom_single_file")
                    .apply();

            placesMode = false;
            if (heroShelf != null) {
                heroShelf.animate().cancel();
                heroShelf.setAlpha(0f);
                heroShelf.setVisibility(View.GONE);
            }

            File customDir = new File(getFilesDir(), "custom_wallpapers");
            File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
            if (files != null && files.length > 0) {
                Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                wallpapers = new ArrayList<>(Arrays.asList(files));
                getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
                showNextWallpaper(true);
                Toast.makeText(this, "🔄 Mod Putar Semua Wallpaper Aktif (" + files.length + " foto)", Toast.LENGTH_SHORT).show();
            } else {
                switchWallpaperCategory("Natural");
            }
        });
    }

    private void onCustomWallpaperDeleted(File file) {
        runOnUiThread(() -> {
            String singleFile = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("custom_single_file", null);
            if (singleFile != null && singleFile.equals(file.getName())) {
                getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit()
                        .putBoolean("custom_single_mode", false)
                        .remove("custom_single_file")
                        .apply();
            }

            File customDir = new File(getFilesDir(), "custom_wallpapers");
            File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
            String activeCat = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");

            if ("Custom".equalsIgnoreCase(activeCat)) {
                if (files != null && files.length > 0) {
                    Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                    wallpapers = new ArrayList<>(Arrays.asList(files));
                    getSharedPreferences("wallpaper", MODE_PRIVATE).edit().putInt("index", -1).apply();
                    showNextWallpaper(true);
                    Toast.makeText(this, "🗑️ Gambar dipadam. Tinggal " + files.length + " foto.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Semua gambar telah dipadam. Beralih ke Natural.", Toast.LENGTH_SHORT).show();
                    switchWallpaperCategory("Natural");
                }
            } else {
                Toast.makeText(this, "🗑️ Gambar dipadam dari simpanan.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onCustomWallpaperCleared() {
        runOnUiThread(() -> {
            getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).edit()
                    .putBoolean("custom_single_mode", false)
                    .remove("custom_single_file")
                    .apply();

            String activeCat = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("active_category", "Natural");
            if ("Custom".equalsIgnoreCase(activeCat)) {
                switchWallpaperCategory("Natural");
            }
            Toast.makeText(this, "🧹 Semua gambar muat naik telah dibersihkan.", Toast.LENGTH_SHORT).show();
        });
    }

    private void showCustomWallpaperManagerDialog() {
        File customDir = new File(getFilesDir(), "custom_wallpapers");
        File[] files = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
        if (files == null || files.length == 0) {
            Toast.makeText(this, "Tiada gambar dimuat naik dijumpai.", Toast.LENGTH_SHORT).show();
            return;
        }

        Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        boolean isSingleMode = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getBoolean("custom_single_mode", false);
        String singleFile = getSharedPreferences("wallpaper_prefs", MODE_PRIVATE).getString("custom_single_file", "");

        List<String> items = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();

        // Quick Mode Actions at top
        items.add("🔄 Putar Semua Gambar (Slideshow Mod)");
        actions.add(this::onCustomWallpaperSlideshow);

        items.add("🗑️ Padam Semua Gambar (Kosongkan)");
        actions.add(() -> {
            new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("⚠️ Padam Semua Gambar?")
                    .setMessage("Adakah anda pasti ingin memadam semua " + files.length + " gambar yang dimuat naik?")
                    .setPositiveButton("Ya, Padam Semua", (d, w) -> {
                        for (File f : files) f.delete();
                        onCustomWallpaperCleared();
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        });

        SimpleDateFormat sdf = new SimpleDateFormat("d MMM, HH:mm", Locale.getDefault());
        for (File f : files) {
            double kb = f.length() / 1024.0;
            String sizeStr = kb > 1024 ? String.format(Locale.ROOT, "%.1f MB", kb / 1024.0) : String.format(Locale.ROOT, "%.0f KB", kb);
            boolean isCurrent = isSingleMode && f.getName().equals(singleFile);
            String prefix = isCurrent ? "📌 [Kekal] " : "🖼️ ";
            items.add(prefix + f.getName() + " (" + sizeStr + " • " + sdf.format(new Date(f.lastModified())) + ")");
            actions.add(() -> showSingleCustomActionDialog(f));
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("📱 Pengurus Gambar TV (" + files.length + " Foto)");
        builder.setItems(items.toArray(new String[0]), (dialog, which) -> {
            if (which >= 0 && which < actions.size()) {
                actions.get(which).run();
            }
        });
        builder.setNegativeButton("Tutup", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void showSingleCustomActionDialog(File file) {
        String[] actions = {
                "📌 Jadikan Wallpaper Tunggal (Kunci Gambar Ini)",
                "🗑️ Padam Gambar Ini",
                "🧹 Simpan Gambar Ini Sahaja & Padam Yang Lain",
                "⬅️ Kembali"
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("🖼️ " + file.getName());
        builder.setItems(actions, (dialog, which) -> {
            switch (which) {
                case 0: // Lock single
                    onCustomWallpaperSelected(file);
                    break;
                case 1: // Delete this
                    file.delete();
                    onCustomWallpaperDeleted(file);
                    break;
                case 2: // Keep this, delete others
                    File customDir = new File(getFilesDir(), "custom_wallpapers");
                    File[] allFiles = customDir.listFiles((dir, name) -> name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".jpeg"));
                    if (allFiles != null) {
                        for (File f : allFiles) {
                            if (!f.getName().equals(file.getName())) {
                                f.delete();
                            }
                        }
                    }
                    onCustomWallpaperSelected(file);
                    Toast.makeText(this, "🧹 Gambar lain dipadam. Gambar ini dikekalkan.", Toast.LENGTH_SHORT).show();
                    break;
                case 3: // Back
                    showCustomWallpaperManagerDialog();
                    break;
            }
        });
        builder.setNegativeButton("Batal", null);
        builder.show();
    }

    private void showHazeLocationDialog() {
        final List<AppLocationManager.Station> stations = AppLocationManager.getPresetStations();
        String currentId = AppLocationManager.getStationId(this);
        int selectedIndex = 0;
        CharSequence[] items = new CharSequence[stations.size()];
        for (int i = 0; i < stations.size(); i++) {
            AppLocationManager.Station s = stations.get(i);
            items[i] = s.getDisplayName() + "\n" + s.place;
            if (s.id.equalsIgnoreCase(currentId)) {
                selectedIndex = i;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("📍 Pilih Stesen Jerebu JAS / APIMS");
        builder.setSingleChoiceItems(items, selectedIndex, (dialog, which) -> {
            AppLocationManager.Station chosen = stations.get(which);
            AppLocationManager.setStation(MainActivity.this, chosen);
            dialog.dismiss();
            Toast.makeText(MainActivity.this, "Stesen Jerebu: " + chosen.name, Toast.LENGTH_SHORT).show();
            refreshLocationDependentData();
        });
        builder.setNegativeButton("Tutup / Cancel", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void showPrayerZoneDialog() {
        final List<PrayerTimes.PrayerZone> zones = PrayerTimes.getPresetZones();
        String activeZone = PrayerTimes.getActiveZone(this);
        int selectedIndex = 0;
        CharSequence[] items = new CharSequence[zones.size()];
        for (int i = 0; i < zones.size(); i++) {
            PrayerTimes.PrayerZone z = zones.get(i);
            items[i] = z.getDisplayName();
            if (z.code.equalsIgnoreCase(activeZone)) {
                selectedIndex = i;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
        builder.setTitle("🕌 Pilih Zon Waktu Solat JAKIM");
        builder.setSingleChoiceItems(items, selectedIndex, (dialog, which) -> {
            PrayerTimes.PrayerZone chosen = zones.get(which);
            PrayerTimes.setPrayerZone(MainActivity.this, chosen);
            dialog.dismiss();
            Toast.makeText(MainActivity.this, "Zon Solat: " + chosen.name, Toast.LENGTH_SHORT).show();
            refreshLocationDependentData();
        });
        builder.setNegativeButton("Tutup / Cancel", (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /** Shows an Apple TV-style frosted glass Putrajaya prayer timetable popup. */
    private void showPrayerPopup() {
        if (openMenu != null) return;
        SoundEffects.playSelect();
        View anchor = prayerTimesView != null ? prayerTimesView : findViewById(R.id.leftBlock);
        FrameLayout panel = (FrameLayout) getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        Runnable close = () -> closeMenu(false);

        // Header: Active Prayer Zone
        addInputRow(rows, close, R.drawable.ic_settings, "Waktu Solat " + PrayerTimes.getShortZoneName(this), TvInputManager.INPUT_STATE_CONNECTED, () -> {});

        // Date row: Islamic Hijri
        addInputRow(rows, close, R.drawable.ic_input, PrayerTimes.getHijriDate(), -1, () -> {});

        addSeparator(rows);

        // Prayer times list
        java.util.List<PrayerTimes.ScheduleItem> schedule = PrayerTimes.getFullSchedule(this);
        for (PrayerTimes.ScheduleItem item : schedule) {
            addPrayerRow(rows, close, item.name, item.timeFormatted, item.isNext);
        }

        addSeparator(rows);

        // Tutup
        addInputRow(rows, close, R.drawable.ic_move, "Tutup", -1, () -> {
            SoundEffects.playSelect();
            closeMenu(true);
        });

        int width = (int) (270 * density);
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        width = Math.max(width, panel.getMeasuredWidth());

        showMenu(panel, rows, anchor, width, false);
    }

    private void addPrayerRow(LinearLayout rows, Runnable close, String name, String time, boolean isNext) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(R.drawable.ic_input);
        TextView title = row.findViewById(R.id.title);
        title.setText(name + (isNext ? " (Seterusnya)" : ""));
        TextView status = row.findViewById(R.id.status);
        View dot = row.findViewById(R.id.dot);
        status.setText(time);
        status.setVisibility(View.VISIBLE);
        if (isNext) {
            dot.setVisibility(View.VISIBLE);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            status.setTypeface(null, android.graphics.Typeface.BOLD);
        } else {
            dot.setVisibility(View.GONE);
        }
        row.setOnClickListener(v -> {
            SoundEffects.playSelect();
            close.run();
        });
        rows.addView(row);
    }

    private void checkInactivity() {
        if (!hasWindowFocus() || isFinishing() || isDestroyed()) return;
        long idleMs = android.os.SystemClock.elapsedRealtime() - lastUserInteraction;
        if (idleMs >= TV_SLEEP_TIMEOUT_MS) {
            turnOffTv();
        } else if (idleMs >= SCREENSAVER_TIMEOUT_MS && !screensaverActive) {
            showNightstandScreensaver();
        } else if (screensaverActive && screensaverView != null) {
            updateNightstandScreensaver();
        }
    }

    private void showNightstandScreensaver() {
        if (screensaverActive || isFinishing() || isDestroyed()) return;
        lastHomeBackAt = -1L;
        focusBeforeScreensaver = getCurrentFocus();
        widgetBeforeScreensaver = focusBeforeScreensaver == null ? -1 : ChombbWidgets.kindOf(focusBeforeScreensaver);
        screensaverActive = true;
        if (chombbWidgetShelf != null) chombbWidgetShelf.setVisibility(View.GONE);
        handler.removeCallbacks(chombbWidgetRefresh);
        handler.removeCallbacks(lyricWidgetRefresh);
        if (screensaverView == null) {
            screensaverView = new StandbyView(this);
            screensaverView.setOnClickListener(v -> dismissScreensaver());
            screensaverView.setElevation(1100f * density);
            root.addView(screensaverView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        screensaverView.setVisibility(View.VISIBLE);
        screensaverView.requestFocus();
        ((StandbyView) screensaverView).onShow();
        updateNightstandScreensaver();
        screensaverView.setAlpha(0f);
        screensaverView.animate().alpha(1f).setDuration(500).start();
        android.util.Log.i("TvHome", "Nightstand screensaver activated");
    }

    private void updateNightstandScreensaver() {
        if (screensaverView == null || screensaverView instanceof StandbyView) return;   // StandbyView updates itself
        TextView hijri = screensaverView.findViewById(R.id.nightstandHijri);
        if (hijri != null) hijri.setText("🌙 " + PrayerTimes.getHijriDate());

        TextView prayer = screensaverView.findViewById(R.id.nightstandPrayer);
        if (prayer != null) prayer.setText("🕌 " + PrayerTimes.getNextPrayerSummary(this));

        // Center locked strictly with no movement
        View content = screensaverView.findViewById(R.id.nightstandContent);
        if (content != null) {
            content.animate().cancel();
            content.setTranslationX(0f);
            content.setTranslationY(0f);
        }

        // iPhone StandBy Wind Down Mode: 10:00 PM (22:00) to 6:00 AM (06:00) -> Red Monochrome
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int hour = cal.get(java.util.Calendar.HOUR_OF_DAY);
        boolean isNightMode = (hour >= 22 || hour < 6);

        TextView clock = screensaverView.findViewById(R.id.nightstandClock);
        TextView ampm = screensaverView.findViewById(R.id.nightstandAmPm);
        TextView date = screensaverView.findViewById(R.id.nightstandDate);
        TextView hint = screensaverView.findViewById(R.id.nightstandHint);

        if (isNightMode) {
            int red = 0xFFFF453A;
            if (clock != null) clock.setTextColor(red);
            if (ampm != null) ampm.setTextColor(0xCCFF453A);
            if (date != null) date.setTextColor(0xE6FF453A);
            if (hijri != null) hijri.setTextColor(0xE6FF453A);
            if (prayer != null) {
                prayer.setTextColor(red);
                android.graphics.drawable.GradientDrawable redPill = new android.graphics.drawable.GradientDrawable();
                redPill.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
                redPill.setColor(0x26FF453A);
                redPill.setStroke((int) (1 * density), 0x59FF453A);
                redPill.setCornerRadius(21 * density);
                prayer.setBackground(redPill);
            }
            if (hint != null) hint.setTextColor(0x55FF453A);
        } else {
            if (clock != null) clock.setTextColor(0xFFFFFFFF);
            if (ampm != null) ampm.setTextColor(0xB3FFFFFF);
            if (date != null) date.setTextColor(0xE6FFFFFF);
            if (hijri != null) hijri.setTextColor(0xD9E6E0D2);
            if (prayer != null) {
                prayer.setTextColor(0xFFFFFFFF);
                prayer.setBackgroundResource(R.drawable.pill_bg);
            }
            if (hint != null) hint.setTextColor(0x4DFFFFFF);
        }
    }

    private void dismissScreensaver() {
        if (!screensaverActive || screensaverView == null) return;
        screensaverActive = false;
        lastUserInteraction = android.os.SystemClock.elapsedRealtime();
        refreshChombbWidgetShelf();
        View previous = focusBeforeScreensaver;
        focusBeforeScreensaver = null;
        boolean restored = previous != null && previous.isShown() && previous.requestFocus();
        if (!restored && widgetBeforeScreensaver >= 0) {
            for (View card : widgetCards) {
                if (ChombbWidgets.kindOf(card) == widgetBeforeScreensaver && card.requestFocus()) {
                    restored = true;
                    break;
                }
            }
        }
        widgetBeforeScreensaver = -1;
        if (!restored) focusHomeApps();
        screensaverView.animate().alpha(0f).setDuration(350).withEndAction(() -> {
            if (!screensaverActive && screensaverView != null) {
                screensaverView.setVisibility(View.GONE);
                if (screensaverView instanceof StandbyView) ((StandbyView) screensaverView).onHide();
            }
        }).start();
        android.util.Log.i("TvHome", "Nightstand screensaver dismissed");
    }

    private void turnOffTv() {
        android.util.Log.i("TvHome", "TV idle: 10m screensaver + 2h timeout reached, putting TV to sleep");
        boolean ok = HomeKeyService.sleepScreen();
        if (!ok) {
            try {
                Runtime.getRuntime().exec("input keyevent 223");
            } catch (Exception e) {
                android.util.Log.w("TvHome", "Failed to send sleep keyevent: " + e);
            }
        }
    }

    private void ensureSystemScreensaverAndSleepSettings() {
        new Thread(() -> {
            try {
                android.content.ContentResolver cr = getContentResolver();
                // 10 minutes idle -> screensaver (600,000 ms)
                android.provider.Settings.System.putInt(cr, "screen_off_timeout", 600000);
                // 2 hours after screensaver -> TV off (10m + 2h = 7,800,000 ms)
                android.provider.Settings.Secure.putInt(cr, "sleep_timeout", 7800000);
                android.provider.Settings.Secure.putInt(cr, "screensaver_enabled", 1);
                android.provider.Settings.Secure.putString(cr, "screensaver_components", new android.content.ComponentName(this, ClockDream.class).flattenToString());
            } catch (Exception ignored) {
            }
        }, "system-timeout-sync").start();
    }


    /**
     * China-market MIUI TV firmware answers no standard Settings intents at all; open Xiaomi's own
     * settings app (com.xiaomi.mitv.settings) there, so the Settings and Wi-Fi pills keep working.
     * On firmware with a standard settings handler the behaviour is unchanged.
     */
    private Intent systemIntent(String standardAction) {
        Intent i = new Intent(standardAction);
        if (i.resolveActivity(getPackageManager()) != null) return i;
        i = new Intent().setComponent(new ComponentName(
                "com.xiaomi.mitv.settings", "com.xiaomi.mitv.settings.entry.MainActivity"));
        if (i.resolveActivity(getPackageManager()) != null) return i;
        return new Intent(standardAction);   // nothing found: let open() show the can't-open toast
    }

    /** Hides the Inputs pill when it would have nothing to list: streaming boxes have no HDMI-in, AV or tuner. */
    private void updateInputsButton() {
        boolean any = liveTvIntent() != null || !sourcePanelService.isEmpty();
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        if (!any && tim != null) {
            for (TvInputInfo info : tim.getTvInputList()) {
                if (info.isPassthroughInput()) {
                    any = true;
                    break;
                }
            }
        }
        // Input pill removed by request: the TV's own source key already opens inputs.
        btnInputs.setVisibility(View.GONE);
    }

    /** The Live TV app's launch intent: its leanback entry point, or the configured action if it has none. */
    private Intent liveTvIntent() {
        if (liveTvPkg.isEmpty()) return null;
        Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(liveTvPkg);
        if (i != null || liveTvAction.isEmpty()) return i;
        Intent byAction = new Intent(liveTvAction).setPackage(liveTvPkg);
        return getPackageManager().resolveActivity(byAction, 0) != null ? byAction : null;
    }

    /** The TV's own source-selection panel, for TVs that have no TvInputManager (TCL Android TV 9). */
    private void openSourcePanel() {
        Intent i = new Intent(sourcePanelAction);
        ComponentName c = ComponentName.unflattenFromString(sourcePanelService);
        if (c != null) i.setComponent(c);
        try {
            startService(i);
        } catch (Exception e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    private void open(Intent i) {
        SoundEffects.playSelect();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    /** Switches to a passthrough input (HDMI, AV). The standard way is ACTION_VIEW on its channel URI,
     *  which the Live TV app handles; where nothing takes that, the configured `input_action` is sent
     *  with the same URI instead (XGIMI's HDMI player only answers com.xgimi.action.hdmiPlayer). */
    private void openInput(String inputId) {
        Uri uri = TvContract.buildChannelUriForPassthroughInput(inputId);
        Intent view = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "vnd.android.cursor.item/channel")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(view);
            return;
        } catch (ActivityNotFoundException e) {
            if (inputAction.isEmpty()) {
                Toast.makeText(this, R.string.not_available, Toast.LENGTH_SHORT).show();
                return;
            }
        }
        open(new Intent(inputAction).setDataAndType(uri, "vnd.android.cursor.item/channel"));
    }

    /** The glass menu while one is open (Inputs, or an app's), and what it opened from. */
    private View openMenu;
    private PanelMotion menuMotion;
    private View menuAnchor;
    private final int[] menuAt = new int[2], menuGliderAt = new int[2];

    /**
     * Menu under the Inputs pill: HDMI ports (with connection state), AV and Live TV. It is drawn in
     * Home's own window rather than a popup window of its own: a new window takes about a quarter of
     * a second to reach the screen on this TV, so the selection could not glide out of the pill into
     * it. Here Home's own focus shape glides from the pill to the first row, the way it glides into
     * the dock's tray, and the menu's glass paints it over itself.
     */
    private void showInputs() {
        if (openMenu != null) return;
        SoundEffects.playSelect();
        // Hero, Pill and Material hide the Classic Inputs button: hang the list from what has focus instead.
        View anchor = btnInputs != null && btnInputs.isShown() ? btnInputs
                : (getCurrentFocus() != null && getCurrentFocus().isShown() ? getCurrentFocus() : root);
        FrameLayout panel = (FrameLayout) getLayoutInflater().inflate(R.layout.popup_inputs, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        Runnable close = () -> closeMenu(false);

        // Compact: as wide as the Inputs pill (a touch wider so "HDMI 1" fits), hanging right below it.
        int width = Math.max(Math.min(anchor.getWidth(), (int) (260 * density)), (int) (150 * density));
        TvInputManager tim = (TvInputManager) getSystemService(TV_INPUT_SERVICE);
        boolean sawNonHdmi = false;
        String tunerId = null;
        boolean tunerIsHw = false;
        if (tim != null) {
            List<TvInputInfo> inputs = new ArrayList<>(tim.getTvInputList());
            // HDMI ports first in port order, then AV and the rest.
            Collections.sort(inputs, (a, b) -> {
                boolean ha = a.getType() == TvInputInfo.TYPE_HDMI, hb = b.getType() == TvInputInfo.TYPE_HDMI;
                if (ha != hb) return ha ? -1 : 1;
                return String.valueOf(a.loadLabel(this)).compareToIgnoreCase(String.valueOf(b.loadLabel(this)));
            });
            // Some TVs (Sony) report every HDMI port as connected whether or not anything is plugged in,
            // so drop the HDMI status then. A TV with every port really in use loses it too.
            int hdmiPorts = 0, hdmiConnected = 0;
            for (TvInputInfo info : inputs) {
                if (!info.isPassthroughInput() || info.getType() != TvInputInfo.TYPE_HDMI) continue;
                hdmiPorts++;
                if (tim.getInputState(info.getId()) == TvInputManager.INPUT_STATE_CONNECTED) hdmiConnected++;
            }
            boolean hdmiStateBogus = hdmiPorts > 1 && hdmiConnected == hdmiPorts;
            for (TvInputInfo info : inputs) {
                if (info.getType() == TvInputInfo.TYPE_TUNER
                        && (info.getServiceInfo().applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                    // Prefer a hardware tuner: the framework names those ".../HW<n>". System apps such as
                    // AirPlay also register software inputs of type TUNER and may sort first (seen on TCL G05).
                    boolean hw = info.getId().matches(".*/HW\\d+$");
                    if (tunerId == null || (hw && !tunerIsHw) || (hw == tunerIsHw && info.getId().compareTo(tunerId) < 0)) {
                        tunerId = info.getId();
                        tunerIsHw = hw;
                    }
                }
                if (!info.isPassthroughInput()) continue;
                CharSequence l = info.loadLabel(this);
                String label = l == null ? info.getId() : l.toString();
                boolean hdmi = info.getType() == TvInputInfo.TYPE_HDMI;
                if (hdmi && !label.toUpperCase(Locale.ROOT).contains("HDMI")) label = "HDMI " + label;
                final String id = info.getId();
                int state = hdmi && hdmiStateBogus ? -1 : tim.getInputState(id);
                if (!hdmi && rows.getChildCount() > 0 && !sawNonHdmi) addSeparator(rows);
                if (!hdmi) sawNonHdmi = true;
                addInputRow(rows, close, hdmi ? R.drawable.ic_hdmi : R.drawable.ic_av, label, state,
                        () -> openInput(id));
            }
        }
        // Nothing to list where there is no TvInputManager: the TV's own source panel switches inputs.
        if (rows.getChildCount() == 0 && !sourcePanelService.isEmpty()) {
            addInputRow(rows, close, R.drawable.ic_input, getString(R.string.inputs), -1, this::openSourcePanel);
        }
        Intent liveTv = liveTvIntent();
        if (liveTv != null && tunerId != null) {
            liveTv = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(TvContract.buildChannelUriForPassthroughInput(tunerId), "vnd.android.cursor.item/channel")
                    .setPackage(liveTvPkg);
        }
        if (liveTv != null && config.showLiveTv) {
            if (rows.getChildCount() > 0) addSeparator(rows);
            final Intent liveTvIntent = liveTv;
            addInputRow(rows, close, R.drawable.ic_livetv, getString(R.string.live_tv), -1, () -> open(liveTvIntent));
        }
        if (rows.getChildCount() == 0) {
            Toast.makeText(this, R.string.no_inputs, Toast.LENGTH_SHORT).show();
            return;
        }

        // Fit the widest row: TVs that report a status on every port (Sony) would otherwise squeeze the names out.
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        width = Math.max(width, panel.getMeasuredWidth());

        showMenu(panel, rows, anchor, width, false);
    }

    /**
     * Shows a glass menu in Home's own window, under {@code anchor} or, with {@code above}, over it:
     * Home's focus shape glides from the anchor to the first row, the menu's glass paints it over
     * itself, and the glass and rows fade in around it. Up from the first row (Down from the last when
     * the menu is above), or Back, closes it and the shape glides back to the anchor.
     */
    private void showMenu(FrameLayout panel, LinearLayout rows, View anchor, int width, boolean above) {
        GlassDrawable glass = new GlassDrawable(panel, 20 * density, density, glider, 0.5f, true);
        panel.setBackground(glass);
        Backdrop.watch(panel);
        glider.addCompanion(panel);
        anchor.getLocationInWindow(menuAt);
        root.getLocationInWindow(menuGliderAt);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Math.max(0, Math.min(menuAt[0] - menuGliderAt[0], root.getWidth() - width));
        int gap = (int) (10 * density);
        if (above) {
            panel.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED);
            lp.topMargin = Math.max(0, menuAt[1] - menuGliderAt[1] - gap - panel.getMeasuredHeight());
        } else {
            lp.topMargin = menuAt[1] - menuGliderAt[1] + anchor.getHeight() + gap;
        }
        root.addView(panel, lp);
        openMenu = panel;
        menuAnchor = anchor;

        // Focus stays in the menu until it closes. Leaving it towards the anchor closes it, and the
        // selection glides back into what it opened from.
        View first = null, last = null;
        for (int i = 0; i < rows.getChildCount(); i++) {
            View row = rows.getChildAt(i);
            if (!row.isFocusable()) continue;
            if (first == null) first = row;
            last = row;
            row.setOnFocusChangeListener((v, has) -> {
                if (has) glideToMenuRow(panel, rows, v);
            });
        }
        final View top = first, bottom = last;
        for (int i = 0; i < rows.getChildCount(); i++) {
            View row = rows.getChildAt(i);
            if (!row.isFocusable()) continue;
            row.setOnKeyListener((v, keyCode, event) -> {
                boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DPAD_UP:
                        if (v != top) return false;
                        if (down && !above) closeMenu(true);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_DOWN:
                        if (v != bottom) return false;
                        if (down && above) closeMenu(true);
                        return true;
                    case KeyEvent.KEYCODE_DPAD_LEFT:
                    case KeyEvent.KEYCODE_DPAD_RIGHT:
                        return true;
                    case KeyEvent.KEYCODE_BACK:
                        if (down) closeMenu(true);
                        return true;
                    default:
                        return false;
                }
            });
        }

        if (!reducedMotion) {
            menuMotion = new PanelMotion(panel, 0.90f);
            menuMotion.open();
        }
        if (top != null) top.requestFocus();
    }

    /**
     * Glides Home's focus shape onto a row of the Inputs menu. From layout positions, not on-screen
     * ones: the rows slide into place as the menu opens, and the shape must land where the row ends
     * up, not where it was when focus arrived. The first row takes focus before the menu has been
     * laid out, so then it waits for the layout.
     */
    private void glideToMenuRow(View panel, View rows, View row) {
        SoundEffects.playNav();
        if (!panel.isLaidOut() || row.getHeight() == 0) {
            panel.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    panel.removeOnLayoutChangeListener(this);
                    // Still inside the layout pass here, where the panel does not count as laid
                    // out yet: glide once the pass is over.
                    panel.post(() -> {
                        if (row.hasFocus()) glideToMenuRow(panel, rows, row);
                    });
                }
            });
            return;
        }
        float l = panel.getLeft() + rows.getLeft() + row.getLeft() - glider.getLeft();
        float t = panel.getTop() + rows.getTop() + row.getTop() - glider.getTop();
        gliderOnPill = true;
        glider.setStyle(Glider.DARK);
        glider.moveTo(l, t, l + row.getWidth(), t + row.getHeight(), 13 * density);
    }

    /** Closes the open menu; with {@code toAnchor}, focus and the selection go back to what it opened from. */
    private void closeMenu(boolean toAnchor) {
        View panel = openMenu;
        if (panel == null) return;
        SoundEffects.playNav();
        openMenu = null;
        if (toAnchor && menuAnchor != null) menuAnchor.requestFocus();
        menuAnchor = null;
        PanelMotion motion = menuMotion;
        menuMotion = null;
        Runnable remove = () -> {
            glider.removeCompanion(panel);
            root.removeView(panel);
        };
        if (motion != null) motion.close(remove);
        else remove.run();
    }

    private boolean inMenu(View v) {
        for (View p = v; p != null && openMenu != null; p = p.getParent() instanceof View ? (View) p.getParent() : null) {
            if (p == openMenu) return true;
        }
        return false;
    }

    private PopupWindow glassPopup(View panel, int width) {
        // The same glass as the pills and the tray: what is behind it, softened, with a shining edge.
        panel.setBackground(new GlassDrawable(panel, 20 * density, density, null, 0.5f));
        Backdrop.watch(panel);
        final PopupWindow popup = new PopupWindow(panel, width, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));   // needed for Back to dismiss
        popup.setOutsideTouchable(true);
        popup.setAnimationStyle(0);
        popup.setElevation(0f);
        popup.setOnDismissListener(() -> {
            if (openPopup == popup) openPopup = null;
        });
        openPopup = popup;
        return popup;
    }

    /** Drop in: fade and unfold from the top edge, hanging under the anchor pill. */
    private void dropIn(PopupWindow popup, View panel, View anchor, int gravity) {
        panel.setAlpha(0f);
        panel.setPivotY(0f);
        panel.setScaleY(0.92f);
        panel.setTranslationY(-8 * density);
        popup.showAsDropDown(anchor, 0, (int) (10 * density), gravity);
        panel.animate().alpha(1f).scaleY(1f).translationY(0f).setDuration(220)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
    }

    private void addSeparator(LinearLayout rows) {
        View line = new View(this);
        line.setBackgroundColor(0x1FFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) density);
        int m = (int) (6 * density), h = (int) (12 * density);
        lp.setMargins(h, m, h, m);
        rows.addView(line, lp);
    }

    private void addInputRow(LinearLayout rows, Runnable close, int iconRes, String title, int state, Runnable action) {
        View row = getLayoutInflater().inflate(R.layout.item_input, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(iconRes);
        ((TextView) row.findViewById(R.id.title)).setText(title);
        TextView status = row.findViewById(R.id.status);
        View dot = row.findViewById(R.id.dot);
        // This TV reports "standby" for every port whether or not something is plugged in, so only
        // definite states are shown.
        if (state == TvInputManager.INPUT_STATE_CONNECTED) {
            status.setText(R.string.connected);
            dot.setVisibility(View.VISIBLE);
        } else if (state == TvInputManager.INPUT_STATE_DISCONNECTED) {
            status.setText(R.string.not_connected);
            dot.setVisibility(View.GONE);
        } else {
            status.setVisibility(View.GONE);
            dot.setVisibility(View.GONE);
        }
        // TV remote: the inflated row must be focusable, not just clickable by mouse.
        row.setFocusable(true);
        row.setFocusableInTouchMode(true);
        row.setClickable(true);
        row.setOnClickListener(v -> {
            close.run();
            action.run();
        });
        rows.addView(row);
    }

    // ---- module cards ----------------------------------------------------------------------------

    /**
     * Asks about the next card that has no decision for its current signing key. One prompt at a
     * time, only over a laid out grid with window focus (not under a popup or another app), and
     * the next one follows as soon as this one is answered. Nothing is shown until the owner says Show.
     */
    private void showCardPrompt() {
        if (!moduleCards || !tilesReady || promptsPaused || cardPrompt != null || !hasWindowFocus() || isFinishing()) return;
        if (cards.isEmpty() || !CardFeature.working()) return;
        CardFeature.run(() -> {
            showCardPromptNow();
            return null;
        }, null);
    }

    private void showCardPromptNow() {
        final Cards.Card card = Cards.firstPending(cards);
        if (card == null) return;

        View panel = getLayoutInflater().inflate(R.layout.dialog_card_prompt, root, false);
        ((TextView) panel.findViewById(R.id.title)).setText(getString(R.string.card_prompt_title, card.appLabel));
        ((TextView) panel.findViewById(R.id.body)).setText(card.state == Cards.State.RESIGNED
                ? getString(R.string.card_prompt_resigned, card.appLabel)
                : card.state == Cards.State.RELABELLED
                ? getString(R.string.card_prompt_relabelled, card.appLabel)
                : getString(R.string.card_prompt_body, card.appLabel));
        TextView names = panel.findViewById(R.id.names);
        if (Cards.fold(card.label).equals(Cards.fold(card.appLabel))) names.setVisibility(View.GONE);
        else names.setText(getString(R.string.card_prompt_names, card.label, card.appLabel));
        ((TextView) panel.findViewById(R.id.identity)).setText(
                getString(R.string.card_prompt_identity, card.pkg, Cards.shortDigest(card.digest)));
        TextView keep = panel.findViewById(R.id.btnKeep);
        TextView show = panel.findViewById(R.id.btnShow);

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(panel);
        dialog.setCanceledOnTouchOutside(false);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout((int) (440 * density), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setDimAmount(0.6f);
        }
        // One decision per prompt: the buttons and Back (cancel) all end here.
        final boolean[] decided = {false};
        View.OnClickListener choose = v -> {
            if (decided[0]) return;
            decided[0] = true;
            cardPrompt = null;
            dialog.dismiss();
            decideCard(card, v.getId() == R.id.btnShow);   // guards its own card calls; the tile reload stays outside
            restoreFocus();   // the tiles changed under the prompt; this also chains the next prompt
        };
        keep.setOnClickListener(choose);
        show.setOnClickListener(choose);
        dialog.setOnCancelListener(d -> choose.onClick(keep));
        dialog.setOnDismissListener(d -> {
            if (cardPrompt == dialog) cardPrompt = null;
        });
        // Left and Right move between the two buttons; Up and Down stay put; the ends don't wrap.
        View.OnKeyListener keys = (v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) return true;
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) return v.getId() == R.id.btnKeep;
            return keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && v.getId() == R.id.btnShow;
        };
        keep.setOnKeyListener(keys);
        show.setOnKeyListener(keys);
        cardPrompt = dialog;
        dialog.show();
        keep.requestFocus();
    }

    /** Writes the owner's decision and rebuilds the tiles; focus is left where it is. */
    private void decideCard(Cards.Card card, boolean show) {
        boolean saved = CardFeature.run(() -> Cards.decide(Cards.storeFile(this), card, show), false);
        if (!saved) {
            Toast.makeText(this, R.string.card_not_saved, Toast.LENGTH_SHORT).show();
            promptsPaused = true;
        }
        reloadTiles();
    }

    /** Dropdown under the Settings pill (hold OK): every discovered card, its package and key; OK toggles Shown and Hidden. */
    private void showModuleCards() {
        if (cards.isEmpty() || !CardFeature.working()) {
            Toast.makeText(this, R.string.no_module_cards, Toast.LENGTH_SHORT).show();
            return;
        }
        CardFeature.run(() -> {
            showModuleCardsNow();
            return null;
        }, null);
    }

    private void showModuleCardsNow() {
        View anchor = findViewById(R.id.btnSettings);
        View panel = getLayoutInflater().inflate(R.layout.popup_cards, root, false);
        LinearLayout rows = panel.findViewById(R.id.rows);
        final PopupWindow popup = glassPopup(panel, (int) (400 * density));
        List<Cards.Card> listed = new ArrayList<>(cards);
        Collections.sort(listed, Cards::byLabel);
        for (Cards.Card card : listed) {
            View row = getLayoutInflater().inflate(R.layout.item_card_row, rows, false);
            row.setTag(card.pkg);
            ((TextView) row.findViewById(R.id.title)).setText(card.label);
            TextView app = row.findViewById(R.id.app);
            if (Cards.fold(card.label).equals(Cards.fold(card.appLabel))) app.setVisibility(View.GONE);
            else app.setText(getString(R.string.card_app_name, card.appLabel));
            ((TextView) row.findViewById(R.id.pkg)).setText(card.pkg);
            ((TextView) row.findViewById(R.id.digest)).setText(Cards.longDigest(card.digest));
            final String pkg = card.pkg;
            row.setOnClickListener(v -> CardFeature.run(() -> {
                // The list stays open; the decision is for the card as it is now, not as it was listed.
                Cards.Card now = cardFor(pkg);
                if (now == null) return null;
                decideCard(now, now.state != Cards.State.SHOWN);
                // Every row, not only this one: a toggle can move another card across the limit of 8.
                updateCardStates(rows);
                return null;
            }, null));
            rows.addView(row);
        }
        updateCardStates(rows);
        // Scroll inside the panel instead of running off the bottom of a 720p screen.
        panel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int[] at = new int[2];
        anchor.getLocationInWindow(at);
        int room = root.getHeight() - (at[1] + anchor.getHeight()) - (int) (34 * density);
        popup.setHeight(Math.min(panel.getMeasuredHeight(), Math.max(room, (int) (120 * density))));
        dropIn(popup, panel, anchor, Gravity.END);
        rows.getChildAt(0).requestFocus();
    }

    private Cards.Card cardFor(String pkg) {
        for (Cards.Card c : cards) if (c.pkg.equals(pkg)) return c;
        return null;
    }

    /** Writes the state of every row in the Module cards list from the current card list. */
    private void updateCardStates(LinearLayout rows) {
        List<Cards.Card> drawn = Cards.shown(cards);
        for (int i = 0; i < rows.getChildCount(); i++) {
            View row = rows.getChildAt(i);
            Cards.Card card = row.getTag() instanceof String ? cardFor((String) row.getTag()) : null;
            ((TextView) row.findViewById(R.id.state)).setText(card != null ? stateText(card, drawn.contains(card)) : "");
        }
    }

    /** The row's state: a card the owner set to Shown but which is beyond the eight drawn says so. */
    private String stateText(Cards.Card card, boolean drawn) {
        switch (card.state) {
            case SHOWN:
                return getString(drawn ? R.string.card_state_shown : R.string.card_state_over_limit);
            case HIDDEN:
                return getString(R.string.card_state_hidden);
            case RESIGNED:
                return getString(R.string.card_state_new_key);
            case RELABELLED:
                return getString(R.string.card_state_new_label);
            default:
                return getString(R.string.card_state_new);
        }
    }
}
