package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.TextView;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak"};
    private static final int[] ACCENTS = {0xFFFF7622, 0xFFFFCA56, 0xFF56E4FF, 0xFF5AAEFF};
    private final Paint spark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path flame = new Path();
    private final Path lastGlyph = new Path();
    private int lastGlyphStart, lastGlyphEnd;
    private PlaybackState playback;
    private long effectsAfter, start, end;
    private boolean compact;
    private int style;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (!TextUtils.equals(getText(), text)) {
            setText(text);
            lastGlyphEnd = text.length();
            while (lastGlyphEnd > 0 && (Character.isWhitespace(text.charAt(lastGlyphEnd - 1))
                    || ".,!?…:;".indexOf(text.charAt(lastGlyphEnd - 1)) >= 0)) lastGlyphEnd--;
            if (lastGlyphEnd > 0) {
                java.text.BreakIterator characters = java.text.BreakIterator.getCharacterInstance();
                characters.setText(text);
                lastGlyphStart = Math.max(0, characters.preceding(lastGlyphEnd));
            }
        }
        this.style = style;
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && hasWindowFocus() && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        boolean active = playing && position >= start && position < end;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();
        if (active && now >= effectsAfter && layout != null) {
            float progress = (position - start) / (float) (end - start);
            long bounceDuration = Math.min(240L, (end - start) / 5L);
            float phase = bounceDuration > 0 && progress >= .8f ? 1f - (end - position) / (float) bounceDuration : -1f;
            boolean bounce = phase > 0f && findLastGlyph(layout);
            int restore = canvas.save();
            if (bounce) canvas.clipOutPath(lastGlyph);
            drawSweep(canvas, layout, progress, now);
            canvas.restoreToCount(restore);
            if (bounce) {
                float jump = (float) Math.sin(phase * Math.PI * 2.7) * (1f - phase) * getTextSize() * .27f;
                int glyphOnly = canvas.save();
                canvas.translate(0f, -jump);
                canvas.clipPath(lastGlyph);
                super.onDraw(canvas);
                canvas.restoreToCount(glyphOnly);
            }
        } else {
            super.onDraw(canvas);
        }
        if (active) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private boolean findLastGlyph(Layout layout) {
        if (lastGlyphEnd <= lastGlyphStart || lastGlyphEnd > layout.getText().length()) return false;
        int line = layout.getLineForOffset(lastGlyphStart);
        if (layout.getEllipsisCount(line) != 0 || layout.getLineForOffset(lastGlyphEnd - 1) != line) return false;
        lastGlyph.rewind();
        layout.getSelectionPath(lastGlyphStart, lastGlyphEnd, lastGlyph);
        lastGlyph.offset(getCompoundPaddingLeft(), getTotalPaddingTop());
        return !lastGlyph.isEmpty();
    }

    private void drawSweep(Canvas canvas, Layout layout, float progress, long now) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            applySweep(paint, x, width, edge, remaining, now);
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if (style == 0 && remaining >= 0f && remaining < width) {
                float baseline = top + layout.getLineBaseline(i);
                drawFlame(canvas, left + edge, baseline, now);
                drawSparks(canvas, left + edge, baseline, now);
            }
            remaining -= width;
        }
    }

    private void applySweep(Paint paint, float x, float width, float edge, float remaining, long now) {
        float size = getTextSize();
        int accent = ACCENTS[style];
        if (style == 2) {
            float pulse = (float) Math.sin(now * 0.003);
            paint.setShader(new LinearGradient(edge - size * 1.4f, 0, edge + size * 1.4f, 0,
                    new int[]{accent, 0xFFFFFFFF, accent}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(size * ((compact ? 0.075f : 0.12f) + 0.025f * pulse), 0, 0, 0xB600C7FF);
        } else if (remaining >= width) {
            paint.setShader(new LinearGradient(x, 0, x + width, 0, accent,
                    style == 0 ? 0xFFFFA832 : accent, Shader.TileMode.CLAMP));
        } else if (remaining >= 0f) {
            if (style == 3) {
                float ripple = (float) Math.sin(now * .016) * size * .32f;
                paint.setShader(new LinearGradient(edge - size * 1.8f, -size, edge + size * .6f + ripple, 0,
                        new int[]{0xFF1E7BCB, 0xFF43C9F6, 0xFF217FCD, 0xFF79E5FF, 0xFFF0FCFF, getCurrentTextColor()},
                        new float[]{0f, .28f, .46f, .68f, .82f, 1f}, Shader.TileMode.CLAMP));
            } else if (style == 1) {
                float gleam = (float) Math.sin(now * .013) * size * .15f;
                paint.setShader(new LinearGradient(edge - size * 1.9f, 0, edge + size * .45f + gleam, size * .45f,
                        new int[]{0xFFF1A824, 0xFFFEDD7B, 0xFFBD7413, 0xFFFFD565, 0xFFFFFBCE, getCurrentTextColor()},
                        new float[]{0f, .30f, .48f, .63f, .80f, 1f}, Shader.TileMode.CLAMP));
            } else {
                float band = size * (compact ? 1.12f : 1.65f);
                paint.setShader(new LinearGradient(edge - band, 0, edge + band * .24f, 0,
                        new int[]{accent, 0xFFFFA832, 0xFFFFF1C4, getCurrentTextColor()},
                        new float[]{0f, .40f, .81f, 1f}, Shader.TileMode.CLAMP));
                paint.setShadowLayer(size * (compact ? .08f : .13f), 0, 0, 0x90FF6715);
            }
        }
    }

    private void drawFlame(Canvas canvas, float x, float baseline, long now) {
        float size = getTextSize();
        float base = baseline - size * .52f;
        for (int i = 0; i < 3; i++) {
            float phase = now * .017f + i * 2.1f;
            float height = size * ((compact ? .49f : .70f) + .16f * (float) Math.sin(phase));
            height = Math.max(1f, Math.min(height, base - 1f));
            float center = x - i * size * .24f;
            float tip = center + (float) Math.cos(phase) * size * .20f;
            float half = size * (i == 0 ? .24f : .18f);
            flame.rewind();
            flame.moveTo(center - half, base);
            flame.cubicTo(center - half * 1.1f, base - height * .40f,
                    tip + half * .52f, base - height * .57f, tip, base - height);
            flame.cubicTo(tip + half, base - height * .74f,
                    center + half * 1.15f, base - height * .30f, center + half, base);
            flame.close();
            spark.setShader(new LinearGradient(0, base, 0, base - height,
                    new int[]{0xEFFFF5C8, 0xFFFFA21B, 0x30FF4E09},
                    new float[]{0f, .42f, 1f}, Shader.TileMode.CLAMP));
            spark.setAlpha(255);
            canvas.drawPath(flame, spark);
        }
        spark.setShader(null);
    }

    private void drawSparks(Canvas canvas, float x, float baseline, long now) {
        float size = getTextSize();
        int count = compact ? 7 : 12;
        for (int i = 0; i < count; i++) {
            float age = ((now + 53L * i) % 480L) / 480f;
            spark.setColor(i % 3 == 0 ? 0xFFFFF3C5 : 0xFFFF9327);
            spark.setAlpha((int) (225f * (1f - age)));
            canvas.drawCircle(x - age * size * (0.45f + (i % 4) * 0.21f),
                    baseline - size * (0.25f + age * (0.42f + (i % 3) * 0.19f)),
                    size * (0.031f + (i % 3) * 0.009f), spark);
        }
    }
}
