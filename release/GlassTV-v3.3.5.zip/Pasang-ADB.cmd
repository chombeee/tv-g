@echo off
setlocal
where adb >nul 2>nul || (echo Pasang Android Platform-Tools dan tambah adb ke PATH. & exit /b 1)
adb devices
adb install -r "%~dp0GlassTV-v3.3.5-manual.apk"
exit /b %errorlevel%
