@echo off
setlocal
cd /d "%~dp0GlassTV-work"
if not defined JAVA_HOME set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-17.0.20.101-hotspot"
set "PATH=%JAVA_HOME%\bin;%PATH%"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "ANDROID_SDK_ROOT=%ANDROID_HOME%"

echo ===== SEMAK JAVA 17 =====
"%JAVA_HOME%\bin\java.exe" -version || exit /b 1

echo ===== BUILD RELEASE PAKSA JAVA 17 =====
call gradlew.bat clean assembleRelease --no-daemon "-Dorg.gradle.java.home=%JAVA_HOME%" || exit /b 1

echo ===== SEMAK APK =====
if not exist "app\build\outputs\apk\release\app-release.apk" (echo APK BELUM BERJAYA DIBINA & exit /b 1)
move /Y "app\build\outputs\apk\release\app-release.apk" "app\build\outputs\apk\release\v3.3.5.apk" || exit /b 1
explorer "app\build\outputs\apk\release"
