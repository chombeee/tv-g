package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.gathin.tvhome.qrcode.QrBitmapUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Preferences > Lokasi Tepat. Left: a QR that opens a map on the phone (search the kampung or tap
 * the house). Right: type the kampung's name with the remote. Either way the TV saves the exact
 * point, its kampung name, the weather there and the prayer zone.
 */
final class LocationPicker {
    private LocationPicker() { }

    static void show(Activity a, Runnable onSaved) {
        float d = a.getResources().getDisplayMetrics().density;
        Handler ui = new Handler(Looper.getMainLooper());
        ExecutorService work = Executors.newSingleThreadExecutor();
        Dialog dialog = new Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        Typeface font;
        try { font = a.getResources().getFont(R.font.outfit); } catch (Exception e) { font = Typeface.DEFAULT; }

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(32 * d);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2141922);
        bg.setCornerRadius(28 * d);
        bg.setStroke(Math.max(1, Math.round(d)), 0x40FFFFFF);
        card.setBackground(bg);

        TextView title = text(a, font, 26, Color.WHITE, true);
        title.setText("📍 Lokasi Tepat");
        card.addView(title);
        TextView current = text(a, font, 15, 0xB3FFFFFF, false);
        current.setText("Sekarang: " + (AutoLocation.isAuto(a) ? "Auto (ikut internet) · " + AutoLocation.cityLabel(a)
                : AppLocationManager.getLocationName(a)));
        current.setPadding(0, Math.round(4 * d), 0, Math.round(18 * d));
        card.addView(current);

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // ---- left: phone map
        LinearLayout left = new LinearLayout(a);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView qr = new ImageView(a);
        left.addView(qr, new LinearLayout.LayoutParams(Math.round(220 * d), Math.round(220 * d)));
        TextView qrHint = text(a, font, 14, 0xCCFFFFFF, false);
        qrHint.setGravity(Gravity.CENTER);
        qrHint.setPadding(0, Math.round(10 * d), 0, 0);
        left.addView(qrHint, new LinearLayout.LayoutParams(Math.round(260 * d), -2));
        row.addView(left, new LinearLayout.LayoutParams(-2, -2));

        // ---- right: search by name
        LinearLayout right = new LinearLayout(a);
        right.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(Math.round(520 * d), -2);
        rlp.leftMargin = Math.round(32 * d);
        row.addView(right, rlp);
        TextView label = text(a, font, 16, Color.WHITE, true);
        label.setText("Atau taip nama kampung / taman");
        right.addView(label);
        EditText field = new EditText(a);
        field.setSingleLine(true);
        field.setHint("cth: Kampung Sungai Ramal");
        field.setHintTextColor(0x80FFFFFF);
        field.setTextColor(Color.WHITE);
        field.setTypeface(font);
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        field.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        field.setBackground(pill(0x26FFFFFF, 0x55FFFFFF, d));
        field.setPadding(Math.round(18 * d), Math.round(12 * d), Math.round(18 * d), Math.round(12 * d));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = Math.round(10 * d);
        right.addView(field, flp);
        TextView status = text(a, font, 14, 0xB3FFFFFF, false);
        status.setPadding(0, Math.round(8 * d), 0, Math.round(4 * d));
        right.addView(status);
        ScrollView scroll = new ScrollView(a);
        LinearLayout results = new LinearLayout(a);
        results.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(results);
        right.addView(scroll, new LinearLayout.LayoutParams(-1, Math.round(230 * d)));

        TextView auto = button(a, font, "↺  Guna lokasi automatik (internet)", d);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-2, -2);
        alp.topMargin = Math.round(18 * d);
        card.addView(auto, alp);

        final Server[] server = {null};
        final boolean[] done = {false};
        final Runnable finish = () -> {
            if (done[0]) return;
            done[0] = true;
            if (dialog.isShowing()) dialog.dismiss();
            if (onSaved != null) onSaved.run();
        };
        final java.util.function.Consumer<String> saved = name -> ui.post(() -> {
            Toast.makeText(a, "📍 Lokasi: " + name, Toast.LENGTH_LONG).show();
            finish.run();
        });

        Runnable search = () -> {
            String q = field.getText().toString().trim();
            if (q.length() < 3) { status.setText("Taip sekurang-kurangnya 3 huruf."); return; }
            status.setText("Mencari…");
            results.removeAllViews();
            work.execute(() -> {
                try {
                    List<PreciseLocation.Place> found = PreciseLocation.search(q);
                    ui.post(() -> {
                        results.removeAllViews();
                        status.setText(found.isEmpty() ? "Tiada hasil. Cuba ejaan lain atau guna peta di telefon." : "Pilih tempat:");
                        for (PreciseLocation.Place p : found) {
                            TextView item = button(a, Typeface.DEFAULT, p.name + "\n" + p.detail, d);
                            item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                            item.setMaxLines(3);
                            item.setOnClickListener(v -> {
                                status.setText("Menyimpan " + p.name + "…");
                                work.execute(() -> saved.accept(PreciseLocation.apply(a, p.name, p.lat, p.lon)));
                            });
                            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                            lp.bottomMargin = Math.round(6 * d);
                            results.addView(item, lp);
                        }
                        if (results.getChildCount() > 0) results.getChildAt(0).requestFocus();
                    });
                } catch (Exception e) {
                    CrashLog.note(a, "location.search", e);
                    ui.post(() -> status.setText("Gagal mencari. Semak internet."));
                }
            });
        };
        field.setOnEditorActionListener((v, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_SEARCH || action == EditorInfo.IME_ACTION_DONE
                    || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { search.run(); return true; }
            return false;
        });
        auto.setOnClickListener(v -> {
            AutoLocation.setAuto(a, true);
            PrayerTimes.clearGpsZone(a);
            AutoLocation.refreshNow(a, onSaved);
            Toast.makeText(a, "Lokasi automatik dihidupkan", Toast.LENGTH_SHORT).show();
            done[0] = true;
            dialog.dismiss();
        });

        // Phone map server.
        String ip = WallpaperUploadServer.getLocalIpAddress();
        for (int port : new int[]{8090, 8091, 8092}) {
            Server s = new Server(a, port, saved);
            if (s.start()) { server[0] = s; break; }
        }
        if (server[0] != null && ip != null && !ip.isEmpty()) {
            String url = "http://" + ip + ":" + server[0].port;
            Bitmap bmp = QrBitmapUtil.createQrBitmap(url, Math.round(220 * d));
            if (bmp != null) qr.setImageBitmap(bmp);
            qrHint.setText("Imbas dengan telefon (Wi-Fi sama). Cari kampung atau tekan rumah anda pada peta.\n" + url);
        } else {
            qr.setVisibility(View.GONE);
            qrHint.setText("Peta telefon tidak tersedia (tiada Wi-Fi). Guna carian di sebelah.");
        }
        dialog.setOnDismissListener(x -> {
            if (server[0] != null) server[0].stop();
            work.shutdownNow();
        });

        LinearLayout stage = new LinearLayout(a);
        stage.setGravity(Gravity.CENTER);
        stage.setBackgroundColor(0x99000000);
        stage.addView(card, new LinearLayout.LayoutParams(-2, -2));
        dialog.setContentView(stage);
        Window w = dialog.getWindow();
        if (w != null) w.setBackgroundDrawable(new ColorDrawable(0));
        dialog.show();
        PanelMotion.openDialog(dialog, card, 0.9f);
        field.requestFocus();
    }

    private static TextView text(Activity a, Typeface font, int sp, int color, boolean bold) {
        TextView t = new TextView(a);
        t.setTypeface(font, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private static TextView button(Activity a, Typeface font, String label, float d) {
        TextView b = text(a, font, 16, Color.WHITE, false);
        b.setText(label);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(Math.round(18 * d), Math.round(10 * d), Math.round(18 * d), Math.round(10 * d));
        GradientDrawable off = pill(0x1FFFFFFF, 0x33FFFFFF, d), on = pill(0xFFFFFFFF, 0xFFFFFFFF, d);
        b.setBackground(off);
        b.setOnFocusChangeListener((v, f) -> {
            b.setBackground(f ? on : off);
            b.setTextColor(f ? 0xFF111111 : Color.WHITE);
            v.animate().scaleX(f ? 1.03f : 1f).scaleY(f ? 1.03f : 1f).setDuration(160).start();
        });
        return b;
    }

    private static GradientDrawable pill(int fill, int stroke, float d) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(16 * d);
        g.setStroke(Math.max(1, Math.round(d)), stroke);
        return g;
    }

    // ------------------------------------------------------------------ phone map server

    /** Serves the map page and takes the picked point. Runs only while the dialog is open. */
    private static final class Server {
        final int port;
        private final Activity a;
        private final java.util.function.Consumer<String> saved;
        private ServerSocket socket;
        private volatile boolean running;

        Server(Activity a, int port, java.util.function.Consumer<String> saved) {
            this.a = a; this.port = port; this.saved = saved;
        }

        boolean start() {
            try {
                socket = new ServerSocket();
                socket.setReuseAddress(true);
                socket.bind(new InetSocketAddress(port));
                running = true;
                Thread t = new Thread(() -> {
                    while (running) {
                        try {
                            Socket client = socket.accept();
                            new Thread(() -> handle(client), "location-client").start();
                        } catch (Exception e) {
                            if (running) CrashLog.note(a, "location.server", e);
                        }
                    }
                }, "location-server");
                t.setDaemon(true);
                t.start();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        void stop() {
            running = false;
            try { if (socket != null) socket.close(); } catch (Exception ignored) { /* closing anyway */ }
        }

        private void handle(Socket client) {
            try (Socket c = client) {
                c.setSoTimeout(15000);
                InputStream in = c.getInputStream();
                StringBuilder head = new StringBuilder();
                int b;
                while ((b = in.read()) != -1 && head.length() < 8192) {
                    head.append((char) b);
                    if (head.length() >= 4 && head.substring(head.length() - 4).equals("\r\n\r\n")) break;
                }
                String line = head.toString().split("\r\n", 2)[0];
                String[] parts = line.split(" ");
                if (parts.length < 2) return;
                String path = parts[1];
                OutputStream out = c.getOutputStream();
                if (path.startsWith("/api/search")) {
                    String q = param(path, "q");
                    JSONArray arr = new JSONArray();
                    if (q != null && q.trim().length() >= 3) {
                        for (PreciseLocation.Place p : PreciseLocation.search(q.trim())) {
                            arr.put(new JSONObject().put("name", p.name).put("detail", p.detail)
                                    .put("lat", p.lat).put("lon", p.lon));
                        }
                    }
                    send(out, "200 OK", "application/json", arr.toString());
                } else if (path.startsWith("/api/pick")) {
                    double lat = Double.parseDouble(param(path, "lat"));
                    double lon = Double.parseDouble(param(path, "lon"));
                    if (lat < -11 || lat > 8 || lon < 94 || lon > 142) {   // around Malaysia / the region
                        send(out, "400 Bad Request", "application/json", "{\"error\":\"Lokasi di luar kawasan\"}");
                        return;
                    }
                    String name = param(path, "name");
                    String used = PreciseLocation.apply(a, name, lat, lon);
                    send(out, "200 OK", "application/json", new JSONObject().put("name", used).toString());
                    saved.accept(used);
                } else {
                    send(out, "200 OK", "text/html; charset=utf-8", PAGE);
                }
            } catch (Exception e) {
                CrashLog.note(a, "location.client", e);
            }
        }

        private static String param(String path, String key) throws Exception {
            int q = path.indexOf('?');
            if (q < 0) return null;
            for (String kv : path.substring(q + 1).split("&")) {
                int eq = kv.indexOf('=');
                if (eq > 0 && kv.substring(0, eq).equals(key)) return URLDecoder.decode(kv.substring(eq + 1), "UTF-8");
            }
            return null;
        }

        private static void send(OutputStream out, String status, String type, String body) throws Exception {
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            out.write(("HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + bytes.length
                    + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            out.write(bytes);
            out.flush();
        }
    }

    /** Phone page: Leaflet map (from the phone's own internet), search box, tap to drop the pin. */
    private static final String PAGE = "<!doctype html><html lang=ms><head><meta charset=utf-8>"
            + "<meta name=viewport content='width=device-width,initial-scale=1'>"
            + "<title>GlassTV · Lokasi</title>"
            + "<link rel=stylesheet href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'>"
            + "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"
            + "<style>body{margin:0;font-family:system-ui,sans-serif;background:#0f131a;color:#fff}"
            + "#top{padding:12px;display:flex;gap:8px}#q{flex:1;padding:12px 14px;border-radius:14px;border:1px solid #fff4;background:#ffffff14;color:#fff;font-size:16px}"
            + "button{padding:12px 16px;border:0;border-radius:14px;background:#fff;color:#111;font-weight:600;font-size:15px}"
            + "#list div{padding:10px 14px;border-bottom:1px solid #ffffff1a}#list small{opacity:.65}"
            + "#map{height:58vh}#bar{padding:12px;display:flex;flex-direction:column;gap:8px}#msg{opacity:.85;font-size:14px}"
            + "#save{background:#2e8cf2;color:#fff;font-size:17px;padding:14px}</style></head><body>"
            + "<div id=top><input id=q placeholder='Cari kampung / taman / jalan'><button onclick=find()>Cari</button></div>"
            + "<div id=list></div><div id=map></div>"
            + "<div id=bar><div id=msg>Tekan rumah anda pada peta, atau cari dahulu.</div>"
            + "<button id=save onclick=save() disabled>Simpan ke TV</button></div>"
            + "<script>"
            + "var map=L.map('map').setView([4.2,102.0],6),pin=null,pick=null,pickName='';"
            + "L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);"
            + "function put(lat,lon,name){pick=[lat,lon];pickName=name||'';if(pin)pin.setLatLng(pick);else pin=L.marker(pick).addTo(map);"
            + "document.getElementById('save').disabled=false;document.getElementById('msg').textContent=(name?name+' · ':'')+lat.toFixed(5)+', '+lon.toFixed(5);}"
            + "map.on('click',function(e){put(e.latlng.lat,e.latlng.lng,'');});"
            + "function find(){var q=document.getElementById('q').value.trim();if(q.length<3)return;var l=document.getElementById('list');l.textContent='Mencari…';"
            + "fetch('/api/search?q='+encodeURIComponent(q)).then(r=>r.json()).then(a=>{l.innerHTML='';if(!a.length)l.textContent='Tiada hasil.';"
            + "a.forEach(function(p){var d=document.createElement('div');d.innerHTML='<b></b><br><small></small>';d.querySelector('b').textContent=p.name;"
            + "d.querySelector('small').textContent=p.detail;d.onclick=function(){l.innerHTML='';map.setView([p.lat,p.lon],16);put(p.lat,p.lon,p.name);};l.appendChild(d);});})"
            + ".catch(function(){l.textContent='Gagal mencari.';});}"
            + "document.getElementById('q').addEventListener('keydown',function(e){if(e.key==='Enter')find();});"
            + "function save(){if(!pick)return;var b=document.getElementById('save');b.disabled=true;b.textContent='Menyimpan…';"
            + "fetch('/api/pick?lat='+pick[0]+'&lon='+pick[1]+'&name='+encodeURIComponent(pickName)).then(r=>r.json()).then(j=>{"
            + "b.textContent='✓ Disimpan';document.getElementById('msg').textContent='TV kini guna: '+(j.name||j.error);})"
            + ".catch(function(){b.disabled=false;b.textContent='Simpan ke TV';document.getElementById('msg').textContent='Gagal. Cuba lagi.';});}"
            + "</script></body></html>";
}
