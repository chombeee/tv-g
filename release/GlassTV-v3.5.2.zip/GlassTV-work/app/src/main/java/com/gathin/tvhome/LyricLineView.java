package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.widget.TextView;

/**
 * Draws the selected effect only while this line is being sung.
 *
 * v3.5: the light now travels word by word (weighted by syllables), each word rises and
 * swells as it is sung, the sweep finishes when the singer does instead of when the next
 * line starts, the colour fades out gently when the line is left behind, and "• • •"
 * gaps breathe and fill like Apple Music. All shaders are cached, so nothing is allocated
 * per frame (important on the Mi Box).
 */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak", "Itik Ombak", "Aurora", "Sakura"};
    private static final int FIRE = 0, GOLD = 1, NEON = 2, WAVE = 3, DUCK = 4, AURORA = 5, SAKURA = 6;
    private static final long RELEASE_MS = 560L, SETTLE_MS = 700L, IGNITE_MS = 300L;
    /** Tail → head → unsung, over a unit gradient whose head sits at HEAD. */
    private static final float HEAD = 0.86f;
    private static final int[][] SWEEP = {
            {0xFFFF5A1A, 0xFFFF7A1F, 0xFFFFB038, 0xFFFFF1C8, 0xFFFFFFFF},   // Api
            {0xFFF0B030, 0xFFFFD86E, 0xFFC0841A, 0xFFFFF8D6, 0xFFFFFFFF},   // Emas
            {0xFF3FE6FF, 0xFF8AF3FF, 0xFFFF6BE0, 0xFFFFFFFF, 0xFFFFFFFF},   // Neon
            {0xFF2C98E6, 0xFF52D2FF, 0xFF2A86D6, 0xFFEFFCFF, 0xFFFFFFFF},   // Ombak
            {0xFF2C98E6, 0xFF52D2FF, 0xFF2A86D6, 0xFFEFFCFF, 0xFFFFFFFF},   // Itik Ombak
            {0xFFF4FBFF, 0xFFFFFFFF, 0xFFE4F0FF, 0xFFFFFFFF, 0xB3FFFFFF},   // Aurora
            {0xFFFF8DBF, 0xFFFFB3D4, 0xFFFF7FB6, 0xFFFFF0F7, 0xFFFFFFFF},   // Sakura
    };
    private static final float[] SWEEP_STOPS = {0f, .45f, .70f, HEAD, 1f};
    private static final int[] GLOW = {0xB0FF6A14, 0x9CFFC23A, 0xD000D2FF, 0x9A2EB4FF, 0x9A2EB4FF, 0xC060E0FF, 0xA8FF6FAE};

    private final TextPaint word = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint plain = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint character = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint splash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path drop = new Path();
    private final Path wake = new Path();
    private final Path star = new Path();
    private final Path petal = new Path();
    private final float[] hsv = new float[3];
    private final Matrix matrix = new Matrix();
    private final LinearGradient[] sweep = new LinearGradient[STYLES.length];
    private RadialGradient fireHalo, waterHalo;

    private PlaybackState playback;
    private long effectsAfter, start, end, activatedAt = -1L, releasedAt = -1L;
    private boolean playsInScreensaver, compact, dots, wasActive;
    private int style;

    // Word geometry, rebuilt only when the layout or text changes.
    private Layout geometryFor;
    private CharSequence geometryText;
    private float geometrySize;
    private int words;
    private int[] wordStart = new int[16], wordEnd = new int[16], wordLine = new int[16];
    private float[] wordLeft = new float[16], wordRight = new float[16], wordDone = new float[16];
    private float textWidth;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void setPlaysInScreensaver() { playsInScreensaver = true; }

    /** This row is an instrumental gap: draw breathing dots instead of the text. */
    void setDots() { dots = true; invalidate(); }

    @Override public int getCompoundPaddingBottom() {
        return super.getCompoundPaddingBottom() + (style == DUCK && !dots ? Math.round(getTextSize() * .42f) : 0);
    }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (style < 0 || style >= STYLES.length) style = 0;
        if (this.style != style) {
            this.style = style;
            requestLayout();
        }
        boolean changed = !TextUtils.equals(getText(), text);
        if (changed) {
            setText(text);
            releasedAt = -1L;
            wasActive = false;
        }
        if (playback == null && wasActive && !changed) {
            releasedAt = SystemClock.uptimeMillis();   // fade the colour out instead of snapping
            wasActive = false;
        }
        if (start != this.start) activatedAt = -1L;
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && (hasWindowFocus() || playsInScreensaver) && getWindowVisibility() == VISIBLE;
        long position = playback != null ? NowPlaying.positionOf(playback) : -1L;
        boolean inWindow = end > start && position >= start && position < end;
        boolean active = playing && inWindow;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();

        if (dots) {
            if (layout == null) return;
            drawDots(canvas, layout, active, position, now);
            if (active) postInvalidateOnAnimation();
            return;
        }
        if (layout == null) { super.onDraw(canvas); return; }

        if (active && now >= effectsAfter) {
            if (activatedAt < 0) activatedAt = now;
            wasActive = true;
            releasedAt = -1L;
            long singEnd = singEnd();
            float progress = clamp((position - start) / (float) Math.max(1L, singEnd - start));
            float settle = position > singEnd ? clamp((position - singEnd) / (float) SETTLE_MS) : 0f;
            drawWords(canvas, layout, progress, settle, 1f, now, singEnd);
            // Once the line has settled it is a still picture; the 90 ms tick keeps it fresh.
            if (settle < 1f || now - activatedAt < IGNITE_MS) postInvalidateOnAnimation();
            return;
        }
        if (inWindow && wasActive && playback != null && playback.getState() != PlaybackState.STATE_PLAYING) {
            // Paused mid-line: hold the light where it stopped instead of snapping to white.
            long singEnd = singEnd();
            float progress = clamp((position - start) / (float) Math.max(1L, singEnd - start));
            float settle = position > singEnd ? clamp((position - singEnd) / (float) SETTLE_MS) : 0f;
            drawWords(canvas, layout, progress, Math.max(settle, .5f), 1f, now, singEnd);
            return;
        }
        if (releasedAt > 0L && now - releasedAt < RELEASE_MS) {
            float t = (now - releasedAt) / (float) RELEASE_MS;
            drawWords(canvas, layout, 1f, 1f, 1f - t * t * (3f - 2f * t), now, start);
            postInvalidateOnAnimation();
            return;
        }
        releasedAt = -1L;
        super.onDraw(canvas);
        if (active) postInvalidateOnAnimation();   // waiting for the slide to finish
    }

    /**
     * LRCLIB only knows when the next line starts. Singers usually finish earlier and rest,
     * so estimate how long the words take (Malay/English ≈ 8–9 characters a second).
     */
    private long singEnd() {
        long gap = end - start;
        int length = Math.max(1, getText().length());
        long natural = 900L + length * 115L;
        if (gap > natural * 13L / 10L) return start + natural;
        return start + gap * 94L / 100L;
    }

    // ------------------------------------------------------------------ words

    private void ensureGeometry(Layout layout) {
        CharSequence text = getText();
        float size = getTextSize();
        if (layout == geometryFor && text == geometryText && size == geometrySize) return;
        geometryFor = layout;
        geometryText = text;
        geometrySize = size;
        word.set(getPaint());
        plain.set(getPaint());
        plain.setShader(null);
        plain.clearShadowLayer();
        words = 0;
        textWidth = 0f;
        float total = 0f;
        int length = text.length();
        for (int line = 0; line < layout.getLineCount(); line++) {
            int ls = layout.getLineStart(line), le = Math.min(length, layout.getLineEnd(line));
            textWidth += layout.getLineWidth(line);
            if (layout.getParagraphDirection(line) == Layout.DIR_RIGHT_TO_LEFT) {
                // Right-to-left scripts keep their shaping: the whole row is one run.
                int a = ls, b = le;
                while (a < b && Character.isWhitespace(text.charAt(a))) a++;
                while (b > a && Character.isWhitespace(text.charAt(b - 1))) b--;
                if (a < b) total += addWord(a, b, line, layout.getLineLeft(line), layout.getLineRight(line), text);
                continue;
            }
            int i = ls;
            while (i < le) {
                while (i < le && Character.isWhitespace(text.charAt(i))) i++;
                int a = i;
                while (i < le && !Character.isWhitespace(text.charAt(i))) i++;
                if (i > a) {
                    float x = layout.getPrimaryHorizontal(a);
                    total += addWord(a, i, line, x, x + word.measureText(text, a, i), text);
                }
            }
        }
        float sum = 0f;
        for (int k = 0; k < words; k++) {
            sum += wordDone[k];
            wordDone[k] = total > 0f ? sum / total : 1f;
        }
    }

    /** Stores one word; its weight follows syllables so long words take longer. */
    private float addWord(int a, int b, int line, float left, float right, CharSequence text) {
        if (words == wordStart.length) {
            int n = words * 2;
            wordStart = java.util.Arrays.copyOf(wordStart, n);
            wordEnd = java.util.Arrays.copyOf(wordEnd, n);
            wordLine = java.util.Arrays.copyOf(wordLine, n);
            wordLeft = java.util.Arrays.copyOf(wordLeft, n);
            wordRight = java.util.Arrays.copyOf(wordRight, n);
            wordDone = java.util.Arrays.copyOf(wordDone, n);
        }
        int syllables = 0;
        boolean vowel = false;
        for (int i = a; i < b; i++) {
            boolean v = "aeiouyAEIOUY".indexOf(text.charAt(i)) >= 0;
            if (v && !vowel) syllables++;
            vowel = v;
        }
        float weight = Math.max(1, syllables) + (b - a) * .15f;
        wordStart[words] = a;
        wordEnd[words] = b;
        wordLine[words] = line;
        wordLeft[words] = left;
        wordRight[words] = right;
        wordDone[words] = weight;
        words++;
        return weight;
    }

    private float wordProgress(int k, float progress) {
        float from = k == 0 ? 0f : wordDone[k - 1], to = wordDone[k];
        if (progress <= from) return 0f;
        if (progress >= to) return 1f;
        return (progress - from) / Math.max(1e-4f, to - from);
    }

    /**
     * @param mix 1 while singing; falls to 0 as a finished line hands over to plain white.
     */
    private void drawWords(Canvas canvas, Layout layout, float progress, float settle, float mix,
                           long now, long singEnd) {
        ensureGeometry(layout);
        if (words == 0) { super.onDraw(canvas); return; }
        CharSequence text = getText();
        float size = getTextSize();
        float left = getCompoundPaddingLeft(), top = getTotalPaddingTop();
        float band = size * (compact ? 2.3f : 3.2f);
        float span = band / HEAD;
        int color = getCurrentTextColor();
        LinearGradient shader = sweepShader();

        // Find the head of the light: which word is being sung and how far into it.
        int head = -1;
        float headX = 0f;
        for (int k = 0; k < words; k++) {
            float p = wordProgress(k, progress);
            if (p < 1f) {
                head = k;
                headX = left + wordLeft[k] + (wordRight[k] - wordLeft[k]) * p;
                break;
            }
        }

        float glow = (1f - .62f * settle) * mix;
        if (style == NEON) glow *= .82f + .18f * (float) Math.sin(now * .0042);
        float ignite = 1f;
        if (style == NEON && activatedAt > 0 && now - activatedAt < IGNITE_MS) {
            long t = now - activatedAt;   // a neon tube flickering on
            ignite = ((t / 38L) % 3L == 1L) ? .35f : 1f;
        }
        float lift = size * (compact ? .045f : .075f) * mix;
        float swell = compact ? .035f : .055f;
        float bob = (style == WAVE || style == DUCK) ? size * .035f * (1f - settle) * mix : 0f;
        int glowColor = GLOW[style];
        float glowRadius = size * (compact ? .09f : .15f) * (style == AURORA ? 1.5f : 1f);
        float headLift = 0f, headScale = 1f;
        int headLine = head >= 0 ? wordLine[head] : -1;

        for (int k = 0; k < words; k++) {
            int line = wordLine[k];
            float p = wordProgress(k, progress);
            float baseline = top + layout.getLineBaseline(line);
            if (baseline - size > getHeight()) break;
            // Edge of the light on this row: past rows fully lit, later rows still white.
            float edge;
            if (head < 0 || line < headLine) edge = left + layout.getLineRight(line) + span * 2f;
            else if (line > headLine) edge = left + layout.getLineLeft(line) - span;
            else edge = headX;

            float x0 = left + wordLeft[k], x1 = left + wordRight[k];
            float cx = (x0 + x1) * .5f;
            float eased = 1f - (1f - p) * (1f - p);
            float dy = -lift * eased;
            if (bob > 0f && p > 0f) dy += (float) Math.sin(now * .0045 + k * .9) * bob * p;
            float scale = 1f + swell * (float) Math.sin(Math.PI * p) * mix;
            if (k == head) { headLift = dy; headScale = scale; }

            // Shader lives in the word's local space: undo the per-word scale.
            matrix.setScale(span, 1f);
            matrix.postTranslate(edge - band, 0f);
            matrix.postTranslate(-cx, 0f);
            matrix.postScale(1f / scale, 1f);
            matrix.postTranslate(cx, 0f);
            shader.setLocalMatrix(matrix);

            int saved = canvas.save();
            canvas.translate(0f, dy);
            canvas.scale(scale, scale, cx, baseline);
            if (mix < 1f) {
                plain.setColor(color);
                plain.setAlpha(Math.round((color >>> 24) * (1f - mix)));
                canvas.drawText(text, wordStart[k], wordEnd[k], x0, baseline, plain);
            }
            word.setShader(shader);
            word.setAlpha(Math.round(255f * mix * ignite));
            if (p > 0f && glow > .02f) {
                int tint = style == AURORA ? auroraColor(now, k, 0xC0) : glowColor;
                word.setShadowLayer(glowRadius * (.6f + .4f * glow), 0f, 0f,
                        scaleAlpha(tint, glow * ignite));
            } else {
                word.clearShadowLayer();
            }
            canvas.drawText(text, wordStart[k], wordEnd[k], x0, baseline, word);
            canvas.restoreToCount(saved);
        }
        word.setShader(null);
        word.clearShadowLayer();

        if (head >= 0 && mix >= 1f && settle <= 0f) {
            float baseline = top + layout.getLineBaseline(headLine) + headLift;
            float speed = textWidth * 1000f / Math.max(1L, singEnd - start);
            if (style == DUCK) drawDuck(canvas, headX, baseline, now);
            else if (style == FIRE || style == WAVE) drawSplash(canvas, headX, baseline, speed, now, style == WAVE);
            else if (style == GOLD) drawSparkles(canvas, headX, baseline, headScale, now);
            else if (style == AURORA) drawAuroraHead(canvas, headX, baseline, now, head);
            else if (style == SAKURA) drawPetals(canvas, headX, baseline, now);
            else drawNeonSpark(canvas, headX, baseline, now);
        }
    }

    private static int scaleAlpha(int color, float factor) {
        int a = Math.round((color >>> 24) * Math.max(0f, Math.min(1f, factor)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    /** Northern-lights hues (green → teal → blue → violet) drifting slowly per word. */
    private int auroraColor(long now, int k, int alpha) {
        hsv[0] = 205f + 75f * (float) Math.sin(now * .0011 + k * .7);
        hsv[1] = .62f;
        hsv[2] = 1f;
        return (android.graphics.Color.HSVToColor(hsv) & 0xFFFFFF) | (alpha << 24);
    }

    private static float clamp(float v) { return v < 0f ? 0f : v > 1f ? 1f : v; }

    private LinearGradient sweepShader() {
        LinearGradient g = sweep[style];
        if (g == null) {
            g = new LinearGradient(0f, 0f, 1f, 0f, SWEEP[style], SWEEP_STOPS, Shader.TileMode.CLAMP);
            sweep[style] = g;
        }
        return g;
    }

    // ------------------------------------------------------------------- dots

    /** Three dots fill one after another while the band plays, breathe, then bow out. */
    private void drawDots(Canvas canvas, Layout layout, boolean active, long position, long now) {
        float size = getTextSize();
        float r = size * .15f, gap = size * .62f;
        float top = getTotalPaddingTop();
        float cy = top + (layout.getLineTop(0) + layout.getLineBottom(0)) * .5f;
        float groupWidth = gap * 2f;
        float lineLeft = getCompoundPaddingLeft() + layout.getLineLeft(0);
        float lineRight = getCompoundPaddingLeft() + layout.getLineRight(0);
        float cx = (getGravity() & android.view.Gravity.HORIZONTAL_GRAVITY_MASK) == android.view.Gravity.CENTER_HORIZONTAL
                ? (lineLeft + lineRight) * .5f : lineLeft + groupWidth * .5f + r;
        float progress = 0f, breathe = 1f, exit = 1f;
        if (active) {
            progress = clamp((position - start) / (float) Math.max(1L, end - start));
            breathe = 1f + .13f * (float) Math.sin(now * (Math.PI * 2 / 1700.0));
            exit = clamp((end - position) / 520f);
            exit = exit * exit * (3f - 2f * exit);
        }
        int saved = canvas.save();
        float scale = breathe * (.35f + .65f * exit);
        canvas.scale(scale, scale, cx, cy);
        splash.setShader(null);
        for (int i = 0; i < 3; i++) {
            float fill = active ? clamp(progress * 3.15f - i) : 0f;
            float x = cx - gap + gap * i;
            float y = cy - (active ? (float) Math.sin(now * .004 + i * 1.1) * r * .25f : 0f);
            int alpha = Math.round((70f + 185f * fill) * (active ? exit : 1f));
            splash.setColor(0xFFFFFFFF);
            splash.setAlpha(alpha);
            if (fill > 0f) splash.setShadowLayer(r * 1.4f * fill, 0f, 0f, 0x80FFFFFF);
            else splash.clearShadowLayer();
            canvas.drawCircle(x, y, r * (.86f + .14f * fill), splash);
        }
        splash.clearShadowLayer();
        canvas.restoreToCount(saved);
    }

    // ------------------------------------------------------------ head effects

    private void drawDuck(Canvas canvas, float edge, float baseline, long now) {
        float unit = getTextSize() * (compact ? .65f : .76f);
        float x = Math.max(unit, Math.min(getWidth() - unit, edge));
        float sea = (now % 10000L) * .009f;
        float y = Math.max(unit, Math.min(getHeight() - unit * .65f, baseline + unit * .42f));
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.scale(unit, unit);

        drawWake(canvas, sea, -.13f, 0x8A16658C, 0x769DDFFF);
        drawDuckSpray(canvas, now, false);
        int bird = canvas.save();
        canvas.translate(0f, (float) Math.sin(sea) * .045f);
        canvas.rotate((float) Math.cos(sea) * 4f);
        character.setColor(0xFFFFB629);
        canvas.drawOval(-.76f, -.31f, .51f, .30f, character);
        character.setColor(0xFFFFD957);
        canvas.drawOval(-.49f, -.22f, .12f, .12f, character);
        character.setColor(0xFFFFE05C);
        canvas.drawCircle(.29f, -.40f, .35f, character);
        character.setColor(0xFFFF861D);
        canvas.drawOval(.48f, -.40f, .90f, -.21f, character);
        character.setColor(0xFF24202A);
        canvas.drawCircle(.39f, -.49f, .065f, character);
        character.setColor(0xFFFFFFFF);
        canvas.drawCircle(.415f, -.515f, .022f, character);
        canvas.restoreToCount(bird);
        drawWake(canvas, sea + 2.1f, .16f, 0xB325A8CE, 0xDEF0FDFF);
        drawDuckSpray(canvas, now, true);
        canvas.restoreToCount(saved);
    }

    private void drawWake(Canvas canvas, float phase, float height, int fill, int foam) {
        wake.rewind();
        wake.moveTo(-1.50f, height);
        float swell = (float) Math.sin(phase) * .16f;
        wake.cubicTo(-1.10f, height - .08f, -.69f, height + swell, -.26f, height);
        wake.cubicTo(.18f, height - swell, .48f, height + .16f, .83f, height - .08f);
        wake.quadTo(1.11f, height - .23f, 1.39f, height);
        character.setColor(foam);
        character.setStyle(Paint.Style.STROKE);
        character.setStrokeWidth(.045f);
        canvas.drawPath(wake, character);
        character.setStyle(Paint.Style.FILL);
        wake.quadTo(.75f, height + .30f, -.30f, height + .25f);
        wake.quadTo(-1.29f, height + .19f, -1.50f, height);
        wake.close();
        character.setColor(fill);
        canvas.drawPath(wake, character);
    }

    private void drawDuckSpray(Canvas canvas, long now, boolean foreground) {
        // Alternating directions launch off the bow and wake, then fall under gravity.
        for (int i = 0; i < 6; i++) {
            int index = foreground ? i + 6 : i;
            long cycle = 360L + index * 19L;
            float t = ((now + index * 53L) % cycle) / (float) cycle;
            float side = index % 2 == 0 ? 1f : -1f;
            float vx = side * (.68f + (index % 4) * .25f);
            float lift = .67f + (index % 5) * .25f;
            float x = side * (.48f + t * Math.abs(vx));
            float y = (foreground ? .16f : -.06f) - lift * t + lift * t * t;
            float size = (.044f + (index % 4) * .019f) * (1f - t * .42f);
            drawDroplet(canvas, x, y, size, vx, lift * (2f * t - 1f),
                    (1f - t) * (foreground ? 1f : .65f), index);
        }
    }

    /** Fire embers rise and flicker; water droplets arc and fall with white highlights. */
    private void drawSplash(Canvas canvas, float head, float baseline, float sweepSpeed, long now, boolean water) {
        float size = getTextSize();
        float centerY = baseline - size * .40f;
        float pulse = .86f + .14f * (float) Math.sin((now % 10000L) * .018);
        float halo = size * (compact ? .62f : .86f) * pulse;
        drawHalo(canvas, head, centerY, halo, water);

        int count = compact ? 10 : 14;
        for (int i = 0; i < count; i++) {
            long period = 410L + (i * 83L) % 215L + (water ? 0L : 160L);
            float elapsed = ((now + 83L * i) % period) / 1000f;
            float phase = elapsed * 1000f / period;
            float direction = (i % 4 == 0) ? 1f : -1f;
            float speedX = size * (1.70f + ((i * 7) % 11) * .31f);
            float speedY = size * (.48f + ((i * 11) % 7) * .22f) * direction;
            float gravity = size * (water ? 5.6f : -2.4f);
            float x = head - size * (.08f + i % 4 * .21f) + (speedX - sweepSpeed * .25f) * elapsed;
            float wobble = water ? 0f : (float) Math.sin(now * .02 + i * 1.7) * size * .05f;
            float y = centerY + speedY * elapsed + gravity * elapsed * elapsed * .5f + wobble;
            float radius = size * (.050f + ((i * 5) % 7) * .010f) * (1f - .55f * phase);
            if (x + radius < 0f || x - radius > getWidth()
                    || y + radius < 0f || y - radius > getHeight()) continue;
            float opacity = (1f - phase) * (1f - phase);
            if (water) {
                drawDroplet(canvas, x, y, radius, speedX, speedY + gravity * elapsed, opacity, i);
            } else {
                float flicker = .75f + .25f * (float) Math.sin(now * .05 + i * 2.3);
                splash.setColor(phase < .35f ? 0xFFFFE7A8 : i % 4 == 0 ? 0xFFFF5A1A : 0xFFFF8D35);
                splash.setAlpha(Math.round(95f * opacity * flicker));
                canvas.drawCircle(x, y, radius * 1.9f, splash);
                splash.setColor(phase < .3f ? 0xFFFFFFF0 : i % 3 == 0 ? 0xFFFFF7DA : 0xFFFFBC64);
                splash.setAlpha(Math.round(255f * opacity * flicker));
                canvas.drawCircle(x, y, radius, splash);
            }
        }
    }

    private void drawHalo(Canvas canvas, float x, float y, float radius, boolean water) {
        RadialGradient g = water ? waterHalo : fireHalo;
        if (g == null) {
            g = new RadialGradient(0f, 0f, 1f,
                    water ? new int[]{0xB9ECFCFF, 0x6043C9FF, 0x00217FCD}
                            : new int[]{0xC8FFF4D0, 0x70FF9D3C, 0x00FF7622},
                    new float[]{0f, .40f, 1f}, Shader.TileMode.CLAMP);
            if (water) waterHalo = g; else fireHalo = g;
        }
        matrix.setScale(radius, radius);
        matrix.postTranslate(x, y);
        g.setLocalMatrix(matrix);
        splash.setShader(g);
        splash.setAlpha(255);
        canvas.drawCircle(x, y, radius, splash);
        splash.setShader(null);
    }

    /** Emas: a warm halo and four-point stars that twinkle in the wake of the light. */
    private void drawSparkles(Canvas canvas, float head, float baseline, float headScale, long now) {
        float size = getTextSize();
        float centerY = baseline - size * .40f;
        drawHalo(canvas, head, centerY, size * (compact ? .5f : .7f), false);
        int count = compact ? 5 : 7;
        for (int i = 0; i < count; i++) {
            long period = 720L + i * 137L;
            float phase = ((now + i * 211L) % period) / (float) period;
            float x = head - size * (.15f + phase * (1.1f + (i % 3) * .35f));
            float y = centerY + (float) Math.sin(i * 2.3f) * size * .48f * headScale;
            float twinkle = (float) Math.sin(Math.PI * phase);
            float r = size * (.07f + (i % 3) * .035f) * twinkle;
            if (r <= .5f) continue;
            star.rewind();
            star.moveTo(x, y - r);
            star.quadTo(x, y, x + r, y);
            star.quadTo(x, y, x, y + r);
            star.quadTo(x, y, x - r, y);
            star.quadTo(x, y, x, y - r);
            star.close();
            splash.setColor(i % 2 == 0 ? 0xFFFFF6D0 : 0xFFFFD86E);
            splash.setAlpha(Math.round(250f * twinkle));
            canvas.drawPath(star, splash);
        }
    }

    /** Aurora: a soft coloured bloom and two thin light ribbons trailing the head. */
    private void drawAuroraHead(Canvas canvas, float head, float baseline, long now, int k) {
        float size = getTextSize();
        float centerY = baseline - size * .40f;
        int tint = auroraColor(now, k, 0xFF);
        splash.setShader(null);
        splash.setStyle(Paint.Style.FILL);
        splash.setColor(0xFFFFFFFF);
        splash.setAlpha(235);
        splash.setShadowLayer(size * (compact ? .45f : .7f), 0f, 0f, scaleAlpha(tint, .9f));
        canvas.drawCircle(head, centerY, size * .06f, splash);
        splash.clearShadowLayer();
        splash.setStyle(Paint.Style.STROKE);
        splash.setStrokeCap(Paint.Cap.ROUND);
        for (int r = 0; r < 2; r++) {
            petal.rewind();
            float amp = size * (.16f + r * .08f);
            float phase = now * .006f + r * 2.1f;
            float length = size * (1.6f + r * .7f);
            petal.moveTo(head - length, centerY + (float) Math.sin(phase) * amp);
            petal.cubicTo(head - length * .66f, centerY + (float) Math.sin(phase + 1.4f) * amp,
                    head - length * .33f, centerY + (float) Math.sin(phase + 2.8f) * amp,
                    head, centerY);
            splash.setStrokeWidth(size * (r == 0 ? .05f : .03f));
            splash.setColor(auroraColor(now, k + 3 * r + 1, 0xFF));
            splash.setAlpha(r == 0 ? 150 : 95);
            canvas.drawPath(petal, splash);
        }
        splash.setStyle(Paint.Style.FILL);
    }

    /** Sakura: petals tumble off the sung words, sway and drift down. */
    private void drawPetals(Canvas canvas, float head, float baseline, long now) {
        float size = getTextSize();
        float centerY = baseline - size * .55f;
        int count = compact ? 6 : 9;
        splash.setShader(null);
        splash.setStyle(Paint.Style.FILL);
        for (int i = 0; i < count; i++) {
            long period = 1500L + (i * 277L) % 900L;
            float phase = ((now + i * 389L) % period) / (float) period;
            float x = head - size * (.15f + phase * (1.3f + (i % 3) * .45f))
                    + (float) Math.sin(phase * 6.28f + i) * size * .22f;
            float y = centerY + phase * size * (1.0f + (i % 2) * .35f);
            float r = size * (.10f + (i % 3) * .03f);
            float fade = phase < .15f ? phase / .15f : (1f - phase) / .85f;
            int saved = canvas.save();
            canvas.translate(x, y);
            canvas.rotate(phase * 300f * (i % 2 == 0 ? 1f : -1f) + i * 47f);
            canvas.scale(.35f + .65f * Math.abs((float) Math.cos(phase * 9.4f + i)), 1f);   // tumbling
            petal.rewind();
            petal.moveTo(0f, r);
            petal.cubicTo(r * 1.1f, r * .2f, r * .7f, -r * .9f, r * .18f, -r);
            petal.lineTo(0f, -r * .72f);   // the little notch at the tip
            petal.lineTo(-r * .18f, -r);
            petal.cubicTo(-r * .7f, -r * .9f, -r * 1.1f, r * .2f, 0f, r);
            petal.close();
            splash.setColor(i % 3 == 0 ? 0xFFFFE3EF : i % 3 == 1 ? 0xFFFFB7D3 : 0xFFFF9CC4);
            splash.setAlpha(Math.round(235f * fade));
            canvas.drawPath(petal, splash);
            canvas.restoreToCount(saved);
        }
        drawHaloPink(canvas, head, baseline - size * .40f, size * (compact ? .45f : .62f));
    }

    private RadialGradient pinkHalo;

    private void drawHaloPink(Canvas canvas, float x, float y, float radius) {
        if (pinkHalo == null) pinkHalo = new RadialGradient(0f, 0f, 1f,
                new int[]{0xB0FFF0F6, 0x58FF8DBF, 0x00FF8DBF}, new float[]{0f, .45f, 1f}, Shader.TileMode.CLAMP);
        matrix.setScale(radius, radius);
        matrix.postTranslate(x, y);
        pinkHalo.setLocalMatrix(matrix);
        splash.setShader(pinkHalo);
        splash.setAlpha(255);
        canvas.drawCircle(x, y, radius, splash);
        splash.setShader(null);
    }

    /** Neon: a hot white spark with a short pink-cyan streak behind it. */
    private void drawNeonSpark(Canvas canvas, float head, float baseline, long now) {
        float size = getTextSize();
        float centerY = baseline - size * .40f;
        float flick = .8f + .2f * (float) Math.sin(now * .03);
        splash.setShader(null);
        splash.setStrokeCap(Paint.Cap.ROUND);
        splash.setStyle(Paint.Style.STROKE);
        splash.setStrokeWidth(size * .07f);
        splash.setColor(0xFFFF6BE0);
        splash.setAlpha(Math.round(120f * flick));
        canvas.drawLine(head - size * .9f, centerY, head, centerY, splash);
        splash.setStrokeWidth(size * .035f);
        splash.setColor(0xFFBFF8FF);
        splash.setAlpha(Math.round(230f * flick));
        canvas.drawLine(head - size * .55f, centerY, head, centerY, splash);
        splash.setStyle(Paint.Style.FILL);
        splash.setColor(0xFFFFFFFF);
        splash.setAlpha(Math.round(255f * flick));
        splash.setShadowLayer(size * .25f, 0f, 0f, 0xE000E5FF);
        canvas.drawCircle(head, centerY, size * .07f, splash);
        splash.clearShadowLayer();
    }

    private void drawDroplet(Canvas canvas, float x, float y, float radius, float vx, float vy, float opacity, int index) {
        int saved = canvas.save();
        canvas.translate(x, y);
        canvas.rotate((float) Math.toDegrees(Math.atan2(vy, vx)));
        drop.rewind();
        drop.moveTo(-radius * 2.5f, 0f);
        drop.cubicTo(-radius, -radius * .30f, -.3f * radius, -radius, radius * .5f, -radius);
        drop.cubicTo(radius * 2f, -radius, radius * 2f, radius, radius * .5f, radius);
        drop.cubicTo(-.3f * radius, radius, -radius, radius * .30f, -radius * 2.5f, 0f);
        drop.close();
        splash.setColor(index % 3 == 0 ? 0xFF8BEBFF : 0xFF35BBF4);
        splash.setAlpha(Math.round(235f * opacity));
        canvas.drawPath(drop, splash);
        splash.setColor(0xFFF5FFFF);
        splash.setAlpha(Math.round(245f * opacity));
        canvas.drawOval(0f, -radius * .67f, radius * 1.05f, -radius * .18f, splash);
        canvas.restoreToCount(saved);
    }
}
