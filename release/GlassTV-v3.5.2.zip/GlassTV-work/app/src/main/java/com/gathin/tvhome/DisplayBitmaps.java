package com.gathin.tvhome;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.io.File;

/** Decodes artwork at a bounded size, independent of the original file or TV panel resolution. */
final class DisplayBitmaps {
    private DisplayBitmaps() { }

    static Bitmap wallpaper(File file, int width, int height, int maximumLongEdge) {
        if (width <= 0 || height <= 0) return null;
        float ratio = Math.min(1f, maximumLongEdge / (float) Math.max(width, height));
        int targetWidth = Math.max(1, Math.round(width * ratio));
        int targetHeight = Math.max(1, Math.round(height * ratio));
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getPath(), options);
        if (options.outWidth <= 0 || options.outHeight <= 0) return null;
        int sample = 1;
        long decodeBudget = Math.max(262_144L, (long) targetWidth * targetHeight * 3L);
        while ((options.outWidth / (2 * sample) >= targetWidth
                && options.outHeight / (2 * sample) >= targetHeight)
                || (long) (options.outWidth / sample) * (options.outHeight / sample) > decodeBudget) {
            sample *= 2;
        }
        options.inSampleSize = sample;
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap source = BitmapFactory.decodeFile(file.getPath(), options);
        if (source == null) return null;
        if (source.getWidth() == targetWidth && source.getHeight() == targetHeight && !source.hasAlpha()) return source;
        float scale = Math.max(targetWidth / (float) source.getWidth(), targetHeight / (float) source.getHeight());
        float left = (targetWidth - source.getWidth() * scale) / 2f;
        float top = (targetHeight - source.getHeight() * scale) / 2f;
        try {
            Bitmap target = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(target);
            canvas.drawBitmap(source, null, new RectF(left, top, targetWidth - left, targetHeight - top),
                    new Paint(Paint.FILTER_BITMAP_FLAG));
            return target;
        } finally {
            source.recycle();
        }
    }

    /** Does not recycle the source artwork, which belongs to the media session. */
    static Bitmap artwork(Bitmap source, int maxEdge) {
        if (source == null) return null;
        int longEdge = Math.max(source.getWidth(), source.getHeight());
        if (longEdge <= maxEdge) return source;
        float ratio = maxEdge / (float) longEdge;
        try {
            return Bitmap.createScaledBitmap(source, Math.max(1, Math.round(source.getWidth() * ratio)),
                    Math.max(1, Math.round(source.getHeight() * ratio)), true);
        } catch (IllegalArgumentException | OutOfMemoryError ignored) {
            return null;
        }
    }
}
