package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Modal search: focus is trapped in the dialog; the underlying home is never rearranged. */
public final class ClassicSearchOverlay {
    private ClassicSearchOverlay() {}
    private static int dp(Activity a, int v) { return (int)(v*a.getResources().getDisplayMetrics().density+.5f); }
    private static GradientDrawable glass(int color, int radius, int stroke) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        d.setStroke(1,stroke); return d;
    }
    private static TextView button(Activity a,String name) {
        TextView v=new TextView(a); v.setText(name); v.setTextSize(16); v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER); v.setPadding(dp(a,14),dp(a,11),dp(a,14),dp(a,11));
        v.setFocusable(true); v.setClickable(true);
        v.setBackground(glass(0xAA303846,dp(a,14),0x77FFFFFF));
        v.setOnFocusChangeListener((view,focused)->view.setAlpha(focused?1f:.76f));
        return v;
    }
    public static void show(Activity a, View home) {
        if (a.isFinishing()) return;
        final View previous=a.getCurrentFocus();
        final Dialog dialog=new Dialog(a);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout panel=new LinearLayout(a); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(a,25),dp(a,22),dp(a,25),dp(a,22));
        panel.setBackground(glass(0xE9222C3B,dp(a,25),0x99FFFFFF));
        TextView title=new TextView(a); title.setText("Search"); title.setTextSize(23);
        title.setTextColor(Color.WHITE); panel.addView(title);
        EditText input=new EditText(a); input.setSingleLine(true); input.setTextSize(19);
        input.setTextColor(Color.WHITE); input.setHintTextColor(0xFFBBC4D0);
        input.setHint("Find apps, search web or in-app…");
        input.setBackground(glass(0xBB0C1622,dp(a,12),0x66FFFFFF));
        input.setPadding(dp(a,16),dp(a,12),dp(a,16),dp(a,12));
        LinearLayout.LayoutParams inp=new LinearLayout.LayoutParams(-1,dp(a,56));inp.topMargin=dp(a,16);panel.addView(input,inp);
        LinearLayout tabs=new LinearLayout(a);tabs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tabParams=new LinearLayout.LayoutParams(-1,-2);tabParams.topMargin=dp(a,14);panel.addView(tabs,tabParams);
        ScrollView scroll=new ScrollView(a); LinearLayout results=new LinearLayout(a);
        results.setOrientation(LinearLayout.VERTICAL);scroll.addView(results);
        LinearLayout.LayoutParams scrollParams=new LinearLayout.LayoutParams(-1,dp(a,245));scrollParams.topMargin=dp(a,12);
        panel.addView(scroll,scrollParams);
        final int[] mode={0};
        String[] names={"Apps","Web","In-App"};
        Runnable refresh=()->{
            results.removeAllViews();String q=input.getText().toString().trim();
            if(mode[0]==1){
                TextView search=button(a,"Search web: "+(q.isEmpty()?"Type a query":q));
                results.addView(search);search.setOnClickListener(v->{if(q.isEmpty()){input.requestFocus();return;}
                    try{a.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(q))));dialog.dismiss();}
                    catch(Exception e){Toast.makeText(a,"No web browser available",Toast.LENGTH_SHORT).show();}});
                return;
            }
            PackageManager pm=a.getPackageManager();
            Intent tv=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            Intent mobile=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps=new ArrayList<>(); apps.addAll(pm.queryIntentActivities(tv,0));apps.addAll(pm.queryIntentActivities(mobile,0));
            Collections.sort(apps,Comparator.comparing(r->String.valueOf(r.loadLabel(pm)).toLowerCase()));
            Set<String> seen=new HashSet<>();int count=0;
            for(ResolveInfo app:apps){
                if(app.activityInfo==null)continue;
                String pkg=app.activityInfo.packageName;
                if(!seen.add(pkg))continue;
                String name=String.valueOf(app.loadLabel(pm));
                if(!q.isEmpty()&&!name.toLowerCase().contains(q.toLowerCase())&&!pkg.toLowerCase().contains(q.toLowerCase()))continue;
                if(mode[0]==2 && q.isEmpty()) continue;
                TextView item=button(a,name+(mode[0]==2?"  ·  Search in app":""));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(a,6);results.addView(item,lp);
                item.setOnClickListener(v->{
                    try{
                        if(mode[0]==2){
                            Intent searchIntent=new Intent(Intent.ACTION_SEARCH);
                            searchIntent.setPackage(pkg);searchIntent.putExtra("query",q);
                            if(searchIntent.resolveActivity(pm)==null){
                                Toast.makeText(a,"This app does not expose search",Toast.LENGTH_SHORT).show();return;
                            }
                            a.startActivity(searchIntent);
                        } else {
                            Intent launch=pm.getLaunchIntentForPackage(pkg);
                            if(launch==null){launch=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
                                launch.setClassName(pkg,app.activityInfo.name);}
                            AppLaunch.start(a, launch, null);
                        }
                        dialog.dismiss();
                    }catch(Exception e){Toast.makeText(a,"Unable to open "+name,Toast.LENGTH_SHORT).show();}
                });
                if(++count>=60)break;
            }
            if(count==0){TextView empty=new TextView(a);empty.setText(mode[0]==2?"Type an app name, then choose an app supporting search":"No matching apps");
                empty.setTextColor(0xFFCCD5E0);empty.setPadding(8,12,8,12);results.addView(empty);}
        };
        for(int i=0;i<names.length;i++){
            final int index=i;TextView tab=button(a,names[i]);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);if(i>0)lp.leftMargin=dp(a,8);
            tabs.addView(tab,lp);tab.setOnClickListener(v->{mode[0]=index;refresh.run();input.requestFocus();});
        }
        input.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int af){}
            public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}
            public void afterTextChanged(Editable e){} });
        dialog.setContentView(panel);
        Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams p=w.getAttributes();p.width=Math.min(dp(a,680),a.getResources().getDisplayMetrics().widthPixels-dp(a,60));
            p.height=-2;p.gravity=Gravity.CENTER;p.dimAmount=.55f;w.setAttributes(p);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);}
        if(home!=null){home.animate().scaleX(.965f).scaleY(.965f).alpha(.55f).setDuration(220).start();}
        dialog.setOnDismissListener(d->{if(home!=null)home.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).start();
            if(previous!=null)previous.requestFocus();});
        refresh.run();dialog.show();input.requestFocus();
    }
}
