package com.gathin.tvhome;

import android.service.dreams.DreamService;

/** The Android screensaver shows the same StandbyView as the Home screensaver. */
public class ClockDream extends DreamService {

    private StandbyView view;

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setScreenBright(false);
        view = new StandbyView(this);
        setContentView(view);
    }

    @Override
    public void onDreamingStarted() {
        super.onDreamingStarted();
        if (view == null) return;
        view.setAlpha(0f);
        view.onShow();
        view.animate().alpha(1f).setDuration(1200).start();
    }

    @Override
    public void onDreamingStopped() {
        if (view != null) view.onHide();
        super.onDreamingStopped();
    }
}
