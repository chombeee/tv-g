package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Keeps the last crashes in a small file, so they can be read on the TV (Preferences > About > Crash Log)
 * or on a phone (the upload page's /api/crashlog) and sent on, instead of being lost when the app restarts.
 */
final class CrashLog {
    private CrashLog() { }

    private static final String FILE = "crash_log.txt";
    private static final int MAX_BYTES = 64 * 1024;
    private static final String MARK = "==== ";
    private static boolean installed;

    /** Records every uncaught exception in this process, then lets Android handle it as before. */
    static synchronized void install(Context c) {
        if (installed) return;
        installed = true;
        final Context app = c.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try { write(app, thread, error); } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private static final java.util.Map<String, Long> lastNote = new java.util.HashMap<>();
    private static final java.util.concurrent.ExecutorService io =
            java.util.concurrent.Executors.newSingleThreadExecutor();

    /**
     * Records an error that was caught and handled (the app keeps running). The same place is
     * written at most once a minute so a repeating error cannot churn the file.
     */
    static void note(Context c, String where, Throwable error) {
        android.util.Log.w("GlassTV", where, error);
        if (c == null || error == null) return;
        long now = System.currentTimeMillis();
        synchronized (lastNote) {
            Long last = lastNote.get(where);
            if (last != null && now - last < 60_000L) return;
            lastNote.put(where, now);
        }
        final Context app = c.getApplicationContext();
        io.execute(() -> {
            try { writeEntry(app, "AMARAN (bukan crash) · " + where, error); } catch (Throwable ignored) { }
        });
    }

    private static void write(Context c, Thread thread, Throwable error) throws Exception {
        writeEntry(c, "thread " + thread.getName(), error);
    }

    private static synchronized void writeEntry(Context c, String label, Throwable error) throws Exception {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        String version = "?";
        try {
            android.content.pm.PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            version = pi.versionName + " (" + pi.versionCode + ")";
        } catch (Exception ignored) { }
        pw.println(MARK + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(new Date())
                + " · " + version + " · Android " + Build.VERSION.RELEASE + " · " + Build.MANUFACTURER + " " + Build.MODEL
                + " · " + label);
        error.printStackTrace(pw);
        pw.println();
        pw.flush();
        String entry = sw.toString();
        // Newest first, trimmed to the size cap so the file never grows without end.
        String all = entry + read(c);
        if (all.length() > MAX_BYTES) {
            int cut = all.lastIndexOf(MARK, MAX_BYTES);
            all = all.substring(0, cut > 0 ? cut : MAX_BYTES);
        }
        try (FileOutputStream out = new FileOutputStream(new File(c.getFilesDir(), FILE), false)) {
            out.write(all.getBytes(StandardCharsets.UTF_8));
        }
    }

    static String read(Context c) {
        File f = new File(c.getFilesDir(), FILE);
        if (!f.exists()) return "";
        try {
            byte[] b = java.nio.file.Files.readAllBytes(f.toPath());
            return new String(b, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    static int count(Context c) {
        String s = read(c);
        int n = 0, at = 0;
        while ((at = s.indexOf(MARK, at)) >= 0) { n++; at += MARK.length(); }
        return n;
    }

    static void clear(Context c) {
        //noinspection ResultOfMethodCallIgnored
        new File(c.getFilesDir(), FILE).delete();
    }

    static void show(Activity a) {
        String text = read(a);
        TextView t = new TextView(a);
        t.setText(text.isEmpty() ? "Tiada crash direkodkan." : text);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(11);
        t.setTextColor(0xFFE6EAF1);
        t.setTextIsSelectable(false);
        int pad = Math.round(16 * a.getResources().getDisplayMetrics().density);
        t.setPadding(pad, pad, pad, pad);
        ScrollView scroll = new ScrollView(a);
        scroll.setFocusable(true);
        scroll.addView(t);
        new AlertDialog.Builder(a)
                .setTitle("Crash Log · lihat juga di telefon: /api/crashlog")
                .setView(scroll)
                .setPositiveButton("Tutup", null)
                .setNeutralButton("Kosongkan", (d, w) -> clear(a))
                .show();
    }
}
