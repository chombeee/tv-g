package com.gathin.tvhome;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.PathInterpolator;

/**
 * ColorOS-style app motion. An app grows out of the icon that opened it; with no icon it rises
 * and fades in from the centre. When the user comes back, Home settles from slightly larger.
 */
final class AppLaunch {
    private AppLaunch() { }

    private static boolean away;

    /** Transition for starting another app or screen from {@code from} (may be null). */
    static Bundle options(Context c, View from) {
        away = true;
        try {
            if (from != null && from.isAttachedToWindow() && from.getWidth() > 0 && from.getHeight() > 0) {
                return ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.getWidth(), from.getHeight()).toBundle();
            }
            return ActivityOptions.makeCustomAnimation(c, R.anim.app_open_enter, R.anim.app_open_exit).toBundle();
        } catch (Exception e) {
            return null;
        }
    }

    /** startActivity with the opening animation. Throws like startActivity does. */
    static void start(Context c, Intent i, View from) {
        c.startActivity(i, options(c, from));
    }

    /** Called from Home's onResume: plays the "back home" settle once per trip away. */
    static void onHomeResumed(Activity a) {
        if (!away) return;
        away = false;
        View root = a.findViewById(android.R.id.content);
        if (root == null) return;
        root.animate().cancel();
        // Scale only: the wallpaper never fades (it dims only behind the big lyrics card).
        root.setScaleX(1.07f);
        root.setScaleY(1.07f);
        root.setAlpha(1f);
        root.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(460)
                .setInterpolator(new PathInterpolator(0.2f, 0.85f, 0.25f, 1f)).withLayer().start();
    }

    /** Home is leaving for an app: zoom it in, like ColorOS (no fade). */
    static void zoomAway(Activity a) {
        View root = a.findViewById(android.R.id.content);
        if (root == null) return;
        root.animate().cancel();
        root.animate().scaleX(1.06f).scaleY(1.06f).setStartDelay(0).setDuration(260)
                .setInterpolator(new PathInterpolator(0.3f, 0f, 0.8f, 0.15f)).withLayer().start();
    }
}
