package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Works out where the TV is from its public IP (a TV has no GPS), so weather and prayer times follow it
 * when it moves house. City-level accuracy at best: some ISPs route through a city nearby.
 * A location picked by hand (AppLocationManager.setCustomLocation) turns this off until it is switched on again.
 */
final class AutoLocation {
    private static final String TAG = "TvHome.AutoLoc";
    private static final String KEY_AUTO = "auto_location";
    private static final String KEY_LAST = "auto_last_check";
    private static final String KEY_CITY = "auto_city";
    private static final long EVERY_MS = 6L * 60 * 60 * 1000;
    private static volatile boolean running;

    private AutoLocation() { }

    static boolean isAuto(Context c) {
        return c.getSharedPreferences(AppLocationManager.PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_AUTO, true);
    }

    static void setAuto(Context c, boolean on) {
        c.getSharedPreferences(AppLocationManager.PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO, on).apply();
    }

    /** City found by the last automatic lookup, or the saved location's name. */
    static String cityLabel(Context c) {
        SharedPreferences p = c.getSharedPreferences(AppLocationManager.PREFS_NAME, Context.MODE_PRIVATE);
        String city = p.getString(KEY_CITY, "");
        return city.isEmpty() ? AppLocationManager.getLocationName(c) : city;
    }

    static void refreshIfDue(Context c, Runnable onChanged) { refresh(c, false, onChanged); }

    static void refreshNow(Context c, Runnable onChanged) { refresh(c, true, onChanged); }

    private static void refresh(Context context, boolean force, Runnable onChanged) {
        final Context c = context.getApplicationContext();
        if (!force && !isAuto(c)) return;
        final SharedPreferences p = c.getSharedPreferences(AppLocationManager.PREFS_NAME, Context.MODE_PRIVATE);
        if (!force && System.currentTimeMillis() - p.getLong(KEY_LAST, 0) < EVERY_MS) return;
        if (running) return;
        running = true;
        new Thread(() -> {
            try {
                // 1) The device's own location, when allowed and the box has a provider (few TVs do).
                // 2) The public IP, from two services so one being down or blocked does not stop it.
                Fix fix = deviceFix(c);
                if (fix == null) fix = ipFix("https://ipwho.is/?fields=success,latitude,longitude,city,region,country_code", true);
                if (fix == null) fix = ipFix("https://ipapi.co/json/", false);
                if (fix == null) return;
                double lat = fix.lat, lon = fix.lon;
                String city = fix.city;
                boolean malaysia = "MY".equalsIgnoreCase(fix.country);
                p.edit().putLong(KEY_LAST, System.currentTimeMillis()).putString(KEY_CITY, city).apply();

                double moved = Math.abs(lat - AppLocationManager.getLatitude(c))
                        + Math.abs(lon - AppLocationManager.getLongitude(c));
                if (!force && moved < 0.08 && p.contains(AppLocationManager.KEY_LATITUDE)) return;

                // Weather uses the exact point; air quality and prayer zone need the nearest Malaysian station.
                AppLocationManager.Station near = malaysia ? AppLocationManager.findNearestStation(lat, lon) : null;
                SharedPreferences.Editor e = p.edit()
                        .putString(AppLocationManager.KEY_LATITUDE, String.valueOf(lat))
                        .putString(AppLocationManager.KEY_LONGITUDE, String.valueOf(lon));
                if (near != null) {
                    e.putString(AppLocationManager.KEY_STATION_ID, near.id)
                            .putString(AppLocationManager.KEY_LOCATION_NAME, near.name)
                            .putString(AppLocationManager.KEY_STATION_PLACE, near.place);
                }
                e.putBoolean(KEY_AUTO, true).apply();
                PrayerTimes.clearGpsZone(c);
                Log.i(TAG, "Location from IP: " + city + " [" + lat + ", " + lon + "] station="
                        + (near != null ? near.id : "-"));
                WeatherAirQuality.sync(c, null);
                PrayerTimes.sync(c, null);
                if (onChanged != null) new Handler(Looper.getMainLooper()).post(onChanged);
            } catch (Exception ex) {
                Log.w(TAG, "Location lookup failed: " + ex.getMessage());
            } finally {
                running = false;
            }
        }, "auto-location").start();
    }

    private static final class Fix {
        final double lat, lon;
        final String city, country;
        Fix(double lat, double lon, String city, String country) { this.lat = lat; this.lon = lon; this.city = city; this.country = country; }
    }

    /** Last known position from the device's providers, with the city from the Geocoder when it has one. */
    @SuppressWarnings("MissingPermission")
    private static Fix deviceFix(Context c) {
        boolean fine = c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        boolean coarse = c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) return null;
        try {
            android.location.LocationManager lm = (android.location.LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return null;
            android.location.Location best = null;
            for (String provider : lm.getProviders(true)) {
                android.location.Location l = lm.getLastKnownLocation(provider);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            // Older than a week is a different place as likely as not: let the IP decide.
            if (best == null || System.currentTimeMillis() - best.getTime() > 7L * 24 * 60 * 60 * 1000) return null;
            String city = "", country = "";
            try {
                java.util.List<android.location.Address> a = new android.location.Geocoder(c, java.util.Locale.getDefault())
                        .getFromLocation(best.getLatitude(), best.getLongitude(), 1);
                if (a != null && !a.isEmpty()) {
                    city = a.get(0).getLocality() != null ? a.get(0).getLocality() : String.valueOf(a.get(0).getSubAdminArea());
                    country = String.valueOf(a.get(0).getCountryCode());
                }
            } catch (Exception ignored) { }
            if (country.isEmpty() || "null".equals(country)) {
                // No Geocoder on many TV boxes: Malaysia's rough bounding box is enough to pick the station list.
                double la = best.getLatitude(), lo = best.getLongitude();
                if (la > 0.8 && la < 7.5 && lo > 99.5 && lo < 119.5) country = "MY";
            }
            return new Fix(best.getLatitude(), best.getLongitude(), city == null || "null".equals(city) ? "" : city, country);
        } catch (Exception e) {
            return null;
        }
    }

    /** Position of the public IP. {@code ipwho} selects that service's field names. */
    private static Fix ipFix(String url, boolean ipwho) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            conn.setRequestProperty("User-Agent", "GlassTV/3.2");
            if (conn.getResponseCode() != 200) return null;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null && sb.length() < 8000) sb.append(line);
            }
            JSONObject o = new JSONObject(sb.toString());
            if (ipwho && !o.optBoolean("success", false)) return null;
            if (!o.has("latitude") || !o.has("longitude")) return null;
            return new Fix(o.getDouble("latitude"), o.getDouble("longitude"), o.optString("city", ""),
                    o.optString("country_code", ""));
        } catch (Exception e) {
            Log.w(TAG, "IP lookup failed (" + url + "): " + e.getMessage());
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
