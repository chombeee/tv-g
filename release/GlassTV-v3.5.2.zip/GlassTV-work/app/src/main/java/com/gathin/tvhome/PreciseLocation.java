package com.gathin.tvhome;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Exact home location, down to the kampung. Mi Box has no GPS and the IP lookup only knows the
 * ISP's city, so the place is picked by name (typed on the TV) or on a map (on the phone).
 * Names come from OpenStreetMap (Nominatim); weather uses the exact point; the prayer zone comes
 * from waktusolat.app for that point, or the nearest JAKIM zone when that service is down.
 * All methods here do network work: call them off the main thread.
 */
final class PreciseLocation {
    private PreciseLocation() { }

    private static final String TAG = "GlassTV.Location";
    private static final String UA = "GlassTV/3.5 (Android TV launcher; github.com/chombeee/tv-g)";
    private static long lastNominatim;

    static final class Place {
        final String name, detail;
        final double lat, lon;
        Place(String name, String detail, double lat, double lon) {
            this.name = name; this.detail = detail; this.lat = lat; this.lon = lon;
        }
    }

    /** Places in Malaysia matching {@code query} ("Kg Sungai Ramal", "Taman Melati"...). */
    static List<Place> search(String query) throws Exception {
        String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=8"
                + "&countrycodes=my&accept-language=ms&q=" + URLEncoder.encode(query, "UTF-8");
        JSONArray arr = new JSONArray(get(url, true));
        List<Place> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            JSONObject a = o.optJSONObject("address");
            double lat = o.optDouble("lat"), lon = o.optDouble("lon");
            String name = a == null ? o.optString("name") : shortName(a);
            if (name.isEmpty()) name = o.optString("display_name");
            out.add(new Place(name, o.optString("display_name"), lat, lon));
        }
        return out;
    }

    /** "Kg Sungai Ramal, Kajang" for a point; null when OpenStreetMap does not answer. */
    static String nameAt(double lat, double lon) {
        try {
            String url = String.format(Locale.ROOT,
                    "https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=17"
                            + "&accept-language=ms&lat=%.6f&lon=%.6f", lat, lon);
            JSONObject o = new JSONObject(get(url, true));
            JSONObject a = o.optJSONObject("address");
            String name = a == null ? "" : shortName(a);
            return name.isEmpty() ? null : name;
        } catch (Exception e) {
            Log.w(TAG, "reverse geocode", e);
            return null;
        }
    }

    /** The smallest named place first (kampung, taman), then its town or district. */
    private static String shortName(JSONObject a) {
        String small = first(a, "hamlet", "village", "neighbourhood", "quarter", "suburb", "residential", "isolated_dwelling");
        String town = first(a, "town", "city", "municipality", "city_district", "county", "state_district", "state");
        if (small.isEmpty()) return town;
        if (town.isEmpty() || town.equalsIgnoreCase(small)) return small;
        return small + ", " + town;
    }

    private static String first(JSONObject a, String... keys) {
        for (String k : keys) {
            String v = a.optString(k, "").trim();
            if (!v.isEmpty()) return v;
        }
        return "";
    }

    /**
     * Saves the place: weather at the exact point, the nearest air-quality station, the prayer
     * zone for the point. Turns automatic (IP) location off. Returns the name used.
     */
    static String apply(Context context, String name, double lat, double lon) {
        Context c = context.getApplicationContext();
        if (name == null || name.trim().isEmpty()) name = nameAt(lat, lon);
        if (name == null || name.trim().isEmpty()) name = String.format(Locale.ROOT, "%.4f, %.4f", lat, lon);
        PrayerTimes.setGpsZone(c, zoneAt(lat, lon));
        AppLocationManager.Station near = AppLocationManager.findNearestStation(lat, lon);
        AppLocationManager.setCustomLocation(c, near.id, name.trim(), near.place, lat, lon);
        return name.trim();
    }

    /** JAKIM zone code for a point (waktusolat.app), or the nearest known zone offline. */
    static String zoneAt(double lat, double lon) {
        try {
            String url = String.format(Locale.ROOT, "https://api.waktusolat.app/zones/%.6f/%.6f", lat, lon);
            JSONObject o = new JSONObject(get(url, false));
            String zone = o.optString("zone", "").trim();
            if (zone.matches("[A-Z]{3}\\d{2}")) return zone;
        } catch (Exception e) {
            Log.w(TAG, "zone lookup", e);
        }
        PrayerTimes.PrayerZone best = null;
        double bestD = Double.MAX_VALUE;
        for (PrayerTimes.PrayerZone z : PrayerTimes.getPresetZones()) {
            double dLat = z.lat - lat, dLon = (z.lon - lon) * Math.cos(Math.toRadians(lat));
            double d = dLat * dLat + dLon * dLon;
            if (d < bestD) { bestD = d; best = z; }
        }
        return best == null ? "WLY01" : best.code;
    }

    private static String get(String url, boolean nominatim) throws Exception {
        if (nominatim) {
            // OpenStreetMap's rule: at most one request a second, with a real User-Agent.
            synchronized (PreciseLocation.class) {
                long wait = 1100L - (System.currentTimeMillis() - lastNominatim);
                if (wait > 0) Thread.sleep(wait);
                lastNominatim = System.currentTimeMillis();
            }
        }
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept", "application/json");
        try {
            int code = conn.getResponseCode();
            if (code != 200) throw new java.io.IOException("HTTP " + code);
            try (InputStream in = conn.getInputStream()) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                return b.toString("UTF-8");
            }
        } finally {
            conn.disconnect();
        }
    }
}
