package com.gathin.tvhome;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

/** Briefly carries the highlight from the end of the old lyric to the next line. */
final class LyricTrail extends Drawable {
    static final long DURATION_MS = 280L;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ViewGroup host;
    private final int[] origin = new int[2];
    private final int[] location = new int[2];
    private TextView from;
    private TextView to;
    private int color;
    private float progress;
    private ValueAnimator motion;

    LyricTrail(ViewGroup host) { this.host = host; }

    void play(TextView from, TextView to, int style) {
        if (!host.isShown() || !host.hasWindowFocus()
                || (android.os.Build.VERSION.SDK_INT >= 26 && !ValueAnimator.areAnimatorsEnabled())) return;
        if (motion != null) motion.cancel();
        this.from = from;
        this.to = to;
        color = LyricLineView.ACCENTS[style];
        progress = 0f;
        setBounds(0, 0, host.getWidth(), host.getHeight());
        host.getOverlay().add(this);
        motion = ValueAnimator.ofFloat(0f, 1f);
        motion.setDuration(DURATION_MS);
        motion.setInterpolator(new LinearInterpolator());
        motion.addUpdateListener(animation -> {
            progress = (float) animation.getAnimatedValue();
            invalidateSelf();
        });
        motion.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                host.getOverlay().remove(LyricTrail.this);
                LyricTrail.this.from = null;
                LyricTrail.this.to = null;
                motion = null;
            }
        });
        motion.start();
    }

    @Override public void draw(Canvas canvas) {
        if (from == null || to == null || !from.isAttachedToWindow() || !to.isAttachedToWindow()) return;
        Layout source = from.getLayout(), target = to.getLayout();
        if (source == null || target == null || source.getLineCount() == 0 || target.getLineCount() == 0) return;
        host.getLocationInWindow(origin);
        int last = source.getLineCount() - 1;
        from.getLocationInWindow(location);
        float x0 = location[0] - origin[0] + (from.getCompoundPaddingLeft() + source.getLineRight(last)) * from.getScaleX();
        float y0 = location[1] - origin[1] + (from.getTotalPaddingTop()
                + source.getLineBaseline(last) - from.getTextSize() * .32f) * from.getScaleY();
        to.getLocationInWindow(location);
        float x1 = location[0] - origin[0] + (to.getCompoundPaddingLeft() + target.getLineLeft(0)) * to.getScaleX();
        float y1 = location[1] - origin[1] + (to.getTotalPaddingTop()
                + target.getLineBaseline(0) - to.getTextSize() * .32f) * to.getScaleY();
        float radius = Math.max(1.5f, to.getTextSize() * 0.085f);
        float fade = Math.min(1f, (1f - progress) * 5f);
        for (int i = 7; i >= 0; i--) {
            float t = progress - i * 0.024f;
            if (t < 0f) continue;
            float x = x0 + (x1 - x0) * t;
            float y = y0 + (y1 - y0) * t + (float) Math.sin(Math.PI * t) * radius * 3f;
            float weight = (8f - i) / 8f;
            paint.setColor(color);
            paint.setAlpha(Math.round(190f * weight * fade));
            canvas.drawCircle(x, y, radius * weight * 1.4f, paint);
            if (i == 0) {
                paint.setColor(0xFFFFFAEE);
                paint.setAlpha(Math.round(240f * fade));
                canvas.drawCircle(x, y, radius * .62f, paint);
            }
        }
    }

    @Override public void setAlpha(int alpha) { }
    @Override public void setColorFilter(ColorFilter filter) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
