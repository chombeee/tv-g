package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.media.session.PlaybackState;
import android.os.SystemClock;
import android.text.Layout;
import android.text.TextUtils;
import android.widget.TextView;

/** Draws the selected effect only while this line is being sung. */
final class LyricLineView extends TextView {
    // Keep the saved Neon index. Emas takes over the old Pop slot.
    static final String[] STYLES = {"Api", "Emas", "Neon", "Ombak"};
    static final int[] ACCENTS = {0xFFFF7622, 0xFFFFCA56, 0xFF56E4FF, 0xFF5AAEFF};
    private final Paint spark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private PlaybackState playback;
    private long effectsAfter, start, end;
    private boolean compact;
    private int style;

    LyricLineView(Context context) { super(context); }

    void setCompact() { compact = true; }

    void waitForSlide(long durationMs) {
        effectsAfter = SystemClock.uptimeMillis() + durationMs;
        invalidate();
    }

    void show(String text, int style, PlaybackState playback, long start, long end) {
        if (!TextUtils.equals(getText(), text)) setText(text);
        this.style = style;
        this.playback = playback;
        this.start = start;
        this.end = end;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        boolean playing = playback != null && playback.getState() == PlaybackState.STATE_PLAYING
                && isShown() && hasWindowFocus() && getWindowVisibility() == VISIBLE;
        long position = playing ? NowPlaying.positionOf(playback) : -1L;
        boolean active = playing && position >= start && position < end;
        long now = SystemClock.uptimeMillis();
        Layout layout = getLayout();
        if (active && now >= effectsAfter && layout != null) {
            drawSweep(canvas, layout, (position - start) / (float) (end - start), now);
        } else {
            super.onDraw(canvas);
        }
        if (active) postInvalidateOnAnimation();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        invalidate();
    }

    private void drawSweep(Canvas canvas, Layout layout, float progress, long now) {
        float totalWidth = 0f;
        for (int i = 0; i < layout.getLineCount(); i++) totalWidth += layout.getLineWidth(i);
        float remaining = progress * totalWidth;
        int left = getCompoundPaddingLeft();
        int top = getTotalPaddingTop();
        Paint paint = getPaint();
        for (int i = 0; i < layout.getLineCount(); i++) {
            float x = layout.getLineLeft(i), width = layout.getLineWidth(i);
            if (width <= 0f) continue;
            float edge = x + Math.max(0f, Math.min(width, remaining));
            int saved = canvas.save();
            canvas.clipRect(0, top + layout.getLineTop(i), getWidth(), top + layout.getLineBottom(i));
            applySweep(paint, x, width, edge, remaining, now);
            super.onDraw(canvas);
            paint.setShader(null);
            paint.clearShadowLayer();
            canvas.restoreToCount(saved);
            if (style == 0 && remaining >= 0f && remaining < width) {
                drawSparks(canvas, left + edge, top + layout.getLineBaseline(i), now);
            }
            remaining -= width;
        }
    }

    private void applySweep(Paint paint, float x, float width, float edge, float remaining, long now) {
        float size = getTextSize();
        int accent = ACCENTS[style];
        if (style == 2) {
            float pulse = (float) Math.sin(now * 0.003);
            paint.setShader(new LinearGradient(edge - size * 1.4f, 0, edge + size * 1.4f, 0,
                    new int[]{accent, 0xFFFFFFFF, accent}, null, Shader.TileMode.CLAMP));
            paint.setShadowLayer(size * ((compact ? 0.075f : 0.12f) + 0.025f * pulse), 0, 0, 0xB600C7FF);
        } else if (remaining >= width) {
            paint.setShader(new LinearGradient(x, 0, x + width, 0, accent,
                    style == 0 ? 0xFFFFA832 : accent, Shader.TileMode.CLAMP));
        } else if (remaining >= 0f) {
            if (style == 3) {
                // A moving diagonal crest within the blue sweep; the glyphs stay still.
                float ripple = (float) Math.sin(now * .014) * size * .22f;
                paint.setShader(new LinearGradient(edge - size * 1.25f, -size, edge + size * .36f + ripple, 0,
                        new int[]{accent, 0xFF7DD4FF, 0xFFD9F6FF, getCurrentTextColor()},
                        new float[]{0f, .50f, .76f, 1f}, Shader.TileMode.CLAMP));
            } else {
                float band = style == 0 ? size * (compact ? .9f : 1.35f) : size * .58f;
                paint.setShader(new LinearGradient(edge - band, 0, edge + band * .24f, 0,
                        new int[]{accent, style == 0 ? 0xFFFFA832 : 0xFFFFDF89, 0xFFFFF7E3, getCurrentTextColor()},
                        new float[]{0f, .48f, .81f, 1f}, Shader.TileMode.CLAMP));
                if (style == 0) paint.setShadowLayer(size * (compact ? .06f : .12f), 0, 0, 0x90FF6715);
            }
        }
    }

    private void drawSparks(Canvas canvas, float x, float baseline, long now) {
        float size = getTextSize();
        int count = compact ? 5 : 12;
        for (int i = 0; i < count; i++) {
            float age = ((now + 53L * i) % 480L) / 480f;
            spark.setColor(i % 3 == 0 ? 0xFFFFF3C5 : 0xFFFF9327);
            spark.setAlpha((int) (225f * (1f - age)));
            canvas.drawCircle(x - age * size * (0.45f + (i % 4) * 0.21f),
                    baseline - size * (0.25f + age * (0.42f + (i % 3) * 0.19f)),
                    size * (0.031f + (i % 3) * 0.009f), spark);
        }
    }
}
