package com.gathin.tvhome;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Home widgets: glass cards for Prayer Times, Now Playing, Live Lyrics, Calendar and Recent Apps.
 * Each card refreshes only as often as its content changes (media every second, prayer every 30 s,
 * recent apps every minute, calendar once a day), and nothing refreshes while the shelf is hidden.
 */
final class ChombbWidgets {
    private static final String PREF = "chombb_widgets";
    static final String[] NAMES = {"Prayer Times", "Now Playing", "Live Lyrics", "Calendar", "Recent Apps"};
    static final int PRAYER = 0, MEDIA = 1, LYRICS = 2, CALENDAR = 3, RECENT = 4;
    /** Widget size: scales cards, text and icons together (width is 340 design px at 1.0). */
    private static final float[] SIZES = {0.85f, 1f, 1.2f, 1.4f};
    private static final String[] SIZE_NAMES = {"Kecil", "Sederhana", "Besar", "Sangat besar"};
    private static final int BASE_WIDTH = 340;

    private static volatile String lyricKey = "";
    private static volatile String lyricText = "";
    private static volatile boolean lyricsLoading;
    private static final java.util.Map<String, String> lyricCache = java.util.Collections.synchronizedMap(
            new java.util.LinkedHashMap<String, String>(32, 0.75f, true) {
                @Override protected boolean removeEldestEntry(java.util.Map.Entry<String, String> e) { return size() > 64; }
            });
    private static final Handler ui = new Handler(Looper.getMainLooper());

    static void invalidateMedia() { /* the shelf polls the active session; nothing to do here */ }

    // ---- preferences ----------------------------------------------------------------------------------

    static boolean enabled(Context c, int i) { return c.getSharedPreferences(PREF, 0).getBoolean("widget_" + i, false); }
    static void toggle(Context c, int i) { c.getSharedPreferences(PREF, 0).edit().putBoolean("widget_" + i, !enabled(c, i)).apply(); }
    static boolean anyEnabled(Context c) { for (int i = 0; i < NAMES.length; i++) if (enabled(c, i)) return true; return false; }

    /** Now Playing progress bar: 0 = Api (flame and sparks), 1 = Kepala bercahaya (soft glowing head). */
    static final String[] BAR_NAMES = {"Api", "Kepala bercahaya"};
    static int barStyle(Context c) {
        int v = c.getSharedPreferences(PREF, 0).getInt("np_bar_style", ProgressFlame.STYLE_GLOW);
        return v == ProgressFlame.STYLE_FLAME ? ProgressFlame.STYLE_FLAME : ProgressFlame.STYLE_GLOW;
    }
    static String barStyleName(Context c) { return BAR_NAMES[barStyle(c)]; }
    static void changeBarStyle(Context c) {
        c.getSharedPreferences(PREF, 0).edit().putInt("np_bar_style", barStyle(c) == 0 ? 1 : 0).apply();
    }

    private static int sizeIndex(Context c) {
        int v = c.getSharedPreferences(PREF, 0).getInt("size_index", 1);
        return Math.max(0, Math.min(SIZES.length - 1, v));
    }
    static float sizeFactor(Context c) { return SIZES[sizeIndex(c)]; }
    /** Card width in pixels on this screen (designed against 1920x1080). */
    static int widthPx(Context c) { return Math.round(BASE_WIDTH * sizeFactor(c) * scale(c)); }
    static String widthName(Context c) { return SIZE_NAMES[sizeIndex(c)]; }
    static void changeWidth(Context c) {
        c.getSharedPreferences(PREF, 0).edit().putInt("size_index", (sizeIndex(c) + 1) % SIZES.length).apply();
    }

    static int lyricStyle(Context c) {
        int style = c.getSharedPreferences(PREF, 0).getInt("lyric_style", 0);
        return style >= 0 && style < LyricLineView.STYLES.length ? style : 0;
    }

    static void setLyricStyle(Context c, int style) {
        c.getSharedPreferences(PREF, 0).edit().putInt("lyric_style", style).apply();
    }

    static int order(Context c, int i) { return c.getSharedPreferences(PREF, 0).getInt("order_" + i, i); }
    static void move(Context c, int i, boolean up) {
        int position = order(c, i), target = position + (up ? -1 : 1);
        if (target < 0 || target >= NAMES.length) return;
        SharedPreferences.Editor e = c.getSharedPreferences(PREF, 0).edit();
        for (int j = 0; j < NAMES.length; j++) if (j != i && order(c, j) == target) e.putInt("order_" + j, position);
        e.putInt("order_" + i, target).apply();
    }
    /** Enabled widgets in the order the user set. */
    static List<Integer> ordered(Context c) {
        List<Integer> out = new ArrayList<>();
        for (int pos = 0; pos < NAMES.length; pos++)
            for (int i = 0; i < NAMES.length; i++)
                if (order(c, i) == pos && enabled(c, i)) out.add(i);
        return out;
    }

    static float scale(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        return Math.min(dm.widthPixels / 1920f, dm.heightPixels / 1080f);
    }

    // ---- cards ------------------------------------------------------------------------------------------

    /** Per-card views and refresh bookkeeping, kept as the card's tag. */
    static final class Card {
        final int kind;
        long nextSlow;
        TextView title, line1, line2, line3;
        GradientDrawable bg;
        float s;
        ImageView art;
        ProgressFlame progress;
        LinearLayout body;
        int shownDay = -1;
        String shownKey;
        TextView timeNow, timeTotal;   // MEDIA: elapsed (left) and total (right) time
        View[] eq;              // MEDIA: equalizer bars that dance while a song plays
        android.animation.ObjectAnimator[] eqAnim;
        float shownFraction;
        View root;              // the whole card
        int tint = GlassStyle.tint(0x73101419);
        boolean wasPlaying = true;
        String lyricSong, displayedLyric;
        Card(int kind) { this.kind = kind; }
    }

    static View card(Activity a, int kind) { return card(a, kind, sizeFactor(a)); }

    /** Card width at a given size factor. */
    static int widthPx(Context c, float factor) { return Math.round(BASE_WIDTH * factor * scale(c)); }

    /** A card at {@code factor} (the home screen shrinks cards that would not fit beside the dock). */
    static View card(Activity a, int kind, float factor) {
        float s = scale(a) * factor;
        Typeface face = font(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int ph = Math.round(22 * s), pv = Math.round(18 * s);
        box.setPadding(ph, pv, ph, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(GlassStyle.tint(0x73101419));
        bg.setCornerRadius(28 * s);
        bg.setStroke(Math.max(1, Math.round(1.5f * s)), 0x2EFFFFFF);
        box.setBackground(bg);
        box.setFocusable(false);
        Card c = new Card(kind);
        c.bg = bg;
        c.s = s;
        box.setTag(c);
        c.root = box;

        // Header: small icon and a spaced caption
        LinearLayout head = new LinearLayout(a);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView glyph = new ImageView(a);
        glyph.setImageResource(kind == PRAYER ? R.drawable.ic_mosque : kind == CALENDAR ? R.drawable.ic_update
                : kind == RECENT ? R.drawable.ic_material_apps : R.drawable.ic_sound);
        glyph.setColorFilter(0xB3FFFFFF);
        int g = Math.round(20 * s);
        head.addView(glyph, new LinearLayout.LayoutParams(g, g));
        TextView cap = text(a, face, 16 * s, 0xB3FFFFFF, 600);
        cap.setLetterSpacing(0.12f);
        cap.setText(kind == PRAYER ? "WAKTU SOLAT" : kind == MEDIA ? "NOW PLAYING" : kind == LYRICS ? "LIRIK"
                : kind == CALENDAR ? "KALENDAR" : "BARU DIBUKA");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
        clp.leftMargin = Math.round(10 * s);
        head.addView(cap, clp);
        if (kind == MEDIA) {
            // Three little bars next to the caption: they dance while music plays and rest when paused.
            LinearLayout bars = new LinearLayout(a);
            bars.setOrientation(LinearLayout.HORIZONTAL);
            bars.setGravity(Gravity.BOTTOM);
            c.eq = new View[3];
            c.eqAnim = new android.animation.ObjectAnimator[3];
            int bw = Math.max(2, Math.round(3.5f * s)), bh = Math.round(16 * s);
            long[] dur = {520, 380, 460};
            for (int i = 0; i < 3; i++) {
                View b = new View(a);
                GradientDrawable bd = new GradientDrawable();
                bd.setColor(0xCCFFFFFF);
                bd.setCornerRadius(bw);
                b.setBackground(bd);
                b.setPivotY(bh);
                b.setScaleY(0.3f);
                LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(bw, bh);
                bl.leftMargin = Math.round(2.5f * s);
                bars.addView(b, bl);
                c.eq[i] = b;
                android.animation.ObjectAnimator an = android.animation.ObjectAnimator.ofFloat(b, View.SCALE_Y, 0.25f, 1f);
                an.setDuration(dur[i]);
                an.setRepeatMode(android.animation.ValueAnimator.REVERSE);
                an.setRepeatCount(android.animation.ValueAnimator.INFINITE);
                an.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
                c.eqAnim[i] = an;
            }
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-2, bh);
            blp.leftMargin = Math.round(12 * s);
            head.addView(bars, blp);
        }
        box.addView(head);
        if (kind == CALENDAR) c.title = cap;   // the caption becomes the month name

        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-1, -2);
        gap.topMargin = Math.round(10 * s);
        switch (kind) {
            case PRAYER: {
                c.line1 = text(a, face, 30 * s, Color.WHITE, 600);
                c.line2 = text(a, face, 19 * s, 0xB3FFFFFF, 400);
                box.addView(c.line1, gap);
                box.addView(c.line2);
                break;
            }
            case MEDIA: {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                c.art = new ImageView(a);
                c.art.setScaleType(ImageView.ScaleType.CENTER_CROP);
                final float r = 14 * s;
                c.art.setOutlineProvider(new ViewOutlineProvider() {
                    @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r); }
                });
                c.art.setClipToOutline(true);
                GradientDrawable artBg = new GradientDrawable();
                artBg.setColor(0x33FFFFFF);
                artBg.setCornerRadius(r);
                c.art.setBackground(artBg);
                int as = Math.round(68 * s);
                row.addView(c.art, new LinearLayout.LayoutParams(as, as));
                LinearLayout col = new LinearLayout(a);
                col.setOrientation(LinearLayout.VERTICAL);
                c.line1 = text(a, face, 23 * s, Color.WHITE, 600);
                c.line2 = text(a, face, 18 * s, 0xB3FFFFFF, 400);
                col.addView(c.line1);
                col.addView(c.line2);
                LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, -2, 1);
                colLp.leftMargin = Math.round(14 * s);
                row.addView(col, colLp);
                box.addView(row, gap);
                c.progress = new ProgressFlame(a, s, barStyle(a));
                // The view is taller than the bar so the flame and sparks can rise above and below it.
                int fp = Math.round(c.progress.padding()), fb = Math.max(2, Math.round(c.progress.barHeight()));
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, fb + 2 * fp);
                tlp.topMargin = Math.round(14 * s) - fp;
                tlp.bottomMargin = -fp;
                box.setClipChildren(false);
                box.addView(c.progress, tlp);
                // Elapsed time on the left, song length on the right.
                LinearLayout times = new LinearLayout(a);
                times.setOrientation(LinearLayout.HORIZONTAL);
                c.timeNow = text(a, face, 14 * s, 0xB3FFFFFF, 500);
                c.timeTotal = text(a, face, 14 * s, 0xB3FFFFFF, 500);
                c.timeNow.setText("0:00");
                c.timeTotal.setText("0:00");
                c.timeTotal.setGravity(Gravity.END);
                times.addView(c.timeNow, new LinearLayout.LayoutParams(0, -2, 1));
                times.addView(c.timeTotal, new LinearLayout.LayoutParams(0, -2, 1));
                LinearLayout.LayoutParams timesLp = new LinearLayout.LayoutParams(-1, -2);
                timesLp.topMargin = Math.round(6 * s);
                box.addView(times, timesLp);
                break;
            }
            case LYRICS: {
                c.line1 = text(a, face, 18 * s, 0xB3FFFFFF, 400);
                c.line2 = formatText(new LyricLineView(a), face, 25 * s, Color.WHITE, 650);
                ((LyricLineView) c.line2).setCompact();
                c.line2.setPadding(Math.round(5 * s), Math.round(4 * s), Math.round(5 * s), Math.round(4 * s));
                c.line1.setTextColor(Color.WHITE);
                c.line1.setAlpha(0.72f);
                box.setClipChildren(false);
                c.line3 = text(a, face, 18 * s, Color.WHITE, 400);
                for (TextView t : new TextView[]{c.line1, c.line2, c.line3}) {
                    t.setGravity(Gravity.CENTER);
                    t.setSingleLine(false);
                    t.setMaxLines(2);
                    t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
                }
                box.addView(c.line1, gap);
                LinearLayout.LayoutParams mid = new LinearLayout.LayoutParams(-1, -2);
                mid.topMargin = mid.bottomMargin = Math.round(6 * s);
                box.addView(c.line2, mid);
                box.addView(c.line3);
                break;
            }
            case CALENDAR:
            case RECENT: {
                c.body = new LinearLayout(a);
                c.body.setOrientation(kind == CALENDAR ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
                box.addView(c.body, gap);
                break;
            }
        }
        return box;
    }

    /** Refreshes a card. Slow content (prayer, calendar, recent apps) only when due or when {@code force}. */
    static void update(Activity a, View view, boolean force) {
        if (!(view.getTag() instanceof Card)) return;
        Card c = (Card) view.getTag();
        long now = android.os.SystemClock.elapsedRealtime();
        boolean slowDue = force || now >= c.nextSlow;
        switch (c.kind) {
            case PRAYER:
                if (!slowDue) return;
                c.nextSlow = now + 30_000;
                String[] p = PrayerTimes.getNextPrayerCountdown(a).split("\n");
                c.line1.setText(p.length > 0 ? p[0].replaceAll("\\s{2,}", "  ·  ") : "");
                c.line2.setText(p.length > 1 ? p[1].replace("remaining", "lagi") : "");
                break;
            case MEDIA:
                updateMedia(a, c);
                break;
            case LYRICS:
                updateLyrics(a, c);
                break;
            case CALENDAR: {
                Calendar cal = Calendar.getInstance();
                int day = cal.get(Calendar.DAY_OF_YEAR);
                if (!force && day == c.shownDay) return;
                c.shownDay = day;
                buildCalendar(a, c, cal);
                break;
            }
            case RECENT:
                if (!slowDue) return;
                c.nextSlow = now + 60_000;
                buildRecent(a, c);
                break;
        }
    }

    private static void idleMedia(Card c) {
        c.timeNow.setText("00:00");
        c.timeTotal.setText("--:--");
    }

    private static void updateMedia(Activity a, Card c) {
        if (!NowPlaying.hasAccess(a) && !NowPlaying.ensureAccess(a)) {
            c.line1.setText("Perlu Notification Access");
            c.line2.setText("Preferences > Widgets > Notification Access");
            c.progress.setProgress(0f, 0L, false, true);
            idleMedia(c);
            return;
        }
        MediaController m = NowPlaying.active(a);
        MediaMetadata md = m == null ? null : m.getMetadata();
        if (md == null) {
            c.line1.setText("Tiada muzik dimainkan");
            c.line2.setText("");
            c.art.setImageDrawable(null);
            c.shownKey = null;
            c.progress.setProgress(0f, 0L, false, true);
            idleMedia(c);
            return;
        }
        String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        String key = title + "|" + artist;
        if (!key.equals(c.shownKey)) {
            c.shownKey = key;
            c.line1.setText(title == null ? "" : title);
            c.line2.setText(artist == null ? "" : artist);
            Bitmap art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
            c.art.setImageBitmap(art);
            // Island-style change of song: the art pops in with a spring, text slides up and fades in,
            // the card breathes once and takes the colour of the new cover.
            c.art.setScaleX(0.7f);
            c.art.setScaleY(0.7f);
            c.art.setAlpha(0.2f);
            c.art.animate().alpha(1f).setDuration(320).start();
            springScale(c.art, 1f, 220f, 0.55f);
            for (TextView tv : new TextView[]{c.line1, c.line2}) {
                tv.setTranslationY(14f * c.s);
                tv.setAlpha(0f);
                tv.animate().translationY(0f).alpha(1f).setDuration(420)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator(2f)).start();
            }
            if (c.root != null) {
                c.root.setPivotX(c.root.getWidth() / 2f);
                c.root.setPivotY(c.root.getHeight() / 2f);
                float rest = c.root.hasFocus() ? 1.04f : 1f;
                c.root.setScaleX(rest + 0.035f);
                c.root.setScaleY(rest + 0.035f);
                springScale(c.root, rest, 260f, 0.45f);
            }
            int tint = art == null ? 0 : artTint(art);
            final int from = c.tint, to = tint != 0 ? tint : GlassStyle.tint(0x73101419);
            c.tint = to;
            android.animation.ValueAnimator va = android.animation.ValueAnimator.ofObject(new android.animation.ArgbEvaluator(), from, to);
            va.setDuration(700);
            va.addUpdateListener(an -> c.bg.setColor((Integer) an.getAnimatedValue()));
            va.start();
        }
        long dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION);
        float f = dur > 0 ? Math.min(1f, NowPlaying.position(m) / (float) dur) : 0f;
        // Glide to the new position instead of jumping: the bar moves continuously between refreshes.
        PlaybackState st = m.getPlaybackState();
        boolean playing = st != null && st.getState() == PlaybackState.STATE_PLAYING;
        c.progress.setProgress(f, dur, playing, f < c.shownFraction - 0.05f);   // snaps on a new song or a seek back
        c.timeNow.setText(clock(NowPlaying.position(m)));
        c.timeTotal.setText(dur > 0 ? clock(dur) : "--:--");
        c.shownFraction = f;
        c.line1.setAlpha(playing ? 1f : 0.6f);
        if (c.wasPlaying != playing) {
            c.wasPlaying = playing;
            springScale(c.art, playing ? 1f : 0.88f, 300f, 0.5f);   // art shrinks on pause, springs back on play
        }
        if (c.eqAnim != null) {
            for (int i = 0; i < c.eqAnim.length; i++) {
                android.animation.ObjectAnimator an = c.eqAnim[i];
                if (playing && !an.isStarted()) an.start();
                else if (!playing && an.isStarted()) { an.cancel(); c.eq[i].animate().scaleY(0.3f).setDuration(200).start(); }
            }
        }
    }

    // ---- Now Playing controls (Spotify, YouTube Music...) --------------------------------------------

    /**
     * Saves / likes the current song. Spotify and most players publish a custom action for it (named like
     * "Add to Liked Songs", "Like", "Save"); the first one that looks like that is pressed. Returns false
     * when the app offers none.
     */
    static boolean mediaSave(Activity a) {
        MediaController m = NowPlaying.active(a);
        PlaybackState st = m == null ? null : m.getPlaybackState();
        if (st == null || st.getCustomActions() == null) return false;
        PlaybackState.CustomAction best = null;
        for (PlaybackState.CustomAction ca : st.getCustomActions()) {
            String n = (ca.getName() + " " + ca.getAction()).toLowerCase(Locale.ROOT);
            if (n.contains("dislike") || n.contains("thumb down") || n.contains("thumb_down")
                    || n.contains("unlike") || n.contains("unsave") || n.contains("remove")) continue;
            if (n.contains("like") || n.contains("save") || n.contains("favor") || n.contains("heart")
                    || n.contains("thumb up") || n.contains("thumb_up")) { best = ca; break; }
        }
        if (best == null) return false;
        m.getTransportControls().sendCustomAction(best, null);
        return true;
    }

    /** Tells the person the song was saved (or that the player has no Save button). No text lives on the card itself. */
    static void popHeart(View card, boolean ok) {
        android.widget.Toast.makeText(card.getContext(),
                ok ? "♥  Disimpan / dikemas kini" : "Pemain ini tiada butang Simpan",
                android.widget.Toast.LENGTH_SHORT).show();
    }

    private static String clock(long ms) {
        long seconds = Math.max(0, ms / 1000);
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private static void updateLyrics(Activity a, Card c) {
        MediaController m = NowPlaying.active(a);
        MediaMetadata md = m == null ? null : m.getMetadata();
        String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        String before = "", current, next = "";
        PlaybackState playback = null;
        long start = 0L, end = 0L;
        if (title == null || title.isEmpty()) {
            current = NowPlaying.hasAccess(a) ? "Mainkan lagu untuk lirik" : "Perlu Notification Access";
        } else {
            requestFor(m);
            ensureParsed();
            playback = m.getPlaybackState();
            long position = NowPlaying.positionOf(playback);
            int index = activeLine(position);
            if (lyricsLoading) current = "Mencari lirik…";
            else if (parsedLines.length == 0) {
                String plain = plainLyrics();
                current = plain.isEmpty() ? "Lirik tiada" : plain;
            } else if (index < 0) {
                current = parsedLines[0];
                next = parsedLines.length > 1 ? parsedLines[1] : "";
            } else {
                current = parsedLines[index];
                before = index > 0 ? parsedLines[index - 1] : "";
                next = index + 1 < parsedLines.length ? parsedLines[index + 1] : "";
                start = parsedTimes[index];
                end = lineEnd(start, index + 1 < parsedTimes.length ? parsedTimes[index + 1]
                        : md.getLong(MediaMetadata.METADATA_KEY_DURATION));
            }
        }
        String song = m == null || md == null ? null : m.getPackageName() + "|" + title + "|"
                + md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        boolean advancing = start > 0 && song != null && song.equals(c.lyricSong)
                && !current.equals(c.displayedLyric) && before.equals(c.displayedLyric)
                && android.text.TextUtils.equals(c.line3.getText(), current)
                && c.line2.isLaidOut() && c.line2.isShown();
        float activeY = c.line2.getY() + c.line2.getHeight() / 2f;
        float nextY = c.line3.getY() + c.line3.getHeight() / 2f;
        if (!android.text.TextUtils.equals(c.line1.getText(), before)) c.line1.setText(before);
        if (!android.text.TextUtils.equals(c.line3.getText(), next)) c.line3.setText(next);
        c.line2.setTextColor(end > start && NowPlaying.positionOf(playback) >= end ? 0xB3FFFFFF : Color.WHITE);
        LyricLineView active = (LyricLineView) c.line2;
        if (advancing) active.waitForSlide(240L);
        active.show(current, lyricStyle(a), playback, start, end);
        c.displayedLyric = current;
        c.lyricSong = song;
        if (advancing) {
            androidx.core.view.OneShotPreDrawListener.add(active, () -> {
                float ratio = c.line1.getTextSize() / active.getTextSize();
                slideLyric(c.line1, activeY, 1f / ratio, 1f, 0.72f);
                slideLyric(active, nextY, ratio, 1f, 1f);
                slideLyric(c.line3, c.line3.getTop() + c.line3.getHeight() * 1.25f, 1f, 0f, 1f);
            });
        }
    }

    private static void slideLyric(View view, float fromCenter, float fromScale, float fromAlpha, float alpha) {
        view.animate().cancel();
        view.setTranslationY(fromCenter - (view.getTop() + view.getHeight() / 2f));
        view.setScaleX(fromScale);
        view.setScaleY(fromScale);
        view.setAlpha(fromAlpha);
        view.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(alpha).setDuration(300)
                .setInterpolator(new android.view.animation.PathInterpolator(0.22f, 0.64f, 0.30f, 1f)).start();
    }

    // Leave extended instrumental gaps and the outro still.
    static long lineEnd(long start, long next) {
        return next > start && next - start < 9000L ? next : start + 5500L;
    }

    private static void buildCalendar(Activity a, Card c, Calendar today) {
        float s = c.s;
        Typeface face = font(a);
        c.title.setText(new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(today.getTime()).toUpperCase(Locale.getDefault()));
        c.body.removeAllViews();
        String[] heads = {"I", "S", "R", "K", "J", "S", "A"};
        LinearLayout hr = new LinearLayout(a);
        for (String h : heads) {
            TextView t = text(a, face, 15 * s, 0x80FFFFFF, 500);
            t.setText(h);
            t.setGravity(Gravity.CENTER);
            hr.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        }
        c.body.addView(hr);
        Calendar first = (Calendar) today.clone();
        first.set(Calendar.DAY_OF_MONTH, 1);
        int offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7;   // Monday first
        int days = first.getActualMaximum(Calendar.DAY_OF_MONTH), todayN = today.get(Calendar.DAY_OF_MONTH);
        int cell = Math.round(34 * s);
        LinearLayout row = null;
        for (int i = 0; i < offset + days; i++) {
            if (i % 7 == 0) {
                row = new LinearLayout(a);
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, cell);
                rl.topMargin = Math.round(2 * s);
                c.body.addView(row, rl);
            }
            FrameLayout slot = new FrameLayout(a);
            if (i >= offset) {
                int d = i - offset + 1;
                TextView t = text(a, face, 17 * s, d == todayN ? 0xFF111418 : 0xE6FFFFFF, d == todayN ? 700 : 400);
                t.setText(String.valueOf(d));
                t.setGravity(Gravity.CENTER);
                if (d == todayN) {
                    GradientDrawable dot = new GradientDrawable();
                    dot.setShape(GradientDrawable.OVAL);
                    dot.setColor(Color.WHITE);
                    t.setBackground(dot);
                }
                slot.addView(t, new FrameLayout.LayoutParams(cell, cell, Gravity.CENTER));
            }
            row.addView(slot, new LinearLayout.LayoutParams(0, -1, 1));
        }
        // complete the last row so the columns stay aligned
        while (row != null && row.getChildCount() < 7) row.addView(new View(a), new LinearLayout.LayoutParams(0, -1, 1));
    }

    private static void buildRecent(Activity a, Card c) {
        float s = c.s;
        c.body.removeAllViews();
        List<RecentAppItem> apps;
        try { apps = RecentAppsManager.getRecentApps(a); } catch (Exception e) { apps = new ArrayList<>(); }
        int shown = 0, size = Math.round(52 * s);
        for (RecentAppItem item : apps) {
            if (item.isCloseAll || item.icon == null) continue;
            ImageView icon = new ImageView(a);
            icon.setImageDrawable(item.icon);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            if (shown > 0) lp.leftMargin = Math.round(12 * s);
            c.body.addView(icon, lp);
            if (++shown >= 5) break;
        }
        if (shown == 0) {
            TextView t = text(a, font(a), 19 * s, 0xB3FFFFFF, 400);
            t.setText("Belum ada app dibuka");
            c.body.addView(t);
        }
    }

    /** Makes a card reachable with the remote: white ring and a small lift when focused, OK runs {@code click}. */
    /** Soft ColorOS-style spring on both scale axes (no fixed duration; it settles by itself). */
    static void springScale(View v, float target, float stiffness, float damping) {
        androidx.dynamicanimation.animation.SpringAnimation[] running =
                (androidx.dynamicanimation.animation.SpringAnimation[]) v.getTag(R.id.focus_scale_springs);
        if (running == null) {
            running = new androidx.dynamicanimation.animation.SpringAnimation[]{
                    new androidx.dynamicanimation.animation.SpringAnimation(v,
                            androidx.dynamicanimation.animation.DynamicAnimation.SCALE_X, target),
                    new androidx.dynamicanimation.animation.SpringAnimation(v,
                            androidx.dynamicanimation.animation.DynamicAnimation.SCALE_Y, target)};
            v.setTag(R.id.focus_scale_springs, running);
        }
        for (androidx.dynamicanimation.animation.SpringAnimation spring : running) {
            spring.getSpring().setStiffness(stiffness);
            spring.getSpring().setDampingRatio(damping);
            spring.animateToFinalPosition(target);
        }
    }

    /** Average colour of the art, lifted and darkened a little so white text stays readable on it. */
    static int artTint(Bitmap art) {
        try {
            Bitmap one = Bitmap.createScaledBitmap(art, 1, 1, true);
            int p = one.getPixel(0, 0);
            float[] hsv = new float[3];
            android.graphics.Color.colorToHSV(p, hsv);
            hsv[1] = Math.min(1f, hsv[1] * 1.15f + 0.05f);
            hsv[2] = Math.min(0.42f, Math.max(0.22f, hsv[2] * 0.55f));
            return android.graphics.Color.HSVToColor(0xB8, hsv);
        } catch (Exception e) { return 0; }
    }

    static void focusable(View card) {
        if (!(card.getTag() instanceof Card)) return;
        final Card c = (Card) card.getTag();
        card.setFocusable(true);
        card.setOnFocusChangeListener((v, f) -> {
            c.bg.setStroke(Math.max(1, Math.round((f ? 3f : 1.5f) * c.s)), f ? 0xFFFFFFFF : 0x2EFFFFFF);
            springScale(v, f ? 1.04f : 1f, 340f, 0.77f);
        });
    }

    static void interactive(View card, Runnable click) {
        focusable(card);
        card.setOnClickListener(v -> { SoundEffects.playSelect(); click.run(); });
    }

    static int kindOf(View card) { return card.getTag() instanceof Card ? ((Card) card.getTag()).kind : -1; }

    // ---- for the full-screen lyrics view ---------------------------------------------------------------

    /** Starts (or reuses) the lyrics lookup for the session's song. */
    static void requestFor(MediaController m) {
        MediaMetadata md = m == null ? null : m.getMetadata();
        if (md == null) return;
        String title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
        if (title == null || title.isEmpty()) return;
        String artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        String album = md.getString(MediaMetadata.METADATA_KEY_ALBUM);
        requestLyrics(title, artist == null ? "" : artist, album == null ? "" : album,
                md.getLong(MediaMetadata.METADATA_KEY_DURATION) / 1000);
    }

    static boolean lyricsLoading() { return lyricsLoading; }

    /** Every synced line of the current song, or null when the lyrics are plain text or missing. */
    static String[] syncedLines() {
        ensureParsed();
        return parsedLines.length > 0 ? parsedLines : null;
    }

    /** Start time (ms) of every synced line, matching {@link #syncedLines()}. */
    static long[] syncedTimes() {
        ensureParsed();
        return parsedTimes;
    }

    /** Plain (unsynced) lyrics, or "" when there are none. */
    static String plainLyrics() {
        String text = lyricText;
        return text.contains("[") ? "" : text;
    }

    private static int activeLine(long position) {
        int active = -1;
        for (int i = 0; i < parsedTimes.length; i++) {
            if (parsedTimes[i] > position) break;
            active = i;
        }
        return active;
    }

    private static TextView text(Context c, Typeface face, float px, int color, int weight) {
        return formatText(new TextView(c), face, px, color, weight);
    }

    private static TextView formatText(TextView t, Typeface face, float px, int color, int weight) {
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        t.setTextColor(color);
        t.setTypeface(face);
        try { t.setFontVariationSettings("'wght' " + weight); } catch (Exception ignored) { }
        t.setIncludeFontPadding(false);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }

    private static Typeface cachedFace;
    private static Typeface font(Context c) {
        if (cachedFace == null) {
            try { cachedFace = c.getResources().getFont(R.font.outfit); } catch (Exception e) { cachedFace = Typeface.DEFAULT; }
        }
        return cachedFace;
    }

    // ---- lyrics (LRCLIB) ----------------------------------------------------------------------------

    private static void requestLyrics(String title, String artist, String album, long durationSec) {
        final String key = title + "|" + artist;
        if (key.equals(lyricKey)) return;
        String hit = lyricCache.get(key);
        if (hit != null) { lyricKey = key; lyricText = hit; lyricsLoading = false; return; }
        lyricKey = key; lyricText = ""; lyricsLoading = true;
        new Thread(() -> {
            String result = "";
            HttpURLConnection conn = null;
            try {
                // /api/get matches exactly only with album and duration as well; search is the fallback.
                String q = "https://lrclib.net/api/get?track_name=" + URLEncoder.encode(cleanTitle(title), "UTF-8")
                        + "&artist_name=" + URLEncoder.encode(cleanArtist(artist), "UTF-8")
                        + (album.isEmpty() ? "" : "&album_name=" + URLEncoder.encode(album, "UTF-8"))
                        + (durationSec > 0 ? "&duration=" + durationSec : "");
                try {
                    JSONObject exact = fetchObject(q);
                    result = text(exact, "syncedLyrics");
                    if (result.isEmpty()) result = text(exact, "plainLyrics");
                } catch (Exception ignored) { }
                if (result.isEmpty()) {
                    q = "https://lrclib.net/api/search?track_name=" + URLEncoder.encode(cleanTitle(title), "UTF-8")
                            + "&artist_name=" + URLEncoder.encode(cleanArtist(artist), "UTF-8");
                    conn = (HttpURLConnection) new URL(q).openConnection();
                    conn.setConnectTimeout(5000);
                    conn.setReadTimeout(5000);
                    conn.setRequestProperty("User-Agent", "GlassTV-CHOMBB/3.2.1");
                    if (conn.getResponseCode() == 200) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        StringBuilder json = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null && json.length() < 600000) json.append(line);
                        reader.close();
                        org.json.JSONArray items = new org.json.JSONArray(json.toString());
                        for (int n = 0; n < items.length(); n++) {
                            JSONObject obj = items.getJSONObject(n);
                            String candidate = text(obj, "syncedLyrics");
                            if (!candidate.isEmpty()) { result = candidate; break; }
                            if (result.isEmpty()) result = text(obj, "plainLyrics");
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
            final String lyrics = result;
            if (!lyrics.isEmpty()) lyricCache.put(key, lyrics);   // a failed lookup is retried next time
            ui.post(() -> { if (key.equals(lyricKey)) { lyricText = lyrics; lyricsLoading = false; } });
        }, "chombb-lyrics").start();
    }

    private static JSONObject fetchObject(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(4000);
        c.setReadTimeout(4000);
        c.setRequestProperty("User-Agent", "GlassTV-CHOMBB/3.2.1");
        try {
            if (c.getResponseCode() != 200) return new JSONObject();
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder b = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null && b.length() < 150000) b.append(line);
            r.close();
            return new JSONObject(b.toString());
        } finally {
            c.disconnect();
        }
    }

    /** LRCLIB sends JSON null for a missing field, which optString turns into the word "null". */
    private static String text(JSONObject o, String key) {
        if (o == null || o.isNull(key)) return "";
        String v = o.optString(key, "");
        return "null".equals(v) ? "" : v;
    }

    /** First artist only: "A, B" or "A & B" rarely matches the lyrics library. */
    private static String cleanArtist(String artist) {
        String a = artist.split("\\s*(,|&| x | feat\\.| ft\\.)\\s*")[0];
        return a.trim();
    }

    private static String cleanTitle(String title) {
        return title.replaceAll("(?i)\\s*[\\(\\[][^\\)\\]]*(official\\s*(music\\s*)?video|lyrics?|audio|visualizer|hd|4k)[^\\)\\]]*[\\)\\]]", "")
                .replaceAll("(?i)\\s+(ft\\.|feat\\.|featuring)\\s+.*$", "").trim();
    }

    // Parsed synced lyrics, kept until the song changes, so the 1-second refresh does not re-parse.
    private static String parsedFor;
    private static long[] parsedTimes = new long[0];
    private static String[] parsedLines = new String[0];

    private static void ensureParsed() {
        String text = lyricText;
        if (!text.contains("[")) {
            if (!text.equals(parsedFor)) { parsedFor = text; parsedTimes = new long[0]; parsedLines = new String[0]; }
            return;
        }
        if (!text.equals(parsedFor)) {
            ArrayList<Long> times = new ArrayList<>();
            ArrayList<String> lines = new ArrayList<>();
            for (String line : text.split("\n")) {
                int end = line.indexOf(']');
                if (!line.startsWith("[") || end < 0) continue;
                try {
                    String[] parts = line.substring(1, end).split(":");
                    long at = Long.parseLong(parts[0]) * 60000 + Math.round(Double.parseDouble(parts[1]) * 1000);
                    String value = line.substring(end + 1).trim();
                    if (!value.isEmpty()) { times.add(at); lines.add(value); }
                } catch (Exception ignored) { }
            }
            parsedTimes = new long[times.size()];
            for (int i = 0; i < parsedTimes.length; i++) parsedTimes[i] = times.get(i);
            parsedLines = lines.toArray(new String[0]);
            parsedFor = text;
        }
    }
}
