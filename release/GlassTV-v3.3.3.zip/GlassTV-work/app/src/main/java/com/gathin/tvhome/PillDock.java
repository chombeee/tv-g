package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.animation.DecelerateInterpolator;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.List;

/**
 * The Hero home layout's dock: one row of glass pills, one for every app on the box, that scrolls sideways.
 * The focused pill grows and its name shows large above the row. It reads the same tile list as the classic grid
 * (so the order, hidden apps and pinned favourites stay the same) and launches through the same code.
 */
public class PillDock extends LinearLayout {

    // All dimensions are 1920-wide design units and go through px().
    private static final int PILL_W = 246, PILL_H = 124, PILL_GAP = 26;   // six fit across 1920 with the side insets
    private static final int PLUS_DIAMETER = 72, PLUS_TOP_GAP = 16;
    private static final int PILL_SIDE_INSET = 134; // ~7% of 1920
    static final int PILL_UNFOCUSED = 0xA61C2633;
    static final int PILL_ICON_GREY = 0xFF555B63;
    private static final int PILL_FOCUS_CLEARANCE = 28; // vertical space for 1.08x scale and shadow
    static final int PILL_FOCUSED = 0xFFFFFFFF;
    static final int PILL_LABEL_DARK = 0xFF111111;
    private static final int PLUS_UNFOCUSED = 0x40FFFFFF;
    private static final float PILL_FOCUS_SCALE = 1.12f, PLUS_FOCUS_SCALE = 1.10f;
    private static final int PILL_ANIM_MS = 160, PLUS_ANIM_MS = 150;
    private static final int BLUR_BOTTOM_TINT = 0x40000000;

    interface Host {
        void focusTop();
        void appInfo(int tilePosition);
        void allApps();
        void onAppFocused(String label, int accent);
        /** OK held on an app: show the Move / App info menu next to {@code anchor}. */
        void onHold(int tilePosition, View anchor);
        /** RIGHT from the last tile: move onto the home widgets; false when there are none. */
    }

    // ---- Pill layout: category tabs under the row ------------------------------------------------
    private static final String[] TAB_KEYS = {"apps"};
    private static final String[] TAB_NAMES = {"APPS"};
    /** How many apps the Pill dock shows; the rest are in the All Apps drawer. */
    static final int PILL_DOCK_APPS = 6;
    private final LinearLayout tabs;
    private final List<TextView> tabViews = new ArrayList<>();
    private String filter = "apps";
    private final Map<String, Integer> categories = new HashMap<>();
    private static final Map<String, Integer> ACCENTS = new HashMap<>();
    private Runnable pendingFilter;

    // ---- moving an app (Pill and Material) -------------------------------------------------------
    private int movingIndex = -1;
    private ObjectAnimator wiggle;
    /** Key of the app to focus on the next refresh, set when a move has already changed the order. */
    private String pendingKey;
    /** Palette listeners of the Material tiles now shown; removed on every rebuild so they never pile up. */
    private final List<MaterialStyle.Listener> tileListeners = new ArrayList<>();

    private final AppAdapter adapter;
    private final Host host;
    private final float u;
    private Typeface face;
    private final TextView name;
    private final HorizontalScrollView scroller;
    private final LinearLayout row;
    private final TextView belowArrow;
    private final GradientDrawable materialDockBg = new GradientDrawable();
    private final MaterialStyle materialStyle = new MaterialStyle();
    MaterialStyle materialStyle() { return materialStyle; }
    private static final int MATERIAL_SIDE = 96, MATERIAL_FRAME = 16, MATERIAL_SCROLL_PAD = 36;
    private static final int MATERIAL_GAP = 28, MATERIAL_RING_ROOM = 12;
    private static final int MATERIAL_RADIUS = 80;
    private int materialTileW = 263, materialTileH = 172;
    private final List<View> pills = new ArrayList<>();
    private final List<Integer> positions = new ArrayList<>();
    private int lastIndex = 0;
    private String mode = "hero";
    private final Backdrop.Fill pillBlur = new Backdrop.Fill();
    private final Paint blurMaskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF blurRect = new RectF();

    void setMode(String value) { mode = value; refresh(); }

    PillDock(Context c, AppAdapter adapter, Host host) {
        super(c);
        this.adapter = adapter;
        this.host = host;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        u = dm.widthPixels / 1920f;
        try { face = c.getResources().getFont(R.font.outfit); } catch (Exception e) { face = Typeface.DEFAULT; }
        setOrientation(VERTICAL);
        setClipChildren(false);
        setClipToPadding(false);
        setWillNotDraw(false);
        Backdrop.watch(this);
        materialStyle.addListener(palette -> {
            if (!"material".equals(mode)) return;
            materialDockBg.setColor((palette.container & 0x00FFFFFF) | 0xB3000000);
            materialDockBg.setCornerRadius(px(MATERIAL_RADIUS));
            invalidate();
        });
        // Pill-only lower glass haze: clear above the tiles, deepening below them.
        // A gradient is used instead of blurring the whole wallpaper, which keeps
        // the upper half of the home wallpaper sharp on Android TV 9.
        name = new TextView(c);
        name.setTextSize(TypedValue.COMPLEX_UNIT_PX, 64 * u);
        name.setTextColor(0xFFFFFFFF);
        name.setTypeface(face);
        name.setIncludeFontPadding(false);
        name.setSingleLine(true);
        name.setShadowLayer(px(10), 0, px(3), 0x88000000);
        try { name.setFontVariationSettings("'wght' 700"); } catch (Exception ignored) { }
        LayoutParams np = new LayoutParams(-1, -2);
        np.leftMargin = px(110);
        np.bottomMargin = px(10);
        addView(name, np);

        scroller = new HorizontalScrollView(c);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setOverScrollMode(OVER_SCROLL_NEVER);
        scroller.setClipChildren(false);
        scroller.setClipToPadding(false);
        scroller.setSmoothScrollingEnabled(true);
        scroller.setPadding(0, px(18), 0, px(18));
        materialDockBg.setColor(0xB32B1D1D);
        materialDockBg.setCornerRadius(px(80));
        materialStyle.addListener(p -> { if ("material".equals(mode)) { materialDockBg.setColor((p.container & 0x00FFFFFF) | 0xB3000000); invalidate(); } });
        row = new LinearLayout(c);
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setClipChildren(false);
        row.setClipToPadding(false);
        row.setPadding(px(110), 0, px(110), 0);
        scroller.addView(row, new FrameLayout.LayoutParams(-2, -2));
        addView(scroller, new LayoutParams(-1, -2));
        belowArrow = new TextView(c);
        belowArrow.setText("+");
        belowArrow.setTextColor(0xFFFFFFFF);
        belowArrow.setTextSize(TypedValue.COMPLEX_UNIT_PX, 49*u);
        belowArrow.setGravity(Gravity.CENTER);
        belowArrow.setFocusable(true);
        belowArrow.setContentDescription("Show all apps");
        belowArrow.setOnClickListener(v -> host.allApps());
        belowArrow.setOnKeyListener((v, key, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && key == KeyEvent.KEYCODE_DPAD_UP) return focusCurrent();
            return false;
        });
        GradientDrawable allAppsBg = new GradientDrawable();
        allAppsBg.setShape(GradientDrawable.OVAL);
        allAppsBg.setColor(PLUS_UNFOCUSED);
        belowArrow.setBackground(allAppsBg);
        belowArrow.setOnFocusChangeListener((v, focused) -> {
            boolean glass = "pills".equals(mode);
            if (glass) {
                allAppsBg.setColor(focused ? PILL_FOCUSED : PLUS_UNFOCUSED);
                belowArrow.setTextColor(focused ? PILL_LABEL_DARK : 0xFFFFFFFF);
            }
            belowArrow.animate().scaleX(focused ? PLUS_FOCUS_SCALE : 1f)
                    .scaleY(focused ? PLUS_FOCUS_SCALE : 1f).setDuration(PLUS_ANIM_MS)
                    .setInterpolator(new DecelerateInterpolator()).start();
        });
        LayoutParams downParams = new LayoutParams(px(PLUS_DIAMETER), px(PLUS_DIAMETER));
        downParams.gravity = Gravity.CENTER_HORIZONTAL;
        downParams.topMargin = px(PLUS_TOP_GAP);
        addView(belowArrow, downParams);

        tabs = new LinearLayout(c);
        tabs.setOrientation(HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        tabs.setClipChildren(false);
        for (int i = 0; i < TAB_KEYS.length; i++) {
            TextView tab = makeTab(TAB_KEYS[i], TAB_NAMES[i]);
            LayoutParams tp = new LayoutParams(-2, px(52));
            if (i > 0) tp.leftMargin = px(14);
            tabs.addView(tab, tp);
            tabViews.add(tab);
        }
        LayoutParams tabsLp = new LayoutParams(-1, -2);
        tabsLp.topMargin = -px(22);   // closer to the pills; the row keeps clearance for the focus glow
        addView(tabs, tabsLp);
        tabs.setVisibility(GONE);
        paintTabs();
    }

    private TextView makeTab(String key, String title) {
        TextView tab = new TextView(getContext());
        tab.setText(title);
        tab.setTag(key);
        tab.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24 * u);
        tab.setTypeface(face);
        try { tab.setFontVariationSettings("'wght' 500"); } catch (Exception ignored) { }
        tab.setLetterSpacing(0.04f);
        tab.setGravity(Gravity.CENTER);
        tab.setIncludeFontPadding(false);
        tab.setPadding(px(30), 0, px(30), 0);
        tab.setFocusable(true);
        tab.setClickable(true);
        tab.setBackground(new GradientDrawable());
        tab.setOnFocusChangeListener((v, f) -> {
            paintTabs();
            if (f && !key.equals(filter)) {
                // Switch the row a moment after focus settles, so holding LEFT/RIGHT does not rebuild every step.
                if (pendingFilter != null) removeCallbacks(pendingFilter);
                pendingFilter = () -> selectFilter(key);
                postDelayed(pendingFilter, 220);
            }
        });
        tab.setOnClickListener(v -> { SoundEffects.playSelect(); host.allApps(); });
        tab.setOnKeyListener((v, code, ev) -> tabKey(code, ev, false));
        return tab;
    }

    private boolean tabKey(int code, KeyEvent ev, boolean isPlus) {
        if (ev.getAction() != KeyEvent.ACTION_DOWN) return code == KeyEvent.KEYCODE_DPAD_DOWN;
        if (code == KeyEvent.KEYCODE_DPAD_UP) {
            if (pills.isEmpty()) host.focusTop(); else focusCurrent();
            return true;
        }
        if (code == KeyEvent.KEYCODE_DPAD_DOWN) return true;
        View f = findFocus();
        int i = f == null ? -1 : tabs.indexOfChild(f);
        if (code == KeyEvent.KEYCODE_DPAD_LEFT && i == 0) return true;
        return code == KeyEvent.KEYCODE_DPAD_RIGHT && i == tabs.getChildCount() - 1;
    }

    private void selectFilter(String key) {
        if (pendingFilter != null) { removeCallbacks(pendingFilter); pendingFilter = null; }
        if (key.equals(filter)) return;
        filter = key;
        lastIndex = 0;
        paintTabs();
        refresh();
        scroller.scrollTo(0, 0);
    }

    private void paintTabs() {
        for (TextView tab : tabViews) {
            boolean selected = filter.equals(tab.getTag()), focused = tab.isFocused();
            GradientDrawable bg = (GradientDrawable) tab.getBackground();
            bg.setCornerRadius(px(26));
            bg.setColor(focused ? 0xFFFFFFFF : (selected ? 0x4DFFFFFF : 0x00FFFFFF));
            bg.setStroke(Math.max(1, px(1.5f)), selected && !focused ? 0x40FFFFFF : 0x00FFFFFF);
            tab.setTextColor(focused ? 0xFF15191F : (selected ? 0xFFFFFFFF : 0xD9FFFFFF));
        }
    }

    private View selectedTab() {
        for (TextView tab : tabViews) if (filter.equals(tab.getTag())) return tab;
        return tabViews.isEmpty() ? null : tabViews.get(0);
    }

    /** Whether an app belongs under the selected tab: Android's own app category first, then its name. */
    private boolean inFilter(AppAdapter.Entry e) {
        if ("apps".equals(filter)) return true;
        String n = (e.label + " " + e.pkg).toLowerCase(Locale.ROOT);
        int cat = categoryOf(e.pkg);
        switch (filter) {
            case "movies":
                return cat == ApplicationInfo.CATEGORY_VIDEO || has(n, "netflix", "prime", "video", "hotstar", "disney",
                        "viu", "iqiyi", "hbo", "movie", "film", "plex", "jellyfin", "kodi", "sony", "zee", "astro",
                        "unifi", "youtube", "wetv", "mubi", "tonton", "apple tv", "vidio", "crunchyroll", "stremio");
            case "music":
                return cat == ApplicationInfo.CATEGORY_AUDIO || has(n, "spotify", "music", "joox", "deezer", "tidal",
                        "soundcloud", "radio", "podcast", "karaoke");
            case "sports":
                return has(n, "sport", "espn", "f1", "formula", "fifa", "nba", "nfl", "dazn", "bein", "golf", "ufc",
                        "mlb", "racing", "motogp", "football");
            case "news":
                return cat == ApplicationInfo.CATEGORY_NEWS || has(n, "news", "berita", "cnn", "bbc", "aljazeera",
                        "awani", "reuters", "bloomberg");
            default:
                return true;
        }
    }

    private static boolean has(String hay, String... needles) {
        for (String s : needles) if (hay.contains(s)) return true;
        return false;
    }

    private int categoryOf(String pkg) {
        Integer c = categories.get(pkg);
        if (c != null) return c;
        int v = ApplicationInfo.CATEGORY_UNDEFINED;
        try { v = getContext().getPackageManager().getApplicationInfo(pkg, 0).category; } catch (Exception ignored) { }
        categories.put(pkg, v);
        return v;
    }

    /** The app's brand colour for the focused pill: known brands first, else the most vivid colour of its art. */
    private int accentOf(AppAdapter.Entry e) {
        Integer cached = ACCENTS.get(e.pkg);
        if (cached != null) return cached;
        String n = (e.label + " " + e.pkg).toLowerCase(Locale.ROOT);
        int c;
        if (n.contains("netflix")) c = 0xFFE50914;
        else if (n.contains("youtube")) c = 0xFFFF0033;
        else if (n.contains("spotify")) c = 0xFF1DB954;
        else if (n.contains("prime") || n.contains("amazon")) c = 0xFF1A98FF;
        else if (n.contains("disney") || n.contains("hotstar")) c = 0xFF1F3FBF;
        else c = sampleAccent(e);
        ACCENTS.put(e.pkg, c);
        return c;
    }

    private int sampleAccent(AppAdapter.Entry e) {
        Drawable d = copy(e.banner != null ? e.banner : e.icon);
        if (d == null) {
            try { d = getContext().getPackageManager().getApplicationIcon(e.pkg); } catch (Exception ignored) { }
        }
        if (d == null) return 0xFF3A6EA5;
        try {
            final int S = 24;
            Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, S, S);
            d.draw(new Canvas(b));
            float best = -1f;
            int pick = 0xFF3A6EA5;
            float[] hsv = new float[3];
            for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
                int px = b.getPixel(x, y);
                if ((px >>> 24) < 200) continue;
                android.graphics.Color.colorToHSV(px, hsv);
                float score = hsv[1] * hsv[2];
                if (score > best) { best = score; pick = px; }
            }
            b.recycle();
            if (best < 0.18f) return 0xFF46536A;   // a grey or black logo: a neutral slate rather than a muddy colour
            android.graphics.Color.colorToHSV(pick, hsv);
            hsv[2] = Math.min(hsv[2], 0.82f);        // keep white text readable on the filled pill
            return android.graphics.Color.HSVToColor(hsv);
        } catch (Throwable t) {
            return 0xFF3A6EA5;
        }
    }

    // ---- moving -------------------------------------------------------------------------------------

    /** Picks up the app at adapter position {@code tilePos}: it wiggles, LEFT/RIGHT carry it, OK or Back puts it down. */
    void startMove(int tilePos) {
        int idx = positions.indexOf(tilePos);
        if (idx < 0 || !adapter.canMove(tilePos)) return;
        movingIndex = idx;
        lastIndex = idx;
        View v = pills.get(idx);
        v.requestFocus();
        startWiggle(v);
    }

    /** Puts the moving app down. Returns false when nothing was moving. */
    boolean endMove() {
        if (movingIndex < 0) return false;
        movingIndex = -1;
        stopWiggle();
        SoundEffects.playSelect();
        return true;
    }

    private void carry(int step) {
        int to = movingIndex + step;
        if (to < 0 || to >= pills.size()) return;
        int fromTile = positions.get(movingIndex), toTile = positions.get(to);
        if (!adapter.move(fromTile, toTile)) return;
        SoundEffects.playNav();
        stopWiggle();
        pendingKey = adapter.keyAt(toTile);
        movingIndex = to;
        lastIndex = to;
        refresh();
        if (movingIndex >= 0 && movingIndex < pills.size()) startWiggle(pills.get(movingIndex));
    }

    private void startWiggle(View v) {
        stopWiggle();
        wiggle = ObjectAnimator.ofFloat(v, View.ROTATION, -1.6f, 1.6f);
        wiggle.setDuration(130);
        wiggle.setRepeatMode(ValueAnimator.REVERSE);
        wiggle.setRepeatCount(ValueAnimator.INFINITE);
        wiggle.start();
    }

    private void stopWiggle() {
        if (wiggle == null) return;
        Object target = wiggle.getTarget();
        wiggle.cancel();
        wiggle = null;
        if (target instanceof View) ((View) target).setRotation(0f);
    }

    /** Key handling shared by every app tile while one is being moved. */
    private boolean focusDockNeighbor(View from, int key) {
        if (key != KeyEvent.KEYCODE_DPAD_LEFT && key != KeyEvent.KEYCODE_DPAD_RIGHT) return false;
        int index = row.indexOfChild(from) + (key == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1);
        View target = row.getChildAt(index);
        if (target != null && target.isFocusable()) target.requestFocus();
        return true;
    }

    private boolean moveKey(int code, KeyEvent ev) {
        if (movingIndex < 0) return false;
        if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT) {
            if (ev.getAction() == KeyEvent.ACTION_DOWN) carry(code == KeyEvent.KEYCODE_DPAD_LEFT ? -1 : 1);
            return true;
        }
        return code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!"pills".equals(mode) || getWidth() <= 0 || getHeight() <= 0) return;
        // Drawn only when the dock itself is invalidated (wallpaper change, rebuild), never per focus frame.
        final float w = getWidth(), h = getHeight();
        final float top = Math.max(0f, Math.min(h - 1, scroller.getTop() + scroller.getPaddingTop() + row.getPaddingTop() + px(PILL_H) / 2f) - px(70));   // haze starts higher
        // Keep the mask and the wallpaper shader in the dock's original local coordinates.
        blurRect.set(0, top, w, h);
        int layer = canvas.saveLayer(blurRect, null);
        pillBlur.draw(canvas, this, blurRect, 0f, 1f);
        blurMaskPaint.setShader(new LinearGradient(0, top, 0, h,
                new int[]{0x00000000, 0xA6000000, 0xF0000000, 0xFF000000},
                new float[]{0f, .22f, .55f, 1f}, Shader.TileMode.CLAMP));
        blurMaskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawRect(blurRect, blurMaskPaint);
        blurMaskPaint.setXfermode(null);
        blurMaskPaint.setShader(null);
        canvas.restoreToCount(layer);
        tintPaint.setShader(new LinearGradient(0, top, 0, h,
                0x00000000, BLUR_BOTTOM_TINT, Shader.TileMode.CLAMP));
        canvas.drawRect(blurRect, tintPaint);
        tintPaint.setShader(null);
    }

    private int px(float units) { return Math.round(units * u); }

    /** Rebuilds the pills from the adapter's tiles: every plain app, in the grid's order. */
    void refresh() {
        String focusedKey = pendingKey;
        pendingKey = null;
        View f = findFocus();
        boolean tabHadFocus = f != null && tabs.indexOfChild(f) >= 0;
        if (focusedKey == null && f != null && f.getTag() instanceof Integer) focusedKey = adapter.keyAt((Integer) f.getTag());
        boolean compact = !"hero".equals(mode);
        boolean fixedPills = "pills".equals(mode);
        boolean material = "material".equals(mode);
        belowArrow.setVisibility(GONE);
        tabs.setVisibility(fixedPills ? VISIBLE : GONE);
        scroller.setBackground(material ? materialDockBg : null);
        // Pill: a soft shade under the row, drawn as one gradient (no blur layer on slow boxes).
        setBackground(null);
        setWillNotDraw(!fixedPills);
        invalidate();
        // Material dock stays inset from both screen edges; content remains centered.
        if (material) {
            setPadding(px(96), 0, px(96), 0);
        } else {
            setPadding(0, 0, 0, 0);
        }
        name.setVisibility(fixedPills || material ? GONE : VISIBLE);
        scroller.setFillViewport(material || fixedPills);   // Pill: the five pills sit centred
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setHorizontalFadingEdgeEnabled(false);
        scroller.setSmoothScrollingEnabled(fixedPills || !compact);
        row.setPadding(material ? px(36) : (fixedPills ? px(PILL_SIDE_INSET) : (compact ? px(60) : px(110))),
                fixedPills ? px(PILL_FOCUS_CLEARANCE) : 0,
                material ? px(36) : (fixedPills ? px(PILL_SIDE_INSET) : (compact ? px(40) : px(110))),
                fixedPills ? px(PILL_FOCUS_CLEARANCE) : 0);
        // HorizontalScrollView clips its viewport even if clipChildren is false;
        // keep the scaled pill and its shadow inside the scrollable content bounds.
        scroller.setPadding(0, fixedPills ? px(PILL_FOCUS_CLEARANCE) : px(18),
                0, fixedPills ? px(PILL_FOCUS_CLEARANCE) : px(18));
        name.setTextSize(TypedValue.COMPLEX_UNIT_PX, compact ? 44*u : 64*u);
        if (material) {
            int n = 0;
            for (int j=0;j<adapter.tileCount();j++) if (adapter.tileAt(j).kind==AppAdapter.Entry.APP && n<6) n++;
            n=Math.max(1,n+1); // reserve the all-apps arrow in the width budget
            int budget = 1920-2*(MATERIAL_SIDE+MATERIAL_FRAME+MATERIAL_SCROLL_PAD);
            materialTileW = Math.max(130,(budget-(n-1)*MATERIAL_GAP-n*2*MATERIAL_RING_ROOM)/n);
            materialTileH = Math.round(materialTileW*9f/16f);
        }
        for (MaterialStyle.Listener l : tileListeners) materialStyle.removeListener(l);
        tileListeners.clear();
        row.removeAllViews();
        pills.clear();
        positions.clear();
        int added = 0;
        for (int i = 0; i < adapter.tileCount(); i++) {
            AppAdapter.Entry e = adapter.tileAt(i);
            if (e.kind != AppAdapter.Entry.APP) continue;
            if (fixedPills && added >= PILL_DOCK_APPS) break;
            View pill = material ? makeMaterialTile(e, i) : (fixedPills ? makeGlassPill(e, i) : makePill(e, i));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(fixedPills ? PILL_W : (material ? materialTileW+24 : (compact ? 220 : 250))), px(fixedPills ? PILL_H : (material ? materialTileH+75 : (compact ? 110 : 128))));
            lp.rightMargin = px(fixedPills ? PILL_GAP : (material ? MATERIAL_GAP : (compact ? 16 : 26)));
            row.addView(pill, lp);
            pills.add(pill);
            positions.add(i);
            added++;
            if (!"hero".equals(mode) && !fixedPills && added >= 6) break;
        }
        if (!"hero".equals(mode) && !fixedPills) addAllAppsArrow();
        if (fixedPills && pills.isEmpty()) {
            TextView none = new TextView(getContext());
            none.setText("Tiada app dalam kategori ini");
            none.setTextColor(0xB3FFFFFF);
            none.setTextSize(TypedValue.COMPLEX_UNIT_PX, 26 * u);
            none.setTypeface(face);
            none.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(none, new LinearLayout.LayoutParams(-2, px(PILL_H)));
        }
        lastIndex = Math.max(0, Math.min(lastIndex, pills.size() - 1));
        if (focusedKey != null && !tabHadFocus) {
            int pos = adapter.positionOf(focusedKey);
            int idx = positions.indexOf(pos);
            if (idx >= 0) { lastIndex = idx; pills.get(idx).requestFocus(); }
        } else if (focusedKey == null) {
            name.setText("");
        }
    }

    /** Material-only TV banner tile with a separate focus label below the artwork. */
    private View makeMaterialTile(AppAdapter.Entry e, final int tilePos) {
        Context c = getContext();
        LinearLayout wrapper = new LinearLayout(c);
        wrapper.setOrientation(VERTICAL);
        wrapper.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        wrapper.setFocusable(true);
        wrapper.setClickable(true);
        wrapper.setTag(tilePos);
        wrapper.setClipChildren(false);
        wrapper.setClipToPadding(false);
        wrapper.setPadding(px(12), px(12), px(12), px(12));

        FrameLayout tile = new FrameLayout(c);
        GradientDrawable tileBg = new GradientDrawable();
        tileBg.setColor(materialStyle.current().containerHigh);
        tileBg.setCornerRadius(px(30));
        tile.setBackground(tileBg);
        tile.setClipToOutline(true);
        tile.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), px(30));
            }
        });
        Drawable banner = copy(e.banner);
        if (banner != null) {
            ImageView art = new ImageView(c);
            art.setImageDrawable(banner);
            art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            tile.addView(art, new FrameLayout.LayoutParams(-1, -1));
        } else {
            ImageView icon = new ImageView(c);
            IconLoader.into(icon, e.pkg, e.icon, px(136));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(px(136), px(136), Gravity.CENTER);
            tile.addView(icon, ilp);
        }
        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(px(materialTileW), px(materialTileH));
        tileLp.topMargin = px(7);
        wrapper.addView(tile, tileLp);

        TextView caption = new TextView(c);
        caption.setText(e.label);
        caption.setTextSize(TypedValue.COMPLEX_UNIT_PX, 31*u);
        caption.setTextColor(0xFFFFD9D4);
        caption.setTypeface(face, Typeface.BOLD);
        caption.setGravity(Gravity.CENTER);
        caption.setSingleLine(true);
        caption.setEllipsize(android.text.TextUtils.TruncateAt.END);
        caption.setVisibility(INVISIBLE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(px(materialTileW), px(38));
        cp.topMargin = px(7);
        wrapper.addView(caption, cp);

        GradientDrawable outline = new GradientDrawable();
        outline.setCornerRadius(px(40));
        outline.setColor(0x00000000);
        outline.setStroke(px(5), 0x00000000);
        tile.setForeground(outline);
        MaterialStyle.Listener tint = palette -> {
            tileBg.setColor(palette.containerHigh);
            caption.setTextColor(palette.onSurface);
            outline.setStroke(px(6), wrapper.isFocused() ? palette.primary : 0x00000000);
            tile.invalidate();
        };
        tileListeners.add(tint);
        materialStyle.addListener(tint);
        wrapper.setOnFocusChangeListener((v, focused) -> {
            outline.setStroke(px(6), focused ? materialStyle.current().primary : 0x00000000);
            caption.setVisibility(focused ? VISIBLE : INVISIBLE);
            caption.animate().alpha(focused ? 1f : 0f).setDuration(150).setInterpolator(MaterialStyle.FAST_EFFECTS).start();
            ChombbWidgets.springScale(wrapper, focused ? 1.10f : 1f, 380f, 0.62f);
            wrapper.animate().translationZ(focused ? px(28) : 0f).setDuration(350)
                    .setInterpolator(MaterialStyle.FAST_SPATIAL).start();
            tileBg.setCornerRadius(px(focused ? 25 : 40));
            if (focused) {
                String label = e.label;
                String lower = label.toLowerCase(java.util.Locale.ROOT);
                materialStyle.focus(e.pkg, e.banner != null ? e.banner : e.icon);
                int accent = materialStyle.current().primary;
                host.onAppFocused(label, accent);
                name.setText(label);
                int idx = pills.indexOf(v);
                if (idx >= 0) lastIndex = idx;
            }
        });
        wrapper.setOnClickListener(v -> { if (!endMove()) adapter.launchAt(tilePos); });
        wrapper.setOnLongClickListener(v -> { if (movingIndex < 0) host.onHold(tilePos, tile); return true; });
        wrapper.setOnKeyListener((v, keyCode, event) -> {
            if (moveKey(keyCode, event)) return true;
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) { host.focusTop(); return true; }
            return keyCode == KeyEvent.KEYCODE_DPAD_DOWN || focusDockNeighbor(v, keyCode);
        });
        return wrapper;
    }

    private void addAllAppsArrow() {
        if ("material".equals(mode)) { addAllAppsCard(); return; }
        boolean material = "material".equals(mode);
        TextView arrow = new TextView(getContext());
        arrow.setText(material ? "➜" : "↓");
        arrow.setContentDescription("All applications");
        arrow.setTextSize(TypedValue.COMPLEX_UNIT_PX, (material ? 38 : 56) * u);
        arrow.setTextColor(material ? 0xFF111111 : 0xFFFFFFFF);
        arrow.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(material ? 0xFFFFFFFF : 0x99263248);
        arrow.setBackground(bg);
        arrow.setFocusable(true);
        arrow.setOnFocusChangeListener((v, focused) -> v.animate()
                .scaleX(focused ? 1.10f : 1f).scaleY(focused ? 1.10f : 1f).setDuration(150).start());
        arrow.setOnClickListener(v -> host.allApps());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(material ? 72 : 128), px(material ? 72 : 128));
        lp.gravity = Gravity.CENTER_VERTICAL;
        lp.leftMargin = px(material ? 18 : 0);
        lp.rightMargin = px(20);
        row.addView(arrow, lp);
        if (material) {
            android.animation.ObjectAnimator pulse = android.animation.ObjectAnimator.ofFloat(arrow, "translationX",
                    0f, px(12), 0f, px(12), 0f, 0f, 0f, 0f);
            pulse.setDuration(2800);
            pulse.setRepeatCount(1);   // a hint, not an endless animation that keeps the GPU busy
            pulse.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
            pulse.start();
        }
    }


    /**
     * Pill layout tile, after the reference photo: a dark glass capsule with the app's name. Focused, it fills
     * with the app's own colour, grows a little and casts a soft glow of that colour.
     */
    private View makeGlassPill(AppAdapter.Entry e, final int tilePos) {
        Context c = getContext();
        final FrameLayout pill = new FrameLayout(c);
        pill.setTag(tilePos);
        pill.setFocusable(true);
        pill.setClickable(true);
        pill.setClipChildren(false);
        pill.setClipToPadding(false);
        final int h = px(PILL_H);

        // Focus glow: a round gradient that fades to nothing at its own edge (so it never shows a box),
        // squashed into an ellipse behind the pill. Fits inside the dock's clearance, so it is never cut.
        final View glow = new View(c);
        final GradientDrawable glowBg = new GradientDrawable();
        glowBg.setShape(GradientDrawable.OVAL);
        glowBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        final int gw = Math.round(px(PILL_W) * 1.5f);
        glowBg.setGradientRadius(gw / 2f);
        glowBg.setColors(new int[]{0x00000000, 0x00000000});
        glow.setBackground(glowBg);
        glow.setAlpha(0f);
        glow.setScaleY(0.5f);
        pill.addView(glow, new FrameLayout.LayoutParams(gw, gw, Gravity.CENTER));
        pill.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), h / 2f); }
        });

        final FrameLayout body = new FrameLayout(c);
        final GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(h / 2f);
        bg.setColor(GlassStyle.tint(PILL_UNFOCUSED));
        bg.setStroke(Math.max(1, px(1.5f)), 0x24FFFFFF);
        body.setBackground(bg);
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(HORIZONTAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(px(20), 0, px(22), 0);
        final ImageView icon = new ImageView(c);
        IconLoader.into(icon, e.pkg, e.icon, px(50));
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        final float iconR = px(12);
        icon.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), iconR); }
        });
        icon.setClipToOutline(true);
        final ColorMatrixColorFilter mono = new ColorMatrixColorFilter(GREY);
        icon.setColorFilter(mono);
        icon.setAlpha(0.8f);
        content.addView(icon, new LinearLayout.LayoutParams(px(50), px(50)));
        final TextView t = new TextView(c);
        t.setText(e.label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 25 * u);
        t.setTypeface(face);
        try { t.setFontVariationSettings("'wght' 650"); } catch (Exception ignored) { }
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setIncludeFontPadding(false);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.leftMargin = px(12);
        content.addView(t, tlp);
        body.addView(content, new FrameLayout.LayoutParams(-1, -1));
        pill.addView(body, new FrameLayout.LayoutParams(-1, -1));

        pill.setOnFocusChangeListener((v, focused) -> {
            int accent = focused ? accentOf(e) : 0;
            if (focused) {
                bg.setColor((accent & 0x00FFFFFF) | 0xEB000000);
                bg.setStroke(Math.max(1, px(1.5f)), 0x66FFFFFF);
                int rgb = accent & 0x00FFFFFF;
                glowBg.setColors(new int[]{rgb | 0xE6000000, rgb | 0x73000000, rgb});
                if (android.os.Build.VERSION.SDK_INT >= 28) {
                    pill.setOutlineSpotShadowColor(accent);
                    pill.setOutlineAmbientShadowColor(accent);
                }
                float lum = (0.299f * ((accent >> 16) & 0xFF) + 0.587f * ((accent >> 8) & 0xFF) + 0.114f * (accent & 0xFF)) / 255f;
                t.setTextColor(lum > 0.66f ? 0xFF111418 : 0xFFFFFFFF);
                icon.clearColorFilter();
            } else {
                icon.setColorFilter(mono);
                bg.setColor(GlassStyle.tint(PILL_UNFOCUSED));
                bg.setStroke(Math.max(1, px(1.5f)), 0x24FFFFFF);
                t.setTextColor(0xFFFFFFFF);
            }
            glow.animate().alpha(focused ? 1f : 0f).setDuration(PILL_ANIM_MS).start();
            v.animate().translationZ(focused ? px(16) : 0f).setDuration(PILL_ANIM_MS).start();
            icon.animate().alpha(focused ? 1f : 0.8f).setDuration(PILL_ANIM_MS).start();
            ChombbWidgets.springScale(v, focused ? PILL_FOCUS_SCALE : 1f, 360f, 0.6f);
            if (focused) {
                name.setText(e.label);
                int idx = pills.indexOf(v);
                if (idx >= 0) lastIndex = idx;
                scroller.post(() -> scroller.smoothScrollTo(
                        Math.max(0, pill.getLeft() + pill.getWidth() / 2 - scroller.getWidth() / 2), 0));
            }
        });
        pill.setOnClickListener(v -> { if (!endMove()) adapter.launchAt(tilePos); });
        pill.setOnLongClickListener(v -> { if (movingIndex < 0) host.onHold(tilePos, v); return true; });
        pill.setOnKeyListener((v, keyCode, event) -> {
            if (moveKey(keyCode, event)) return true;
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) { host.focusTop(); return true; }
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                View tab = selectedTab();
                if (tab != null) tab.requestFocus();
                return true;
            }
            return focusDockNeighbor(v, keyCode);
        });
        return pill;
    }

    private static final DecelerateInterpolator EASE = new DecelerateInterpolator();
    private static final ColorMatrix GREY = new ColorMatrix();
    static { GREY.setSaturation(0f); }

    /** Adapter position of the last app shown in the dock (where an app from All Apps lands), or -1. */
    int lastDockTile() {
        return positions.isEmpty() ? -1 : positions.get(positions.size() - 1);
    }

    /** Whether the app at adapter position {@code tilePos} is shown in the dock. */
    boolean inDock(int tilePos) {
        return positions.contains(tilePos);
    }


    /**
     * Material: the last card of the dock opens All Apps. Same size as an app card, in the palette's
     * primary container, with a little 2x2 cluster of the apps that are not in the dock and a "+N" badge.
     */
    private void addAllAppsCard() {
        Context c = getContext();
        int total = 0;
        List<AppAdapter.Entry> rest = new ArrayList<>();
        for (int i = 0; i < adapter.tileCount(); i++) {
            AppAdapter.Entry e = adapter.tileAt(i);
            if (e.kind != AppAdapter.Entry.APP) continue;
            total++;
            if (!positions.contains(i) && rest.size() < 4) rest.add(e);
        }
        final LinearLayout wrapper = new LinearLayout(c);
        wrapper.setOrientation(VERTICAL);
        wrapper.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        wrapper.setFocusable(true);
        wrapper.setClickable(true);
        wrapper.setClipChildren(false);
        wrapper.setClipToPadding(false);
        wrapper.setPadding(px(12), px(12), px(12), px(12));
        wrapper.setContentDescription("Semua app");

        final FrameLayout tile = new FrameLayout(c);
        final GradientDrawable tileBg = new GradientDrawable();
        tileBg.setCornerRadius(px(40));
        tileBg.setColor(materialStyle.current().primaryContainer);
        tile.setBackground(tileBg);
        final GradientDrawable outline = new GradientDrawable();
        outline.setCornerRadius(px(40));
        outline.setColor(0x00000000);
        outline.setStroke(px(5), 0x00000000);
        tile.setForeground(outline);

        // 2x2 cluster of the next apps (or fewer), the way a phone folder shows what is inside.
        LinearLayout cluster = new LinearLayout(c);
        cluster.setOrientation(VERTICAL);
        int ic = Math.max(16, Math.min(px(48), Math.round(materialTileH * 0.30f))), gap = px(6);
        for (int r = 0; r < 2; r++) {
            LinearLayout line = new LinearLayout(c);
            line.setOrientation(HORIZONTAL);
            for (int k = 0; k < 2; k++) {
                int idx = r * 2 + k;
                ImageView iv = new ImageView(c);
                final float rr = ic * 0.26f;
                iv.setOutlineProvider(new ViewOutlineProvider() {
                    @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rr); }
                });
                iv.setClipToOutline(true);
                if (idx < rest.size()) IconLoader.into(iv, rest.get(idx).pkg, rest.get(idx).icon, ic);
                else {
                    GradientDrawable dot = new GradientDrawable();
                    dot.setCornerRadius(rr);
                    dot.setColor(0x26FFFFFF);
                    iv.setBackground(dot);
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ic, ic);
                if (k > 0) lp.leftMargin = gap;
                line.addView(iv, lp);
            }
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-2, -2);
            if (r > 0) rl.topMargin = gap;
            cluster.addView(line, rl);
        }
        tile.addView(cluster, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        int more = Math.max(0, total - positions.size());
        final TextView badge = new TextView(c);
        badge.setText(more > 0 ? "+" + more : "Semua");
        badge.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20 * u);
        badge.setTypeface(face, Typeface.BOLD);
        badge.setIncludeFontPadding(false);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(px(12), px(6), px(12), px(6));
        final GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setCornerRadius(px(20));
        badgeBg.setColor(materialStyle.current().primary);
        badge.setBackground(badgeBg);
        badge.setTextColor(materialStyle.current().onPrimary);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        bl.rightMargin = bl.bottomMargin = px(12);
        tile.addView(badge, bl);

        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(px(materialTileW), px(materialTileH));
        tileLp.topMargin = px(7);
        wrapper.addView(tile, tileLp);

        final TextView caption = new TextView(c);
        caption.setText("Semua app");
        caption.setTextSize(TypedValue.COMPLEX_UNIT_PX, 31 * u);
        caption.setTextColor(materialStyle.current().onSurface);
        caption.setTypeface(face, Typeface.BOLD);
        caption.setGravity(Gravity.CENTER);
        caption.setSingleLine(true);
        caption.setVisibility(INVISIBLE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(px(materialTileW), px(38));
        cp.topMargin = px(7);
        wrapper.addView(caption, cp);

        MaterialStyle.Listener tint = palette -> {
            tileBg.setColor(palette.primaryContainer);
            badgeBg.setColor(palette.primary);
            badge.setTextColor(palette.onPrimary);
            caption.setTextColor(palette.onSurface);
            outline.setStroke(px(6), wrapper.isFocused() ? palette.primary : 0x00000000);
            tile.invalidate();
        };
        tileListeners.add(tint);
        materialStyle.addListener(tint);

        wrapper.setOnFocusChangeListener((v, focused) -> {
            outline.setStroke(px(6), focused ? materialStyle.current().primary : 0x00000000);
            caption.setVisibility(focused ? VISIBLE : INVISIBLE);
            tileBg.setCornerRadius(px(focused ? 25 : 40));
            ChombbWidgets.springScale(wrapper, focused ? 1.10f : 1f, 380f, 0.62f);
            wrapper.animate().translationZ(focused ? px(28) : 0f).setDuration(350)
                    .setInterpolator(MaterialStyle.FAST_SPATIAL).start();
            if (focused) {
                name.setText("Semua app");
                host.onAppFocused("Semua app", materialStyle.current().primary);
            }
        });
        wrapper.setOnClickListener(v -> { SoundEffects.playSelect(); host.allApps(); });
        wrapper.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) { host.focusTop(); return true; }
            return keyCode == KeyEvent.KEYCODE_DPAD_DOWN || focusDockNeighbor(v, keyCode);
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(materialTileW + 24), px(materialTileH + 75));
        row.addView(wrapper, lp);
    }

    /** Focus the first app of the dock (used when Home opens), not the last one remembered. */
    boolean focusFirstTile() {
        lastIndex = 0;
        return focusCurrent();
    }

    boolean focusCurrent() {
        if (pills.isEmpty()) {
            // An empty category: the tabs are the only thing to land on.
            View tab = tabs.getVisibility() == VISIBLE ? selectedTab() : null;
            return tab != null && tab.requestFocus();
        }
        View v = pills.get(Math.max(0, Math.min(lastIndex, pills.size() - 1)));
        return v.requestFocus();
    }

    private Drawable copy(Drawable d) {
        if (d == null) return null;
        Drawable.ConstantState cs = d.getConstantState();
        return cs != null ? cs.newDrawable(getResources()).mutate() : d;
    }

    private View makePill(AppAdapter.Entry e, final int tilePos) {
        Context c = getContext();
        final FrameLayout pill = new FrameLayout(c);
        pill.setTag(tilePos);
        pill.setFocusable(true);
        pill.setClickable(true);
        pill.setClipChildren(false);
        pill.setClipToPadding(false);
        final boolean fixedPills = "pills".equals(mode);
        final boolean material = "material".equals(mode);
        final int h = px(fixedPills ? PILL_H : (material ? 145 : 128));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(material ? px(26) : h / 2f);
        bg.setColor(fixedPills ? PILL_UNFOCUSED : ("material".equals(mode) ? 0x00202630 : 0x88202A39));

        pill.setBackground(bg);
        pill.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), material ? px(24) : v.getHeight() / 2f);
            }
        });
        pill.setClipToOutline(!fixedPills);

        Drawable art = (fixedPills || material) ? null : copy(e.banner);
        if (art != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(art);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pill.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            View shade = new View(c);
            shade.setBackgroundColor(0x2E000000);
            pill.addView(shade, new FrameLayout.LayoutParams(-1, -1));
            pill.setTag(R.id.card, shade);
        } else {
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(material ? VERTICAL : HORIZONTAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(px(12), 0, px(12), 0);
            ImageView icon = new ImageView(c);
            Drawable appArt = copy(e.icon);
            if (appArt == null) {
                try { appArt = c.getPackageManager().getApplicationIcon(e.pkg); }
                catch (Exception ignored) { }
            }
            if (fixedPills && appArt != null) appArt = appArt.mutate();
            icon.setImageDrawable(appArt);
            icon.setTag("app_icon");
            if (fixedPills) {
                icon.setAlpha(1f);
                icon.setColorFilter(PILL_ICON_GREY, android.graphics.PorterDuff.Mode.SRC_IN);
            }
            col.addView(icon, new LinearLayout.LayoutParams(px(material ? 118 : (fixedPills ? 54 : 64)), px(material ? 88 : (fixedPills ? 54 : 64))));
            TextView t = new TextView(c);
            t.setText(e.label);
            t.setTextColor(0xFFFFFFFF);
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 26 * u);
            t.setTypeface(face);
            t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
            tp.leftMargin = material ? 0 : px(14);
            if (fixedPills) {
                t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24*u);
                t.setTextColor(0xFFFFFFFF);
            }
            if (material) { t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 23*u); t.setGravity(Gravity.CENTER); t.setVisibility(INVISIBLE); }
            col.addView(t, tp);
            pill.addView(col, new FrameLayout.LayoutParams(-1, -1));
        }

        final GradientDrawable ring = new GradientDrawable();
        ring.setCornerRadius(material ? px(26) : h / 2f);
        ring.setColor(0x00000000);
        ring.setStroke(Math.max(2, px(3)), 0x00FFFFFF);
        pill.setForeground(ring);

        final String label = e.label;
        pill.setOnFocusChangeListener((v, focused) -> {
            int accent = 0xFFFFFFFF;
            if (!"hero".equals(mode)) {
                String appName = label.toLowerCase(java.util.Locale.ROOT);
                if (appName.contains("spotify")) accent = 0xFF1ED760;
                else if (appName.contains("youtube")) accent = 0xFFFF2222;
                else if (appName.contains("netflix")) accent = 0xFFE50914;
                else if (appName.contains("prime")) accent = 0xFF20B9FF;
                else if (appName.contains("play")) accent = 0xFF69D3A3;
                else accent = 0xFF8CC8FF;
            }
            ring.setStroke(Math.max(2, px(3)), fixedPills ? 0x00000000 : (focused ? (material ? 0xFFFFFFFF : accent) : 0x00FFFFFF));
            if (fixedPills) bg.setColor(focused ? PILL_FOCUSED : PILL_UNFOCUSED);
            if (fixedPills) {
                LinearLayout content = (LinearLayout) pill.getChildAt(0);
                ImageView appIcon = (ImageView) content.getChildAt(0);
                if (focused) appIcon.clearColorFilter();
                else appIcon.setColorFilter(PILL_ICON_GREY, android.graphics.PorterDuff.Mode.SRC_IN);
                ((TextView) content.getChildAt(1)).setTextColor(focused ? PILL_LABEL_DARK : 0xFFFFFFFF);
                appIcon.animate().alpha(1f)
                        .scaleX(focused ? 1.07f : 1f).scaleY(focused ? 1.07f : 1f)
                        .setDuration(160).start();
            }
            ChombbWidgets.springScale(v, fixedPills ? (focused ? PILL_FOCUS_SCALE : 1f) : (material ? 1f : (focused ? 1.12f : 1f)), 360f, 0.62f);
            v.setElevation(focused ? px(12) : 0f);
            Object shade = v.getTag(R.id.card);
            if (shade instanceof View) ((View) shade).animate().alpha(focused ? 0f : 1f).setDuration(140).start();
            if (material) {
                LinearLayout content = (LinearLayout)pill.getChildAt(0);
                ((TextView)content.getChildAt(1)).setVisibility(focused ? VISIBLE : INVISIBLE);
            }
            if (focused) {
                if ("material".equals(mode)) host.onAppFocused(label, accent);
                name.setText(label);
                int idx = pills.indexOf(v);
                if (idx >= 0) lastIndex = idx;
                if (fixedPills) {
                    scroller.post(() -> scroller.smoothScrollTo(
                            Math.max(0, pill.getLeft() + pill.getWidth()/2 - scroller.getWidth()/2), 0));
                }
            }
        });
        pill.setOnClickListener(v -> { if (!endMove()) adapter.launchAt(tilePos); });
        pill.setOnLongClickListener(v -> { if (movingIndex < 0) host.onHold(tilePos, v); return true; });
        pill.setOnKeyListener((v, keyCode, event) -> {
            if (moveKey(keyCode, event)) return true;
            if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) { host.focusTop(); return true; }
            if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (fixedPills) belowArrow.requestFocus();
                return true;
            }
            return focusDockNeighbor(v, keyCode);
        });
        return pill;
    }
}
